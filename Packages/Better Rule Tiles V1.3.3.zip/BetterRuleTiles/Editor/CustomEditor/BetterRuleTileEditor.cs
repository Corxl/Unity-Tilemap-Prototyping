﻿#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEngine.Tilemaps;
using System;
using VinTools.BetterRuleTiles;
using VinTools.BetterRuleTiles.Internal;

namespace VinToolsEditor.BetterRuleTiles
{
    public class BetterRuleTileEditor : EditorWindow
    {
        public Texture2D t_editorIcon;

        #region Open window methods
        //[MenuItem("VinTools/Editor Windows/Better Rule Tile Editor")]
        //public static BetterRuleTileEditor ShowWindow() => GetWindow<BetterRuleTileEditor>("Rule Tile Editor");
        public static BetterRuleTileEditor ShowWindow(BetterRuleTileContainer container)
        {
            BetterRuleTileEditor window = Resources.FindObjectsOfTypeAll<BetterRuleTileEditor>().ToList().Find(t => t._file == container || t._file == null);

            if (window == null || window._file == null)
            {
                //create new window
                window = CreateInstance<BetterRuleTileEditor>();
                window._file = container;
                window.titleContent = new GUIContent(
                    container.name,
                    window.t_editorIcon,
                    $"Rule Tile Editor ({container.name})"
                    );
            }

            //set up window
            window.SetupGrid(false);
            window.SetUpGUI();

            window.Show();
            window.Focus();

            //return window
            return window;
        }
        public static void CloseWindow(BetterRuleTileContainer container)
        {
            BetterRuleTileEditor window = Resources.FindObjectsOfTypeAll<BetterRuleTileEditor>().ToList().Find(t => t._file == container);

            if (window != null)
            {
                Debug.Log($"Closed window for asset \"{container.name}\"");
                try
                {
                    window.Close();
                }
                catch (Exception)
                {

                }
            }
            else
            {
                Debug.Log($"There is no window opened for asset \"{container.name}\"");
            }
        }
        public static void DebugWindow(BetterRuleTileContainer container)
        {
            BetterRuleTileEditor window = Resources.FindObjectsOfTypeAll<BetterRuleTileEditor>().ToList().Find(t => t._file == container);

            Debug.Log(window);
        }
        #endregion


        #region Textures
        public Texture2D t_gridTex_Empty;
        public Texture2D t_gridTex_NotSame;
        public Texture2D t_gridTex_Any;

        /*public struct Base64Texture
        {
            public Texture2D texture;
            public string base64;

            public Base64Texture(string base64)
            {
                this.base64 = base64;
                texture = null;
            }

            public Texture2D Texture
            {
                get
                {
                    if (texture == null)
                    {
                        texture = Functions.Base64ToTexture(base64);
                        Debug.Log("Null texture");
                    }
                    return texture;
                }
            }

            public static implicit operator Texture2D(Base64Texture b) => b.Texture;
            public static implicit operator Base64Texture(Texture2D t) => new Base64Texture(Functions.TextureToBase64(t));
        }*/

        private static Texture2D t_tileTex_Delete;
        private static Texture2D t_tileTex_Ignore;
        private static Texture2D t_tileTex_Empty;
        private static Texture2D t_tileTex_NotSame;
        private static Texture2D t_tileTex_Any;

        private static Texture2D t_backgroundTexture;
        private static Texture2D t_toolbarBackgroundTexture;
        private static Texture2D t_highlightTexture;

        private static Texture2D t_emptyTexture;
        private static Texture2D t_defaultButtonTexture;
        private static Texture2D t_hoverButtonTexture;
        private static Texture2D t_activeButtonTexture;

        private static Texture2D t_windowBorderTexture;
        private static Texture2D t_fieldBoxTexture;

        private static Texture2D t_toolTex_Brush;
        private static Texture2D t_toolTex_Pick;
        private static Texture2D t_toolTex_Erase;
        private static Texture2D t_toolTex_Move;
        private static Texture2D t_toolTex_Select;
        private static Texture2D t_toolTex_Inspect;
        private static Texture2D t_toolTex_Recolor;

        private static Texture2D t_actionTex_DeleteSelection;
        private static Texture2D t_actionTex_Undo;
        private static Texture2D t_actionTex_Redo;
        private static Texture2D t_actionTex_Copy;
        private static Texture2D t_actionTex_Paste;

        private static Texture2D t_actionTex_Lock;
        private static Texture2D t_actionTex_Unlock;

        private static Texture2D t_optionTex_Export;
        private static Texture2D t_optionTex_LockWindows;
        private static Texture2D t_optionTex_HideSprites;
        private static Texture2D t_optionTex_Ruler;
        private static Texture2D t_optionTex_Modified;
        private static Texture2D t_optionTex_Settings;
        private static Texture2D t_optionTex_helpIcon;
        private static Texture2D t_optionTex_showSprites;

        private static Texture2D t_searchIcon;

        private static Texture2D t_tileInfo_downArrow;
        private static Texture2D t_tileInfo_upArrow;
        private static Texture2D t_tileInfo_rightArrow;
        private static Texture2D t_tileInfo_leftArrow;

        /// <summary>
        /// Loads all the textures from base64 to a texture2D
        /// </summary>
        private void SetUpTextures()
        {
            SetUpTextures_Grid();
            SetUpTextures_Tile();
            SetUpTextures_Solid();
            SetUpTextures_Tool();
            SetUpTextures_Action();
            SetUpTextures_Option();
            SetUpTextures_Search();
            SetUpTextures_TileInfo();
        }

        void SetUpTextures_Grid()
        {
            t_gridTex_Empty = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4Ae2d2XMdx3XGSWwkAALgDnDRYjmOFltKRFmWlMiWnNhVWZwHVyp+ypPpf0svefNDEruSOK5U5JTKsaVIEVnWUpEsWRQtc5W4g8QO5PsN7nd50Jy5d+bOXBK0eKoap/c+fb5zenp6BnO3bumBjh492rHV2trahvKtW7duSDtBflrXZfd4dQ289NJLlRvlI9Ohm27gd2i6ochGcc8ANqildqKqEQxUGbEq+IBbBHBRfhV57tW9VQNVMSq9AlTt+FbRbubY+8m5Zwg39dJkrOxKMFhm0O9///tlqhXWiYDHSkX5sc69eG8aOHLkyJbjx493bdx1BWjS86M0Bv/eChC10ny820rQcQ9QF3zALQK4KL95FXy+e+yGYeEK0K1hHbXa++njniHU0WT5tkUrQe4eoC74KagR8ChyUX6scy/ejAaK9gS3rAB1wS8rrsFPjaVs+3v1etNAuhJs2AM0DT7gFgFclN/btO61KquBFOP2CpAWlO2wl3r2ftr2YAhtmXsZ+za02XgOfhsG7GUIrwSZMuvc5wNmNxAj4FHYMm1VvxPgncriUP2OdwK9U1m/5erYP0awtY7nA3wRuB1HVqHb5RhPCmpMxzhDpOluw/arPAU5pmOc8dN0v2Qq1e9QqVoFlQxiQXF7Zcirl2M8EUzHzRnCcfOYVyRCrFtUp0x+N9BiOXHGdV6Mu4wxXU78jlEtA+gmdR7wtAn5ESDH4VXiWZf8uQMUQSTudJl4FNftYt5tiffFANJlPQCeTapVHkEm38DH/JiXF3e7yIn3myJgjhv0Tpw5uNwykna+824b74sBpIAns2GyUOTECdyWpnHnmcdyVW/XJw5R3k8CMJPBdN6qCpzneMopd57buT94Xl4sbzQ+ZG/tAlpPg+b0bXAMYuQAbJAdL+KxXYxHOclvmgxO5MRjANxuAdmiEcT+KHNa0f7SUD+At8ihb4MBjyEFnKNp8uAOMR0Ngn7c3n0qKyPS/SADEzlxgxmBX1E+gTzHYzrWpY8YlMzI4zjdOG+vAI33fLND2UGGh0Eyj2AabDiXpTzuOjYIg29u0M1vStD7ZSEPAANF/xF48iPABn25lR85Mse6NgZlt4n+mEueDO1KdSN9XQGYQNjwMRmDBZjEDSqgxzAc0o5Ho3Db2CdxB0XbRF6vlKd88tJgAPNAB/glhciJO9gYaEu/7kvRLI38eXJQXpv6sglsSZUpvuX+xJmoQx7wAE0YSbgNwNxt4e6P/mNQsk2ZHO1U9Uiq/CLwAQ5QAdLgArzDYitubtmpa9lpa6I/iPEoT+WgrDb1ywCsdDgTNTd49vYIOsATtrW40zYIGwBt3Y+VSP8xKNkm8utQqvgyBmCPN9hwwkLCqUc+87AhYASWmbFsCIo2bwT9MAALDy8CPwIP4DFsT9Ijk4uLOw/Nzt63c2FhZs/8/EOjy8v7tq2s7NEGZmxwbQ0DuWO0snXr4vLWrTcWBgcvzg0Nnb+wffuJy9u2nT21Y8cnV0dGLkswAw/48wpwOwDxqCfrTtkZ2IBPno0wxqlTm5o2AE8A7oAR2GvtxfZygw0fVYBnYfvy8sSB69cPffHq1a/umZt7dNvq6u6h1dUxdUp/m4YwQILk2zm5tPTQ/rm5ry0PDNx44sKFS59t3/5/H01OvnlmfPx380NDsxJ6TgEjwGjh1geGwLwwFijqkbRXAjhlNgjKalHTBoAwEXgm5eWasZgwk8cAIuhjSmMAo9o1jn/54sXHH7py5Tl5+xPq4I56uGSqRBjo8OrqDsKOpaX77r927cXPRkffPjE5+dq7u3e/tabVQh16BfQ+xoB7LKe5LBh85zVqBE0aAAI6AHwE3xP2Up+BrToAn4VBKUzKekie8xda6h+TV416xqpz1xIGvG9u7qnd8/OPyajfe3vPnp+enJj4aHVggBUB/RNsCOjM087zcu8H8srUtDoN8q5YA2ShPQGD7wliANHrAX1cYUcrTDxz7tw3Bf7fTS0tfUmNh92hyu96Yi7MaXx5+cDMjRuPjK6srGqPcE7Z6TQBNgbmnpcmP21LXmVq0gBa88wEs1Xb81nuMQB7vMGf2Ds3d/jFU6e+99DVq98Z1vJfeQZ3WQPmqH3C4zPXr+/WZvHcjeFhbwQ9E3u3eer1zqd+bSNowgAQwgHPj96PAXAN9/W+7fm61k9KEYefP3Pm7/fOzz+pDmj3uaHxpaWD03NzB3XX8InuHhb0jDx6eoxjADHdqI7qGoAtEG7g4awABj/X8wH/hVOnjk4tLj6sBp8r8EEQg9++srLv4PXrD346OvrR9eFh7hAgA55ye37K11v1+LcJAwB8G4CNwEt/et3Prvks+3i+wH9EDWn7uSTmPqLbW20Sp3WncFKXA4wAgAE/GkBMezVoRGdNeR4gEmwA3vzFW7729f9r5879jXb6j35ukQ/QoQPp4hF0oigOgp58JoIDoUMcyvsqdEywzhXt3YnotFeyAOYWjFua9BKQ3fZxq/f0+fMvHrhx4/mqg8rs1xYHBq5r4/S7i7punhsd/eT82Nins8PD13RvzfFp9Bi6r7pUMg9TnBNxn2UYiAwY7WNGx5aXJ3WLt09evF9hj84udmlpH4mdudMiLsUNSifPPXv27MnX9+9/WbeI3P/H42TSBObouTIEczRXtDrVMQCPhgAR/DwDyDaB3OfrXvjbbliGt4Cf/WTHjl+dmJp69+zY2NnFwcHramsFoRArBYWgJKiKARivyD0nOHqKRp2NKcPbqms3YeWTiYmrQysrZ2ZkCE+fO/fQ7oWFync00s2fy7A/Zp4aj7sDPytgPOJwy8U8a4Gv9tmk4FUpKoq4Q1RWXP63c8LHIY/ugfeXHUwzXJGXv398795XTo+Pn9JO2UepVow9o44BeC6IFedBPM/z8X6Uj4ExX+qwMizLc1f+4PLlvVMLC6x4lUm62fe4dPTx5OTHMi4MgKNh9Mh8MUDmy3gG3/Iqq23wxEtTnRUgDk7cyrBCUErbCDje5YSvrGR6wLLw/q5dr/xq7943dJvEQxWOUDk/J6QGgEIwAkCJQclS5LmYx7lEz/eqwhzJZ8zM+PTsYkie/6UvXL06o8b00xPtWlh4+CsXLjzx9t69r6kD5orBYQiZkYkzd+QjWB5Fe1sN6hgAg0IG30qjTwLgZwbAgx3O9jneVV5XAvxf79z5ymvT0z+X13NkypJvA2AV6GYAjGHlmJNnSgGKwBMHYINsQwZoiHLPL7suD6yubtFJ5sNfuHLlgTrg0zk6evDatWc/2LnzXT1AwgCYL3q0XpELWSwzPG+Oyu5OdNorRQGI2wBSxW3jqR4PdqjUjVj28fwW+NdUPxpA3iUg80DV87KMMqJCYtzDW5TIkd/Bc3Bb0u6fPmhHGJBxb3v+9Oln7pud5Qib9rWITnWb/Lh0dp/2AleUBHyMkMBKgCyWE5ksC7ISt8yKdqde3gnkJR8Ggjy4BYJjVBY4WwV4pKsC4h1Jkq9xzWfZb3k+4GMErACE9BIA+HkGoOyOikjlJ43sVi7y06+JOXkc523VewnbtHN/uinw3bEEGf7ilStPyQA+UJ4NwCsAchKsezfTNkv/q1eRmngn0IJYgfaezBB4mYPn+WXk0m3eLBu+1jXfoJv7EoARsPRyGYgGwOQdFO1INgAr0kp1IyuSeszHc2obtm5pt3/91Kk/O3T9+lfUmPJGSSvmI9LdlF4qwQEYF31aFstr3cMts6LliU57pTi4BbKA8ExZvMnDyxzdBkF6bvWy3f769R7ACRiAOTtj3x5l11+lMQIDb66sXEJmyNxyww0iZSytEHHKMmMWZ04jOxYXJ589d+7bAv9xFVJeiiTo2pVt225oozduAYoaSme7pLv7r+7efU51GD81ALpwyLq5uTBnyVJ/Sguf9Gb5LQCcvggo0gIPaec/w5s8yutIeH92/3vzVs8bIC/7Bp/rIN7vgCHE4FWhG7exwD0PG3Db01XGLtwPs0bl+ePPnT37rfuuXXtKky2tP1nUmm7vzr4+Pf2b+cFB5tKRpLNxGcqMKlmXls16tsz0Q7wnovMqFAdy3IJYMLiFHdJS9pAqdFUUJ3wc8qitAfeGz2mUBvgEAAdgb8wMprJyl8JU1pimLUSeZUcvXHsNfmYAY0tLO184ffq7epRbCXwJuvqbqamTvzh48MOBtbVBnftPa98wrf4LScJs1Qnjg6qALNYn3HpGXgdFs7jnQroUdQUm7SXZZ1gAcyvQfJAXONM+8tIc74YTPnu3OYATt6fbuzEAGwLx1CBsGOaqklEqL0rOlndxg84tKysXJ3rjAn/3n54585cC/0lNrrTeJNAqm7n/nZ5+a1W3tHpfcFbvCn6mPrtSS3dlwac/5lWJqq4A2pxvGCMqMsbbQvP2bhmJONtXPUC2l0deBD7AAjqUZ/1RWOLUsZxwG2o0AC/3gJ8ZgJb9CT26/q7e5jmiBqV1JsFWtK/54OcHDryuU0LkpO3Q+dHR8+JfVuhILd1Zl8hKiPI7HvshL08XsU47Xnoy7RYbBQjZmWBRwExgXt2OlYriPNhRmT088ujtKJHABGNQsiNZUVaileprPV5PiF6fPbqeWFzcp2v+Xwl8bmVpX4oAX9f8t16dmQF8DBjKxru0ffuF9WTnvy3dMSbyp5y82tSLAaSDWrnmCNoOvDKdNshL81RP+YCdB340AoCPhkB3qcVH5Tge5cMAMm8U97U+gp8t+/L8ScDXbvw5TYg5lSIJt3pqfPyd12ZmXtFpHncwHpuxRm4MDaXy5vbb0l1bl6pE3H1Fntu+TGZdA0AIKAqTxtdrdPnbeqQbgTbI5kUenykz7E18ThXlsBKZL+Db81nuCaxSGADAZ56vV7b2fuPUqb+V5z+txrQvRRJ2WU8G3/yvQ4f+Y2VggMsYc0IW+sC4V3iKKF6W4jxiPLav0l9sV/56tqHVxoQHj8LF+MbaxSkDDU8NIYIf4+3eEp1GmQx+3rJvA7gF/D85c+Y7Ar/Sbl+Cr/5ux443dIz9ssDnGDcDXBwZGJ95MT/iZcnyW6e0i3H3Q17mDM4ow+uuAEVjWEB4WYrAdop36i+OS9zKs+ezBOP9EXi8P/N6uJb9qZbnA35p/QjV5bPj48d/dvjwjwW+b2Ej4O4LmVgZeqWo0xjvqT8L1VPj0CgKQjyGUK1jFM9wKDIAOsizco8fucHv5PmA3172teHbr2v+X/ey7MvzX/3FgQM/FfhX1SdnF5xbeD7oGcNDPuRhw1mWoi49v7Jtu9ZrygA8UFMCGmRz95/HPWZUlMFnfii8lOcDfi8bPh1gHRP4P9FLnRc1Fps+H1rZkAEfY4D7llbRnijOs6cOYqMmDcBAxP6rxK2syGlf1QgMfmnPr7Ph03/4vPry4cM/anm+n1n4DMM6AXzm4TsO9gZlqVHA00HrGIAnl/Z5u9JxfCvJ4Jf2fMDvdcMH+LrP/0lrw8eja679GAEA4+mWC45s3hRiEE1R1EPlPusYQKfB4sQ71YtleZ5f1vutYJRc2vNrbfjGxt6U5/9Ty/P90goGQGDzB9g2SMvluxt4XyjcDpfqvx8GUMsiS0gd+3fcii7t+TU3fL/85YED/9oCnwMsL/3e/Bloy+M03JeDElO9pYrne0uBM5LbYWcX8n4YQOFgDRegDAd7GN7PRovghzo+6Gnv9vH8Ghu+NwFfr4LzQAfPJ2AABG/+DDIcHbMaEHd+mZVN1ftPd5MBGGxzlAjwpO1pXXf7DWz4WPY55DH4vLDipZ/rvu/xDTIypuC7TEV3lu4mA7CmAByCe+kv5fkNbPj+LYCfLv0s/3g6AbJ8XvY3nfcj5GY2ABTYLaQbvv6c8N3c8BV5vpd+wPbmD9mj5yvZvqW9twKgjR4Ij4dsGBgARtzxmt/Qhs/g4/l+URWvZ/n30m/AvTLZ681VtW0ExO84beYVAOUYaCsUzyHPaYBnDh09v+ENn19SBXwC13yf7iEfYENeAeztcMezCpvhz2Y0ABQXKRqBlRiXfjZ+NoANZ/sNb/jyPB/wWf699Ftuy2x5Nx3wFnSzGYDBtwLN7fEuR26C3+Tx8/z2U72GN3w+6OFWz54P8PZ8b/SUlRHyblrQWzJmbDMZgMFFsBR4FIrXOz/e6/Msf8Pz/IZO+Dpd873p867f137PweB7BZCIm5M2kwGgIQMMt9cDvIk4+Sz7BIDfsOw3vOHr5Pl4P55PAGiMANmQfdMDLxkz2mwGgFB5RuB8X/t9yrcB/IZP+PKu+fZ8L/2AjgFA0QiIQylfz91EfzeTARj46PkAznJv5cZdv5f97Ii34Q1fWc/HAJDNQNv7lXV30GYzAC+h9nTks4ehUQwgLv1s+sYb3vCV8Xxk8nXf4CsrMwSM4K6hfhhA9Igqikg9H9msXK8OgM/yz9JP4B2+yZ7f4Ss+4cvb7cdrfgQfGbuB3q1cXZQi66NU5TKV+mEAHreqIaAkjADvRy683eR8X/tZ9se14fM/bVR+dVvv8PmRbpndvq/50fMxAsigNAXyeq+36W8dA/DEmxI1Au+l3nnmPvAZl+dP6ISvp3/a0Dt8eY900xM+3+cXeT7zjjqIcesEo7BhOG7uOt14Xr+xTbfyWPeWeB0DuKWzmhkGGZlY6u1tcK8I2T0//6jZ+l+9qv+utdx6hy8+0q16zU89v+a0SzUH5FJA38k3gkoLWTBlvJ7AMu/JwlG4y0b5F+3sv3TX/1GTS0MpUid8op13+OIj3Sq7feSIchG3dxfJYG/P40VtuuUzrsMtde/UG0FWDAJZOPNbhCzIsOdjAFBUbnZJ0LI/3vr/fP5Fu/TqJeSWWfZb7/A1cc33fOFRTsttwElDTke+XtL9r/Vo3r1FhRqlldihz6gMCxl5h6YbigDey74vB1Zu9lkWXfO/VfXjDICfs+Gr6/kbBG8lDC5Jx+GsUnmBemXIunRd65t0jLu8Em/CAPIGtNBVBIzXfa8GmSLl+dv5Js/h2dnK/6uXs+Grc80vMx9khgx+NodWOuZllUr88ZjWKU1i3F1k9W73HiAVzoJFbgE7cj683PqvWbyFlYAHLXyKzV/jqvRBJjw/bPj4dy28nsA9Pi9x+KlefJ7vFYjrPSHOT8kMVOc5bR6Bjh7PauaAYQ9qrlUcj/GiPNYt45raMlXeA1S1GEZMBrFA5lZcJjS/q1fmGwF8dZsPL6t7lAUQK/oI43a+w9f6FBtKLUUa2Bs+/mkD8PF6L/vxJU4/z/dTvWxc1fVczLegp9a8kTFSEfDIa+A3cP2aGCeYXQndqZL1iSyO09aywXumXr4TmDew8ywgPAv8qGIZA9g1P7+Xr26rHRu+VT6/Gr7AiQJLkQZlw3es9e9a3vDh9dHzi+7xrUzzNtiJ0VuWPPANNl7u4LuYLK3Pyu9zB524DACZ0aNXJuSybi1jpy66lpX2qoKeEMKCOG4BM84vaha03ZDN9/aVkT3dk+fv+vqZM8/qS1p/KAErgc9/6b5y6NA/tzw/en00ADyLYM+PMns+lq9tBM4Qj8ATR48OyGvg4Qa/zfffuHFI+V1JurukSgbfMlrPtI9x95fK7/xc3pQBIBwDw72MZsrl51RzR04y9cNRe/g2nj6jtkNf3X5cH16u9O1dDbzK/+fzL9rhv3T9vj7Xe3s9clmpUVkG0tyAwu3VebwIbDa1fnZhvm1kZWVMn867X2VdSZ+SOadK1qd51LXlT3nXvl0B4asQA6EgKA5KHMEcLOzKpW3bfqsfiHpGjdyOtreQDGDX9I0b+750+fK+qp9c16Dc6r3R+jgD13y83Ue7GIGf4+d5fZTF4Md5xnLingfc9W0Y9vIIPre3DiPy/hl9APIwHXUiCbCmT+edVB0brI3WOkZGB7oiXpmqGoAHYDAmbwHgFszgZyuAJnFa38a7zk+punEe58PL+t2cL/JjC3I5+i5FGnSVb/K0Psvi3b0BT5XnPu3dpA1inIvr5XHqWz7342UfAwB8nllkx9YtzqVtVDvJ0S9cu/aIfihqQumOxN7p8sjIGVXK9ChuvVrPlpd+iPdEvRoAg0UBLJSFtNBL+vbvJwsDA5e7GQAarfozKxp0ha9xtT7IxIbPS72v8fEpnuU1gIDnuBVorqJCchu4DcCXAXv+reDLALQSTutnc/iNRNp2JH0086JuY3+rSp5DasyeTxmZC8eqYwDu1IJEI0BYBF/iJ9S1Cry3Y3b2sBs0wQGf7/DxKTZt+Ly0e5lEJgMFSMwT+SDSlhVuBaacuiYDFrnBt/czhq/1NoDshRXlj2uF2/nV8+e/qY8/TrrTTlw/KPm+dIdRZ3oUtwGkslv/nborLOvFAKwolEE8CgQACGoDWOS3b/QT6sd0iveCNMYSWZs04Cpf4OQjjK3v8HnlsSxRRoAySMSjkUTluU2efBF4yumHPF/70SNz87UeA8juaMQzI/jyhQtHtMd5TI3cl4rySZNY0q+Nv4nuVAPjTlcB5hllp6NO8lOeS70YgDuyAOYIZSBstQi/oKXspCz6bW30jnSdvXsv4Bog+/Zu6/OrjEOXhAg0YCCL84ljlNFAiEOp4mI6FTeORdwGwHgErwDr1/z1D1CNP3P27PMPX7r0ogSkfkdicK2Yb7eW/2gAzNX6jfOw/uk3yk66K9UxAHfOoBbIim6vACpbkJfOarl+Q7vfx/T5UzZIPZEGWeOr2/rw8nutb+/Sj0G2lwME8iCXAUIuywiHouLWc4r/2hC6GUBcAUZZ9vF8wNePRpeatw5/5j+emPgffVKe00sbgC9x6NVzsfzw7KQSXpXqGIAFQCnErWAExFoz7xdnEvNv79lzTLd3z2oV+COlK5M6zb63r0+uf6CvbjOWl128zoqhX+SxNzo/V2mqlymPRl0ozwC84kTDwwBG2O1ruZ956tNPXxR/VBVL6/nKyMh7b+3de1zLv29f0Z9XVM/Dum7LX3BS2WVaFQRLemJgA0/cAQFROsFGwM58ThMakRH8VI90D+uXNfcorxLxSxv6Ja1PdVA0JAOISscArBiDwtiAQb7LLCMcMl9Pdf5bygA45AH4B69effT+2dknteGbUEO37TyCSuX1F6Sjf5euOMfIe1hlg8YA4nwc7zpGWqG0ZaYNQ5rBEYiJwm0ENoBsBVD+iJa2D/URxpcfvXTpe0pXIn5m5RunTz+sb+3v1w8ufKZf3P5Uh0wX+PCyFMbYGAWrDsDbCC2PFQSHzNdT3f8aRDgBQ9MPvq8N8WCHs32Odznh45CH+3xVcpvuvbdqSD//qUvlh0r6BDO9BNiYowGU7j+vYh0DiEokbmUzcQAADPoHGJbkIV23h/V9nZ/pwc8D03NzT6siiixFdKonhtvkWTOEUo3ukkpS3qp+Q+ANXd5elsg8v4gHWr4E5Hk/M9SDyggFWeWpNABdukQCGwGGYA9kFfAKwKQ4np3V7+b8WD8R84Ea9C65Ovp9IHSg6/77b0xP/0jz8fG1LwEp+LkrgBbAbBFkIawaBo8cOVJHj3GZS+OkY2CcbOnUw5rFi3pGoF/MflDL5a7YsI4wd1tbwL82PHzivw8e/IdzOjGV/H56iQHEVQBHIniVxXFiULI3qmsAjGqQHU+5y80p3yIjmNf1/MT++fmD2iztViHlnxsSeqt4fgb+2Nhv5boGn1UgBT8u/77+N6KrJgwgChJBjIATx2Jvkpat6yMjczogOqGflpvcsbx86Gbh739M1/zXXztw4IeZ56+DbwPw8s9dAF7vM4Dc5b+uppoyAAOfcuTLy7Pca3oLaO6DXbve1aHJ3MTS0gHt6TlG/b0lbvU+nJr6l5fvv/8fw8cm8Xp7Pt7PtT9e/730t72/tfHb6FQ9aK0pA2BoA52KkQpJmuDJwPmNnU9mR3SnuLQ0qfvpKXU2VNRhOsBmTzNZTvh02/rOsX37fvjOnj1vaNeWvqcYr/t4Pd7vpd/eb12y6et54xc3inVuA1O9WzjyARUyhnCHrEB/qJ/pRnyFX9b6aGrqXT0EOfHEZ5/98QPXrj2j+2p+l5dbyLuWpIglzvY53m2d8BloPN1xH/rg9Z3At84a00eTBmChbAg2AqcpJ555fItj2b5lZOI8PZyXol799a5d7/DbuTo+PqJf0HxEG8Vd/IyarMhGpeqbjzTBNV7m4Hk+j3R5qseDHc72NTdv7swj8Cn46CXqCt1Zl+a1FdDLW8GdBkWw+DPmpJkEoDGhSJS5HENgySMsSFELepdw7sOdOy/r4c+v+RVtjGHn4uKMjOEBHQhNYxB623iszBvH6rNvxKvbvL3LC5y8wydvP8mbPIDO83zmosFjAPSYjsDHZd/gW09wyHw9VfOvnKrR/iwggNOxwXe+ucso9wrA5FkFOMpFSfBhKXBEzwGuKpxVmhXLp4ucMHKukJ0ttLhYe4VocqWISiIeg4HCiOOKZoPOVjaVwQ22454zOiDuPuD0az15fHMVNUP9uAQgGYIaAOIEJgQ5bU5+qjge8KAsrv8OKfg2AMaxESjaHtfjk9cEIS9kuYkbJANmAKNRR0NI4xF44tYF3H3HcRmzUeqXASCkBSfOZAyIFejJpuAjU/bsIPAi8OMK4P5Trm4aIc8ncoMEj/OJczLIkRMnuJ7buh/rKI7VyCTSTvppAIzFBADEE2GCBkjRjCjzxKMHIRtLJRxvjyECb+93v+Zq0qa8vHZhh4jljlWcB7fs5shvMONcDHTkLvfczd0vHDJfTzX8t98G4AkAgCcSJ8ikAdBKI45nwFPAveRTRqBPcwOcclVplOIc6NhzQX7iBtHzMY9gE4/1iLttXv8q7h/dDgNAeiYWjYA8Ju48KwBAyYejKHheoF1eUHZGlPWDDBB9E3faIHoepLsF13U/7ivljNU3qmQA3DFwitQjqXk2N3WxNU6SDknDURoc0PM4eXlB2Vk+HKJOP8hy07fjcMejIZDndMrdxjzrr6Uf3fj0Ln5VjCqdAyDYqv5rd2AAfA8NMzAAAAKSSURBVIqpNZGiCipmjm0jcD2UYXAdt0E4P+W0jdqKcffbD458JsfhVQLtXd8vdbov912JVwWfziufA2AEXQAuI3Q6UdKAZ04fBjsv7rzIiafUlEGk8sZxXJbHY16M0z5Nxz57ioNNVap0CajaeVq/wHhQhMGPTZxPnmeWctd3vtO3ixtEj+d0EadeVtZyoiwegYtxd9pPflsNoMPKYYWlcyU/NY4isIvy0z6bSneSOY7RrtcCV2pYz8oDm7K8/Nhhk/FMaUePHm2yz8K+PHEqlJxkEahF+YVj36aCNtjJeFk+c7YOzK0Hp2nnvKSPW5K0KVv3lsbKeOmll7J77S3Hjx/fUvPdwLz+O+bVEVwdb1B0XUV0FLREIXNR2CBTXrNWvXZRkQ6K8tsNW5Gy9dJ2pAEf4nAlo9thBFHgGLcMdXjT/VWRhbGjBxe1LaoXZY/xon7q5ht8+tlwPxcL6g6S176MkvLa3Q15ZYGL9YjHNPPst45SjHOvpT/4wQ9q6bxoEjE/nXidAem3yf6qysLYcW5F7WM917fcTtPWeUX99Jqfgk8/7UtA7PTYsWNbnnzyyZjVeLzpSTbdX5UJM3aZ8dN6RW2K8qvIlNbNA586Gy4BsVFRg1inarwfE6sqQ7/qRw/uNEasRzymadcPHXXCstAAEKZTQ8qrUjrZqu03c/2ywMV6xGOa+TWto24YdjQABOrWAXXuUXngIsAx3g8dlsGuqwEgWJmO+jGBu6nP1JOLZI/1Yryofq/5ZTErZQAIUbbDTgL3c8Kdxr0dZWW9OdYjHtPI2YSOqmBV2gAQrkrH1E8pnWxafjenywIX6xGPaeZfV0dVMapkAAjIABa8iFPv80ZlgYv1YrwJfVUFnzH/H5pQ0OeVChyPAAAAAElFTkSuQmCC");
            t_gridTex_NotSame = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAc8klEQVR4Ae2d+5Mc1XXH9cIItE8hhKRFEi8TTGKXAScY7CQkEMApF+WkcFKpPJxC+cX5JX8RqvyWSuxyxQnvQMDgR2zKhji2EUIPpBUJlZRB0Wt3tctuzuduf0dnrm7P9Ezf7p0lulV3zn31vefxPadv9/RMb9xQMR04cKDiyPJhGzdu3LCyslI+oGIP85D8XL5cZRrmePLJJ8PQHLIxUZvybdq0acPy8nKpqAcPHizt8x2rmvQtiXIOBaWMllhq3TaNonwCeC+lburVSV8O4zPPoB7KMWUJZUvhZWPabh9F+arYrmcEqDJBFUV7Y+VUVJW12xgz6vL1igSbyxSUy/h+fq8o3z5omXniuQYFVnz8oDykxueaM4d8nr+77rprwxtvvOGbOuVkBGjS+IMaqsPpiBdk/FGWLxUJLosATRhftpOSVB+WpjxEc1U1QC5etC4015y95PPrDVq+++67L4sEXRGgKeN7xVQ10KDCreX49SafjwSdCNCU8b1hvKJ8+6DllIcMCqxcvHjec81ZRT7G9JK5V7/fE4QIUMf4MFFFcI3pxbRX5norr0f5iAQb6xh/UCP1QuUgcw2i7DLAaY5B1u03di3k68dTv/4t/Qbk6M+t7DKjpnjNvXYbawwiX4qfQdpaAYAEymUMzaN5EdiXUwrQMam+um1aO9camkfzwp8vp/jlmH5jUse1AgAWllApJuguaU9+c5QStM/8JdPna+6zfivy9eEhKWxrAMBoEYNlSvGM+jEdMGieFBBSbV0Tmqc0kdqSLzfvlQGA0vspt4w5Gcz6vfbLyn6ajtG7Gnsw4tbyhzRadmuWyeTbPS8Dy+cPzlGuDIAeOu/LR3GslFBGmUd9Ugx1lbXOiik8tHuefFkDe1FntF7DKvWthXz9ngeo0g/flQFQSRPpQTKqp5R95kj1axYML+OrHOqRsUNbToOKgYpUfHvqZfPtfkrJRJvKleVDB71krtLPwk0DwAsfK0V1PZOgsfBF8krxZf8YDO0cFxTHQS0n8SxZUnSk5WsSACnloAwyfSqr7sfHBsfoyowbBRB4fimTJZMvj7R8TQEgVo6UIAXxHQRlUfXrOAFARv/IxlIWtWI3CCzkcWzlSNArfDJ5nyQ+oWTxPzLy9eG/090EAKQUFvGKwdgyOOuqTlmKs2JQKMbGmBhcecnKjFOddTRu2QzKeNoqg8DGDpP6ySe5ROvKh4yc7xuRLzcAUI5Syvgy/FU2iLKylMWxMiyCY3QMLuNDZQDaSYxjrQCGqpFgyAhQRT7J5Okw8iGrEsYP8hmFh2wgh8lcScqByvgITlnKwPDKn3BlxokXjkdY8qJlFHHRMv3UKcdAYCyJS0TKWZUUZr4EPOaWjMgm3qEp2QR2+km95EM25pTxPcg5jpQ1Ekjpq1MP/ynmoMoIEhsfo5OvLrLqASB/cPTo1+e2bPnv5/bv/6b1IzwGJ9Mv5Wh+awpJ3iBKvwWC3nuCASMAc5K0tmTDqAIAhpY8klH1KvIt2PHMqzWsGMpQpQ7Q1VCXbubhgAzJ9BluzsC8Vw6CSzEY/ZoiX2uUvK3I1z527Nhf71hYeGxicfFzO+bmlo9NTp6wPu89XjmsQxJdrV36hJ1wwwi2UvnS0L4l1iBr/Vg+GRv5tlpGRi9bkNHk+3pCvgCMYm7NK5kEaFEblj9t5jmxlIIGaLOhHeNLUQjmQ6JXDgqS4aFjXz5+/K92zs9/SeJNXrz42en5+eXjk5MnrY25YuVoKFQKimkYU0QCPz6UV1m+rDlukDFYX7JR9l4PSBXRUsZHvgMl8p2wY718Vu2kWB7qamMQZfFHfagUADDUkasHiQGvHBQkZCsEohivnDGrh/z77777l7vm5h5ane7S5/TFi5+eXFhYeXdiYtZapXTWUWYwZa8U2nwCm8lI4AeVlLWONz6Gj4GtyOa9ftzGhWzyfa2ifFpP7EguTymrrnG1aA4AiHEZyXsHACAsKjQGj7d6UM6X3n33L/ZcuPCA1ZNp+8LCnRMXL244sQoCrQNVkjK8YnybxkH9cb49VdZYb3zJB7j9aU2yCQAAO8j36IkTf2by/XZqAdoK+VZMvpNW1Zqef8nFuT/7+R8ecgEA5UhB3kNQDh6ikC/ljKGcmQsXfsv6eiZT0h1jBoKTExPv2UCUpKzjUBJtUpzaPVU/tF/S/MhDOSVXHPIV0TD8BNnk+5OZ8+e/aOWeCfkM5MsFCBjrjU4Zw6stpoyvleoAQIqSkqQo7yHyDg8AlPOnppzfrMr5dQsLt48tLm44OT5+yo5hPRLKIHkqBcXtYWDxoeN9m8rq88ZPyQUAkA2vJ3cB4JETJ/74xvPnv2DtlZIDwQk7ABnk8VwJkVVXXyyn+Lahg6XcAMD4ZJ37PQCC91vY//Mqnh+Lcd38/Ce3dYMAoVOCo5yy5MfHZc3njV/lnB/CvS2I50+a8f/IjH9/GQNl7QEECwtLFgmO2RhveO4JAAAPBKbxIKA+VNp8zz33DHMVIOVBUZj3EgEg3hyNseHrdc7vJ8GObhBouAyOkkhSjNpT1PMfl1Myxed8eT7GB9gh7BfGvw8mhkkGgk/ZxnfJNr5H7HgMj9FFPQAkI8tIPsoDp2HvA0hpKW8RALQBDLt/LvVsN/zgwBxGBxgIbosiQTSiU62iGOSIs8Ds9zJ9z/mF8T/fWX3IgoHgzu3z8wt2CXzIptCNMEBAViRANsoeCFYdPNUCANdYtqQiABRPEQB0nryGmzx2Hfzo4Oylj3AgmHUjZPCySOCGdoop4wsAyFHm+Trny/O/amG/tvHF1ZRdAtvNsHm7GfZza9Otb8AQA4BDJDflgdPQAFi1fcd7pDSdM7UHuNpu7/4Nd8AG5qzPAQ4Ep2wohixLXkGMo67xovAtGWR4jF/F87Ma39YMiZthu86fP39kaurfrQEQAAAfCRQBGO9lpF45bSkMWfmAAQfyHaaUPOCh/Yf/yunTIap8d8+e5220lCDqI4EMz6T0q091jM8YARjjy/u1kY2v8ycs7DdifJiKktehL2uYl09tleiwVwFiAkouVeCh7dt/uvfs2e3blpZur8TRgIMGiATMHPMt3vsZXiG/c53ftPFPjo397fP79/+98TxvmQigU4E2hYoAojZk8JQDAKzqFQkY8B7tBa56e3r6rZlz57aPLS3dyuDcyYFg1s2tSCDqugK/4hnqAcDpS6Hf37/wu/1GPf/4+PjfvbRv37eMjznLAkDqFFDL+DZ3rTuBKI7kFYnxySgUCgjCOfXw9PSh3efPT48vLt5sbdmTA8Epm1y8xeuoXTx7w/tzvi7z/K3rRjZ8MYNHJya++fLevd+29guWPQAUAS67HLQvvOJpKteHjQAsgBK9QmnzAEC5GF90yztTU+/ccOHCtH3lu5/BuZMDwaybG+3Ap7QkvqH9AKDQ34rxj0xOfvs7N974tPGF8T0AeFZAANDlYMf72ccNm3MAwCuUMiBQmwcE5c22qwUEUwaCfVbPnhwI3ismhxeSeIJiePhRhFLYj7+xDIa3cY1v+N6ZnPznV2dmnrG1zlk+X2TCP1EA43MK0I0hjE8mCdirtQE/6wDAL+WVS1kgEAC6qIHgyM4LFyYNBHv9JLnKBQhWiu8OmBaeSPBBigHAOR8QCADy/LDpe9hu7+7NeJ0PAz4dnpx8+rWZmeesDeMLAEQAAID3Y3ztAWR8qIwvak2DpboAkOFZVeUU9YAI/UfbAQFfIBEJ/PoY33u+DM/l3mXnfDP+V83491pfI+ntqalnvzszw2Xs2SLj/Qr/GF8A0O6fKIDBhza6HdtJw94I0gR26sGeIXUKru7BUDRfGmsgOFpEght9Z65ydDqAF0UiAYCNHwDQtT6eDwjCFzxm/McbNv5zxT0MGV8RgLBPxvg69+sUIM8XCGoBIUSAYTcQhfFlZOO1E2oFhl409LlI0BgIrrVvEWfHx//L+NOmDwBgfAxP1q6/8+XOwydP/uEaGB/PV+gn/GN0AUCe7wFg3fVS3VNAanUZPdWXbGshEtxagOB9YwAQYHwBgPN/112+3zt58iv7zp37dWtvJFnYl+efsQXI8vxU6PeeHxu/lvcjXC4ApIyeamPNZGoBBLdcs7S0ySLB/xgDhH0f+gn7IfSb8b9sxr8nyWSGxsj4hP540+c3fpz3yRheOUvot/lCqrsH0DzQeD8Qo7Os3mlvGgTXz8/ftHVpaeOp8fEPjV8BgFNAAMBDs7OP7D93Lstz8igkTpHxY89X6Nd5X55P6I+NH089dD0nAGBCIIi9X3Vox+AprlsAwf5PfPTR5vfGxv7X1tceYNvvzs4+cNPZs59O8ZSjLTJ+7Pls+PB8zvf+nC/jozNlK/bWIQOqptwAYF2BQIYWpU/llDC0BaA0DYKdc3MzW5aXN//n2Bhet/WBU6fuu+Xs2TtgsImUML4AwPre8/F6eb4P/Sl9ZWG19lUAVwJxLjiT13tGFQFEfV9XuWkQ3DA3t2vTysrm20+fvvm2M2du6Vo8Y6XE+P5aX57vjR97vjiSA6lem+baBPZiREyLMlZlqC+rr5VIsOvChR32CNYUizaRSozPpi/l+YR+DK+cfcefkrENAIx0JEgpJUdbYfwXbC42e4R8chXPBwDeMazacRLKWVMbABDDsafT7tt8WX2dSHC9fYE0ubjYyM0iMZiLOs+X4Xud89fE8yVrmwAYJhLomI3sCQwEk6MOAjP+83Z7F8+X8f11vt/tx+f8Vj1/LQCgNWNPp923pcrhWAPBsVEGQWR8XecDBJ3z/Zc7a+r5QaH20WYE0JryatWhtGF4UdpIGgsN2UBw/Pq5uUl7anYmjBiRj0NTUy98b8+eF40dnfO957PT93f4dKmH18ebPSSSE1BuNK0FACSQhBSlPVX2beFr3aOTk8ftufkpA8EeTbaW1Iz/ojO+PD/e7QMADO89X3f4BALE8PJSbzStJQDk3V5AtXU8vuj03+dT3mw/mjhpICAS7PYTtF1+a3r6le/v2fOyrauNnje8P+djeG7ukOX5AoA1hdSq8VmxiTuBq6JU+OQGkqUqQgsYAkL4WtdAcMp+NDppv6TZVWG57EN+MT392g92737VJk5t+HSHD8/H+HHYl9dLftHsfPaacFN8F6/FOgJLaKi8AYqHyFugKE/hE2WSw5cmL+7d+7I9Rv0Lq7eafrZ9+4/M+K/bol38uDr8yttjj5fsXv5W+ddieNRaJ68MGR+FCQSlxrcxQfn/unfv9+xx6nfaEuSn11335g937XpT6xvVN3gCg3iOQYBMAruXuy3Wu9bhpVGb/DvkunrbqcgDUqtJQfSpDPWhs9P+yo03vmmPVZ9ITZSz7c0dOw69fsMNb0c8iS9FsQ5fbpzYoC8knudfywwTPBo1iqmjJGPOK9Mb35c1pi1ZWE/ri4oH3wc/1EmiqzWrF3sg1deEbj5w4MCaLFwsqs0dlMwpieyf3QOk/rFtPbqt5/h4mONavtJt8ls9WyMkvkCyr5KX7KtkHi8rC/06fUFTAPFgkA5WF2jxk78IHIU9gIwf0zIw6Ile0c32MMf9t545c1tbuvvML3/52Xvff/8ztp548FTgFZUcsXyqt8V2ch0YX6skBYhKUShOCtWze0QAsp7ggRIJtj44O/ugPclzp5VbTb/2wQf3blxZWfy33btfsYXFjzaBigB4v9/4waO8nz6f1O7bGi+vFQAwOillfAFAT+7Gxg+Gt2O32gOcj9oDnHjimqRf/fDDLxpqF7+/e/dLxgAg0ClBVwECAsb1pwL4lcFF0YXK9LeS1gIAMroono/RofCD4fF8DI+xdc4PD25aHTpmxn/MjH+3ldc0ferDD3/HIsFHxa1gDE7G2N7gZcZVFBBAysY1JmPbAEBAkje+Qj+8CAA+3HsAhN/s2Y82vrL33LnPhZlG4OOO06cfMjaWDQT/YlQAgMqwonAbe7nqwfjFfxurjfGNpjYBIKOLes/H6+EFw+P98nx5ffiplrWPm/EfN+P/hpVHKhkIHjbBVopnATCgjAhFZhLU10OjfXQigV0aUtY49TdG2wKAVwBleb3CPnxow6eNXtevdax/ovit3sgZX9ax/yx6xMoxCASEjpGL8WqPaTB+W5GgDQAgkM9VPL/rR5p2PMZv9Fe6hVFqE/fHVS+4yZCfhOwk1UX5zoDUAUlbkaBpAEhAKLmf58fne0I/f87wuP0P371WXhfJgeB5Yzj28I6RC2HiftXRlwWC3m8+qauQJgEgo4sO5flN/xtXXQWWHR+BAB2QREcmEjT1QIgXlLI831/j61KPc75u6+qfOVr5Tx77Yuftc1dddb6p3wa4/yeYxfpFkof7SECb2mMaDisigebIRpuIABjcZ2/8st3+Zef8pj2fr3R/vHPnYeN1xa7jL9qt5E9m06qbaNQjQe4IIM/3Xq/QD9j8TZ4183we5vjRrl0/MX54Wmfe/p37pL2j6Gp7Tc1OZ7tsxZyRwJiSjrPwlxMAYkzGhxLyfdjnOp/sN3u6xm8l7PMYl92//6HxwLN7PLNHvmj/zn3MHi+7tqnHyxwITtl60pUVu0I/7alTgNoYT/LHr7YM+ZkLAGIISlbYx+sBAOd7vB/je8/H+IT/VozPA5z2GNdrth4/0SJj/AuWwz18e8aQp423NfWgqQPBrK3pEwb2WX1qUz07zfVQqF22hic8vfExPEaX4eX5eL82e+Eyz+qN/w8fj267p3c9APTQJt/kLRkIjhoIxpt65NyBgEhAir17tbW8Xf1ZaIgA2K5GxvbyfAFAng/Vbh8AlO32ec3K57NIlJik+NHGS9alp3c9AMIpwPoAAPfvPwIE9uMTQDBj9ewpAoEAIG/3lLXjqwXxwzj0XSvVPQWIARneh35vfMI+nh/f29c7dhozPj/XKr6p03P7UMK+Qj/h3399G77EsR+fHGnyF0gFCPyfWXrDq2ysdSKE2qDZUg4AYHwBgLBPxvh+x69Nn0K/zvl4/n02tpHkfqvnf67lf7iB8ZMAsPZlA0GjP0g1EPAiLEDAnsAbmDKeH1Nr6gCCcu2UCwDyfAFA5348X5u+8D2+1XV7l1er3V9bgpIJzPj8FdsL1u09n9CP54fLP6OEfYV+7sejdH2NGzzNfot4pMkfpAICey/isr0X8WSxPjzEOQaH6ja0XqoDAHm+vB8QyPu16xcAukI/L1U043+hHuvlRxfGf95GYPxev9VLAUCeJyWvAIIm/9E0vBdxFQQnjF8AKCB6Kr5EA0BtLBQbDJVyA4DQ78/9hP6uc394Y2iFN2oOJY0dFHm+vF+ez4ZPu37O+3i9PF+KhZKkYMr8P0HjILA3iPr3BsIXYBB/Aobnz/MInwOnNt4bKADw3sCv9XqX7sDcRwc4z/fnfL/pw/ic8+X5UjLKJaNQD4QuBRsIGv1vY/tO4g57b+DilfcGmhUGTQnjY3h5vj/na8fvPQtDy9hlNLDUAgiuvDcwk/H9bj8GAMZPAQDj+xALKx4Q4VzbNAiuvDcQtVdMfTyfc76/1POGx9AK9xhZhtbKcV3tgTYNArsJdeW9gV0aT1RKjB97vq7zdbmnzZQ3Op6tnbQHBasKCDHdYK91+4Z9bb2hybuYhdjijaovF92hTfyprRId9ipATEDJXAJC4/sAn2jqvYElxtc5P97tc97XRk8GhvrkFYgs1EX9uK5yU5HgynsDu9TcXYmMX3adX+b5AoAMLuoXUZunvsxY1TfkBsHH9b2Bb9l7A7fXfW9gZPx+1/mx53vjdwzoLR+VFQFEo+5QDfMYCLLcJzg2MfGN4r2BRDMfyTiFsYfRKawjiz0uFhgZ5mPYUwBroRQySTS+JcxNIZ0WeG/gYXshMi+P3B+OGvDDjP+se8fOMJ4vpbGy15r49+2+X2WoL/vxRAJAMDHs29DsDy7+0f7o4imbVF9W6epF9y7iTWzgpcY3ubX+J1AAiKn2A7R7QISyvTLucPHewP1or2o6PDX1jDP+IJ7vb/BoORlRdU89GNROG8eIqj2m3DZ+ZxgQhJdGzsw8bROyicX74wigaKbLV8BM6iXL6ogen3UigJ8WxfgsECRpAQLeG1gJBPZevafsvXrP2hoYXsavsttXuERJUpSoNV1KPoyuPt6QHK9j/XyKKp02AwEgJxLsu7RCeakw/jM2QsYnAij8ay8DALzxtS4Tiy/KA6W6AJDRWVTlXrTDnIHgkJ0OJux0cFOnMVFAOe6NmjJ+HCI5P6IgeYl2/B2jFFOXKsqH0WIscsSJNuYQpT+ek/oy8hUg2M+gskTY/86lN4YKABhfAJBsOv8rosXrli3Rs73uI2Gmt46eOoViRepqg3qGA3pNST+3jSEguDnFJS9SLt6li2KknDg86vwYG18eonVFU0v1atNxooxVGaqy1oOGbPL9rIJ8T9l4gI1cArYAgPFjAGgdra31bejgKUQAj/5By7ZkbGi4kOHjMnUxHpRkG8P/sFfLj8WvludSyHbD/2TjZXCvIH2pI+N770h5SB0leVngn0RbPKfqAkCIQoV84yXy8ZZwyeeNL/lkfB/RPADgpVaqewpILR4rTIqBKktJGG7JXi3/k71nz45vW1q6nQm5CfLSvn3fsqKMLirPkIJ82PfnR63DdFqfcp2keUQ1l9aCyjgyWACmyffjEvlkdFHJB7B17he4pTOtx/oxL7QNlHIBIDa6mEi1SwAEkqIW356efv2mM2fGPti69dUX9u//B+vDyDoPinrFYHwph3mkfK8UX7YhtVJKFj+hl4uy5IPHXvJJNuQlp8K+5PMyZpFt4xNPPGFrZknaD6Ao7f65B0BZD4pA9aygHhuD6n6BlIygZBkZqnDo2wQgjZcRbHh972ASl+BN/JXJJ1n0RJRkHFQ+ydi4fDCWK9mVFP99uNEbAcOQ8AK1iyJc8A6jAoqULIPKw6UQ6sopr7DukFgjd9Kc8Kiy5IMXyUUb5RzySUbNrXVFbZl6KScA4EQgQAnyFs88ZfoQTF4h4+NVJI7zSmRsKjNGWWtYU8c4lHMnr3iVtTb8U64rHwCXXKJaA3m0LuXaaQu7/swJBuUlCBAvIGHo88ZnnMb6MfICT+n3ygn/uWtttFdOQ8ru12hLPq0pWlnGfgNzRwCtB6MCAW0oijayDIfHgHadT1MA8OPjsuYj6tg0gxmfA2okFvxYyNcUANBtrCTa5DEyHkpUG2WfNAbqAeTbKfOztkD9wS2UWdODgCUli3gcefkCAAoPSuqMMDlovwut3jBSGEqJFUM9laRIzRPXOUZ9qeObbvNrU5Zs60a+AABnsKTC6vbbpFKOFKY66/lyvD59/hiN9zQcE4O0H8/hoHwfksHzKlCrL7Uaff4YxsT11HHZ2rbEiiubGYX2G9tH6RIszGNjqUtJLOvL1Dvje5QZdxlfffgIxzTw0eEXPa0X+SrvAQqhLlO2V6TG+LZEOdwsKNo7SovGDdS+RgaPWO5U15V8lQGAeDIwtCxpTFl/0Z6agDZFgVR/nynrdXuZMgAqxf+aylemnaHuA2RQUBk/KcWVje1q9wbs6igq/Xju15+ac4i2oeUbYq1KhwwUAfyMFT3dH9JYua7xG2Ms08RV5Os3poyVoQHQkseU8d3VPkq8dDGWqVJFvipjUuyEc26vbwSZuBe6Uv3DMpNi8EpbcxrglYHadG04cOBAcyu1MHMM0isg7K10vS+yAwCG94oEvadb7V0rpX/cjZ9bPhkfq3UBgIb1CgJ4v5L6a8Abn9GXAYDGKyBACx+/FBsfCZMAoGO97QniMIkM/dJanbL68dVEf8r4rFMKADrXCwiGMX4QPv/DMEybPQ0rnxg5ePCgipfRngBg9HoBwWWSXWkIGijzfKmnLwAY2GtPQBiNEfr/KbRKkaNI+xkfnisBgIGjHgkGBaFXzqjLhv4HTV6+Xsf+H3/qKk9+Y21YAAAAAElFTkSuQmCC");
            t_gridTex_Any = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4Ae2d+49dV3XHPeOxZ+wZO4kT4zhxEjvvkPAKDaKoUOgLqRAQoCLKLwiJ/g/5ub8k/0MRqFIFqJQSUZQKqIAgSsNDlIgASZw4fiaOHTu2E789M12f4/lc1t1z7txz78z4HldZ0p61H2uvvdb6rr3Pvmfu2GNrgh577DHY0DQ/Pz/03NWYODY2tqa0yTZjVwv182O5vjzyyCNrxh599NGrJR6N7awLXDm5iUw550q3r4SNE2YRO8Q6jg7Sdndd6QANsp426qPtQXS0QVa78UNflmPXhApRkuvDtJdjyGrPbRos5Mo4rLZtg+jPfqyEnZ0TQCNQmhexX143vhKGqH+1uDYu5RtrK7dadixXr/bhR+kLY2VfXq9uvOsEUNhFbJe833gp34Z2GRjaV7sfdfbX9eX4l+OdE4CBHKRB2qXSvGBb6tqoj7bbYl9TO7QbP/SlnDs3N7dmfHy87O6083jXCaByJQdtO6+NvFewSluRK/0uZUbZzn70srOfD3m8cwL0copF8qJ1cr0MqZMdVZ82Xu2+ZD+a+NJPpusE6AWOi/Yavxr6y0DQvhr9yn40sb+fTOcEQLBU3rTdb5E2JIg26pPtNtg2iA3ajR/60m9+fuYjm9tdJ4DKVTho23k9+JV6B1v7XrppsJAr/S78aY0ffezsmF36lNudE0BplC4VrLrxJQypC1Zdn8svhwt81m9fB9SlfGPxHr5kndpY1+fYcrg2Z/32dezDj9KXOmyyIXXjXSeAwj2C4HDHiE5HdyUb3qTePXu4FgFyrTC/E6+OtghWVyfBq5PrTPijPrrUvVQ9TR26OpAfdfbX9WVryvHOCcBAzqhB2kmpgWrKs23WnWs78y4Q04D9BtC2ImHiPHrn9THZrEzm2tCU57nWnWs789I+x+xv5Ie+OFmen/H2ZZ7Hu06AMigDtHU2c+p1BVuyXLZt0HoOGHNp15Wu5F6QQb6kiGl1MmT76nzI4+iwXepr2h7Kj8DHeV3rLPjQ1ZcbebxzAmSBAetjC3b0ChSvpHqNsdSwwdP5OsDpm4tSjrEefawJz1TZEb70srV1flTZutiP7FPfetcJ0Fd6sYDg5aAZKHhdQVYZNGYdtPuRwGUu2PC6giz9Eo8CE9c++FXlx8IJgM3GIvvSqD7RSGppoTJogr42plGHW7fNnGGSQEczF3D6ZqPQhue64Mu5AKojRCu6Kv0Iy6tkhl92Y7Cfy0mAHDABFWg4uillXRkTIOvpZ71OwikAChfsSwt1uHX0My51ksCOBa4d2GWilrZnn3r5gTp09SN9kGMXxeTNPlDv6UdNMvdbuzM+bAJkB6kbNAO3LvrQDc/1HEDnMN8S1YqyfjoIEpQ5dYHPQbsY/RQAgkNZnzrot+762sRcSml79kcZOPOZq56odmiptVmfksEXeLi+qLdOV/bBemfxfpWhL4GRddko6hl8ArU+lcmFukkBJ3AGXF3R1QUWbUjH5ASMegaegF2IQtDg56MICn3IW5ifyfW1B9u0FV+0X58c6+UH+iD55dbln/qgLfBefuCDcVJXno8fZf/lVRr+XIlLIAYIPgGhECiCRplaKDmIymXn0KMzUe2i7DT1vGMInjuFgBk09SHvHOvRVemAQ8rCsy+Crx/6VCaCc7Ie9cJL0g7tMgFMXhM4xwcdysNZE86acCjXL/f0+QkQg1J20jrGUNDn7idYG6NsSMUAIkPBQYp6olrrhA7CKQSMJPC4JGAUdGKDOqPalSzMyYFjHGJ9fWBu6Yc+kMzUl/IDPeiD5Nb1gzZ1Exk/8Ek/zkbd+Kgvy1uHU1gHPjANkwB5kTJwBA/D2SFVsL790JM/jvoVp0/98s8/GIsSYJMlc4ExcPDSF5MAsKfCj58Ev+IUfnw4FgVc7Ldkv6K7sl1faDem5SSAQTNw7hx0VkELzm4ZFWEDRyr2YJs7HE5ACaKkL8roC8lMQdeoiBgCPL54MdRO7R5q9+MQigYhFoQyp65B7hrvAKNMAJ/TAJiTwKCVPtiPLySASaCe6BoJ+cjBjuyLcdfuoYwjMMOSC2uIgUMnxSQYVv9y52XQsS3bq2768u7JMvoDX06cXGtYzulTgo9N2Sd0Y7u/88g+0d2TUDIoVQulSQYt7xoyddQJoD0GSq692Y/cZx15inqSy1e0WpcA2KSd8qGMwsFhyEXlBteAeQqQCKMidkHeCdbl2S775IxRzyXLX8k6MaQAOvHNsSb+yyKULZdyEmggxpIEbUgAQcRPAZbT14QGlW+is6kMMXRDlUlg7JvqWiS33ATIGagxOQkweFTEZ2pvztyiufWbDJlrn31+xGKOt270jIoEnfgSW+Oc7anry+M96ytxucmLW89J0HPxVR4owc9JwNLuaoHPvC4JVtncnupJgJwExljeNXHxLzm7hhc1ViIBVKpBJXf8SvNzsWDdKQC4ngbY1A94dPB6eVRUxpN2T+LbPoPQSiWAqw5kbDY03nh9K9q8AqUAngACgK982cW52I8MxXno8PcC9HMaOE/Ao2vRKWByKMs8dt9E2PeR4L7a9pUwn3Qo5TPaXUs/deX8vQhvFj8V/U2oLqb2NZm/pMxKJQCLYFSmsp3H6uqAdibK6SgmgiDm41xwAMsEYJyCfE4E2nmuAJsEcIkxHl1w1vD5D4Do8fkb1UoGOdc1AZBBXm6/NjAnrxnNxtQonlfyEbCUQY7Jm3gJ6ID/ZhQTgcCzqw204MMFKoOFnKdB5oDpXOYJRAkG/disToAUeH1hjrq0C9Dd7YIPNwH4LI8Nrqeu6OpLWTbXnVjX51hfjoErTdkgHW6yBkB7CpAEngQmAIAaeEG0LXenCYxtEyADr21ybKRe6mYuAKPL3Y2P2U/iyDzHTRztiqGKHF+NuFcLjOoOsODfspgJAPCUN6L4KAB8ACCgACJImRtswYZbd0x5gM7AR7Nq26+c6wkoXPBzAiAPqMhnWdeN7ko/CUBZtfcjV/IRgFMrSYDMkU8ReE8Ej3MDKkB1HBn6lbVNnwALvjyGKmDzeK86slBOhLr6ZanuZM02OT5SvmpH0RBemQCcBJ4G3AUoJoA7WjCX4oxZAFNZgY2uWmIcUi7zyyN//Anw47NjsxO/vWXP+ycvrTt378u3/SH+aq/UwdoZfOpNSV1N5QeSa1MCEBQAzs9vgTc5DGIGNgNEPQOd61luqSDl3exxzrFNrCgc3/6ia3JubG7q2Zv2Pbhv6ytfiv74jvb8V+95+bZn1s6Ps7a6fPbTbhW1KQF8ZpsEgE4y5CQwSUqgCWoGmDqU+2xXAz1+CFjmJIHP7kUJsP/6V+/e87aXvzA3Pj8dcmO7bzz4xTPrz/3nO/ff+dP1s+vwBTKR3kqAy/Go/emudpdnTiBzu1cCoLgEP/dRr4jb8sKFSbABibqALwI7xvhyBoUXQtPHpk/e+Nz2/Z+7NDG7NdoVzY3PzRzccvQT8Z3pDe/ed9dP1s1OkMTqbN1J0KYTwATIPINO3URAptzdACD4Zb1s+2dh7sicBO5WYpOTwLd4VQKcn7hwza93PffFM1Pn7kF5pvnx+cmD1x/5+Ll152949767v7/p3EYus6xhArBGK6g1hixEI4NqIthXgl62lZMb4LJd9S98XnbHCzoAZdB5geNr32rXR3smwN/yvzt3P/zm1Nn7om0SRbWbXtt08k9+ecfvP3N6/dlNMeJjhLV6zunWsPqtNiWAQJU8A90vKcq5tCsC8IUSbNGfgNclAJe92gT43Y6XPnz4mmMfCRiXBnJszcTJjafv/5+7n/nsa5tOvC30vXUCXIaj9mcHrBjNdYQF1onV+AKgjpVzlPV7crSroz+e/QBHqQPeG/6inR83/k3Pbd/3UDzjPxrHPHKN6I2pM3c8u33f+xeEl06aRhpXTqhNdwC8Esxcz8CW41UkFnZ0Va/7UbwdE/xeCdBz5x/ddGLnC9sOfXJ27Sw3/sY0eXH90Ttf3fHrmNAq8HGgbQnQOKgIFsD2m5uBz+ATg/zcX7TzY3zmtZkTt/5m5/Ofv7Du4vX9Fsrja2fXnn7Pvrsev/Hk9YcX1slJnEVHUm/THaBJAIbdQXleBt+LGQmQj36SoHPpu7D24rW/vfXFT55Zf/7mJkYqs3Z2/OyuI9t/uP3EDa9En3cZuWIj5W0+AQDKkoNEH7tInsfq6shBcBJenm/8XPbyhY8jfoZyfuLidU/ftvujJ6bffCDazWl+zfzNr2/92dsP7fpVTOIjLMCzNoV2K6jNCVAGiMBJ1L0b2G9bGbhjcAtJkHd+frXrS55q98+tmZv5/c0vfeiVa1/7EMoa0/yaua2nrvv1/Qd3PRWvhPm9BoR9XjpJhlZQ2xJAkOqAo48AGjxl64A3uFmPwXfnl8c+oHeO/ajP7N16+B0Htxz5i3jN2/jGz8LT5zcceOeBO/5r6uLkyWjy281sB3VfEUd1tNSmBDBIRsQ2PBeTAL4U+FlPBt/dn3d+efGbPnjdkbt/v+Olz8ZrXh4FjWnD+cmXH3zp7m9tPjt9NCb5+wzt1463HgE9Imqg4AYLLmhMA3TGOQmomwQlj6FO4qgLPQLPrl4EfPTNHJs5ecuzN+97+OLEpWuj3Zi49MWx/50tb24+FJP4Ugs7vfxdADa8lQARhJIAFeqVBIAIyAQQjhy8LOqJoY4u5jCfE49CEnjxy8/9mfjd/uanb33h0/Hy5vaQaUzjc+Pnbj9y0xO3HN/2XEzyiyz+7oL1Laz9VgLURBbg8k41YADmbmecftr2kQC5TlsymdDBPHY9AOSd33nun5u4wI3/b09ufPO+SJ2cSDGlN43Nj126+fjWJ+N7AE+FFDvfbzRhF2CzJjaQEBT6W0EY1RYSLJNAsAGOAEL0ETwBL+smA7KQSWUCoMedTxIIfvWxb/eNB953+NrjHxgE/Dh/5q89PfO7OPqfXDc3cSp0kgB+o0l7tNcT4a0TIIJUkmABMoABFoEieCRBL/BNgsxDvHo0MAe97kBAJwG6gOcd/4tvO/Tgnm0vfyJ+n49MMwp4N5/d+ML7Xnz7NzdcnDwWk/w2s99tRA9JoG/6g62toDadAIAF0JYyAeh3R8kJpEGFW2ecgk4KuiiAzzPf5z47f/rI5td37d5+4BN8vSvajSlAf+Xel3d+d+OFqddikuBzAvgtJoAXfOzPNkZz9NSmBMjA86zm9gwBYAlsmQCM5+M1JwAA+Oxn5wM+H+2qcnz61I7f3vLip8+vu3hD9DWm6sZ/YNc3423f7pgE6BS+wMrzH9u9/WM/cRZ8bYuu0VObEoBAkQTYxG4FNMCjj51eBe7U1OkNZyfPT247ueV49BlUL1dyEwSdFHRRTIDqmb/wmvfT8cWOnTHWmC6/47/pu3Hjfz4msfPd/V7+TEaT2raPKexrBbUpAQhWPqoJFm2CV9Hs2NxYfA3rC2fXn7/17Qd3ffm2YzfuiwF3PzvOBDDQdQlAEmy6ND57ze927PnwiY1v3l+lWbVCsx83nrj+v+Pr3z8LacFn51O4/PH8xyaTNqpV3fZbJwARqaG8+w0WnGCOxe/itzx96+6/f2PjmQ8wNz6u/ePpqbP/FEA8PT4/7hs3j17mUUgAThGe/Z4A03Fx3/TMLS/+eXyj968GAj/e8d/wxrW/etf+O78fN35e83r0w9n9Xv5KkPWn7I8po6W2nQAe/x6R8W+6z6+Jr1Nt/c3O3Z97c/Ls/YZrdu3cDfF17C/FTn78/oO3/zx+6ULwTQB3oAkA+NXtP37BM7136yv3xzv+D8e3ejhhmlFYNHN+w9537r/jiclL61+PSR777nx2v+ujEx88gXICMNYaalsC+BggQARvzaEtR2+KS9rnz62/cEs02c0dile1W/lOfvwxxsx9h3b9Yv3sBLuQ04CAVydHcPSQANUJcHTzCV7zfvLixOzm6GtMUxfXH37gwO3/fs3ZmVdikuB78QN8io8g9GIrNhBjd37m0T16alMCAJSXpojY/Pjz2w/c98K2gx+Pb+Fs6xUqvpsXO/rTZ9df2P6ufXf+KD6aAY4nACBQAH/d6xvf2BbJ9HDc+Af8Vs/4mQD/m3Hx3BN6BJ+dT8L53PcOkhMPwFu7+8O2KjvhbSATYCKO6fEXbjx0z/Pb9//dpbWzfKV6SYpf104evvbYn82PzU0/+NI9P4wjGlAyEOvm1syvD/D/5o0NZ25dUlkxOD43dv7WY9u+v/COn79YNgF87rMWp04+earTK/oy+O7+6G4PtekEcLeOPX3bC+/bf8PhjwJs01DFY2AiXuM+9LO7ntkS38F78tozm7ikVTovrr00FeA/eGzzyXub6qvk4tK34/jbfvTOOFmiLfDljd8LKMe/gLOudVQBfivJTG2TcWPxvD2zdm6c43VgOjH9xu2/uv3Zj53acPpmXtPHzr8u7gl8seNdAykL8K9/85rf3Hto54/H14z32vnu/nz8+/hxx7cWfOLRpgQwYHPx0e6ZBw7c8Y11l9Zy2x6M4rd4ccxve+rO3/31q9ccv+2V617bGb/keTA+NXAPaEwz5zbsfc/eux6fvvya1497+cbvpw52PqDXAd9q8AlGmx4BBItjcy4wnN352vY9cQp87Q837/3Y6alzO6N/IDo9efa6OAk+EDpmeQQMMplv9cRHy29vOjf9aswDfI9/TiUK4Hv0s/sru4NDHP8Z+FyvBNr0o00ngLuIHVV9no6L15537bvrm9PnpvZ2hbRJBAOG+Jg4GR8fN1aQNJkTMvGy8eJ9L9/2+PYT178YTYH3xl+C73PfBADsXFy1tUnQ5gSobtbbTm05+MFn3/3V+JrVbyK0JMmqUbzjP3fX4Vu+ddtr23/PkyQWcvebAH7kc/d7/NclAHa2FniD2LYEcPcTYI5ZAn42Ptsff3DvPd+Oz+FPxbdvVicJIrnir3d+etfhHb+MNd35+aNePvZL4EkAqPWAXzbzjz+vigQIc8/E39gf+dPdD3x7++vXP8ln8z+6sAK1yzf+p+Pj3g/iX/UoX/Pm3V/ufJIR8POxf1UlQZsSgEDmE6Da/dEHANVRzLEcJ8ETtx+5+T8m4m/uon/5FHBFcr3EjX/q0np+xYxe1hT4cufn3b8U8FdFIrTpUwC7KScAgScp6MdOymz8kyuX3n5w50+Dn4uPd5+KN4X8bn9oin/Z6+h9h3Z+Z+HGz9Hv8W8C+NyvLqYx7q7PO5/1uf1fddSmBBDsnAgkBMXfEVQya+fX8q7gqY3np07En259Jr4gsn2YyMel70x8yvhafKvn+ZhfBzxHPkU7WN/Sb4fnhMj1UNEeatsjgOCWp4CPguoxEOPczquy4/jWP7xn793/wuf2eAr3A6Qr6nyPP97xfy+BX5cAnEJ557v789HfpbdoAHxrwcfWNiUAQXV3wfNJABAmgneCN+KLIKfiY+Keh/bc95Vrzsz8IWSaUSRLfM7/Sbxt/FFMyK95PfZZr7zwYZNJJnc9ga7jyPTqd/7IeNsSgMBSMvgAASAUXsRwEuTT4FS8s9//3pfu+foNp675BX+kEeO9KW788U7hF/cf2PW9ibm1J0LQBBB8Eo2SEyAnpuCXoLJmrz7GWkltSgCCJ5kIcE8Dj2KAyadBdXHjixrv3XPvv0YS/CxSiASqpQ0XJvfFt3r+bfrChiMhAPje+kku9JJorEUioUdboroIYGwmhhTuKdb78exrTBsdYWibyZ3nieBpkBMAAAHy1MaLU0ff/8ID39h1dPvX45UuMl00eXHdgQD/y9ed2XwwBvgrnip5gufdX7fzyyToB/BS454SXbaNqtGmTwEEzV0kp8+AuWsAw4Rgpzoe1TVzcaxfesf+O384OzY/+/KWow/Hx8QtDMTLo9N3Ht7xlXjb93w02e25NNn52AJpR+baoN1815DYyqlTGLdEdfTUpgQwePK8izgJIHcibY5oAk8fZN/F+ILo2Qf33v1EfK/gwJ5th/4hvk4+E/9Ozz/fffhWXvP6COGoB3iKJws6KZ486hbgzEOsk3wmKhz7+4GPTCuoTQlg0PwCJ98GEgiTQUBsAwgk+NbXxlvDC/Gu4OfrL00cPbbp5M74vuAPYpCjnlPDS6XA+8wX/LwOOgU+r0s991M3ed35/Bqagi8UfWtN3FtjSASHoFVf3kyB4qinGHiAAWyCLQD0IQNZr4CJk2D+rldveToK/0Yf4AI0BeAzL3d+DHfAzcCypiC7vrZlvlQCMEZpSqy/atSmBGCHsFv42z0ABWgDLnAmQAxVlBOhAj16s4x6BFg9cpPCk4a5kLpc32M985wIgm+fp5k7n9fV/lmaJ0K10Kh/rHYCDJK9JgC7U0AEQMDsJ26CleuMmwCATxFkObpMCLhJwlzthbM28bG4q+WAnUtOAueYAIBv+X+fAHXAhP99Ke98AeCRQBAFDZAAjDUsJoVjjCNPOydDBt06suqLakWuDYge1z675Y4JtImaTwDGlMc3EiCfBNEcmHJsB55cNwEjh6WljFlqrNd67AxBc/cBPhc2ABPUEnDa7mSf7fQJrHVBz1xdIV4R4FPc2SQAILpr3dECW3caaLtJ4nx0mAQkxErRMLHurL2cBOgoWaiUhpTtUr5sGxQAMHgAShE0wZS7g0kOCvNIGAgZ5qEPwh4Bl9NHUQbubtYGQAc87JObCJ4QyJo0mTuuPDosUW1E2giHbF9uFT/5h7MHoYlBJ/T4B5pL4zTS/r42xf+l+5m+QgMIxP/1+5chDhhEhKJNGXzq2qhcTgB2b5UAYd9Poj4K0j7W7lXv2NUDn854WZkYdEKpILUNcOYEeFTE7uP0AFDBzbbkYNKvDPIUdnU+BaI5EjJhTVbjizGlDwMbiKPLpdIg2xq+XP3Dzs/PZ5MAXXVBA3zIJPAYJwF83lcCI/hRAq/98mWZtNwEyEZQp2Cwz2aewaMifMvAY4dAa2u2TfDlzCUR4CTCqMj7DzHNyaA9+gIfmFbCMQ1wx+cEwOhRUX7+C3xpSxk0wYebQJ4G5dwr1XYz5fjWJUJlz6B3umETQNDl2TgMJmu5lfMMHhXlIAm0PNuU+8o6bUuecyXrxNBPOcQ1xzrbW9k06J2OLB+UykUNEFzwMRTDR5kA2S7r+JrrtCH6MimTeR6/knUTgJh6GmS7rA9l08CfAtIR48JwslLjMvj8zn1U1G/XaL/22c47zIRG16iIGPJuAxtyEuQTDtu0H96YBn0PgHKej5lTN2gYSMFYjOYmPipi5+SAAWYOmoGC56Ivgo+OUZ5kflnFkyD7kf0JMwenYe8ArFQGzYAJ/qgvT37RI+8cwTVwdX4wVvqynDixxnKIE6CXL2IwtP6xRx99dNDJdTdlAkThrVn57ttXn3BfifqK1CRRZ4h0PqpRx0FJZ+EC6YnD7qAQKEr+updHaHmM5iTw1o89+OFnf179+voX+6338oM7lb7ApVynT1+yHySdfgh66Qe+6QeJzRyKeqLaFTPaS9IwmV0HigYAiME0EMhjJAYbWF/SEDCCrmxUe5JBk7OmRzy6KQQnJ4LBUk471QGXGMMObEUe29ClbcgacPrRbeKXfjgnRGrJdVmTuvZlP9Av4HDWVC6Dznz1RXUwGiYB8goujiMYpeNwiHH6cQwH8s5nbeR67ZoY6iKdhBs4A4F+guM6rJVL08CpW5tLP1yj9AMfsh/RrHyD15G+DOqHfuo3etTFOrlet+6ivqETID4NxEfOaj2NyEmgMfYZuHLH5KAZbHk2Vscyp24g4ILmWgTLgJkABlybWUOd1BmH0AVhi7L6gk79yI+w7AtzodKXvJZ64eimaGedD/qiz3n+fPp0Fmqa06CfAtTM4jqnA47B7SuDZsDKHYMu9WU9ZR29ENziGvIcROsmCDIU50a1IvUyVpJzTDDAX8oP5vfzxfW0A57X0V7s1we5CaAfrMd/o6vOqt30x8DvAZLicsEyeDpHP4DjANxnfrlj+gUtplbAldzAyQ2QQbTNuDbJ0QWxtv4gl0lZ+pv4wdx+vrhW5tpPnzZnH+zLctrGmkPR0I+AtJpO0IVxGkWwaGO4YJc8hjrB6hc0ZCHXy9x1M6duQdYx7UOXpC7bWbbVfiwc/aX9+tGXD/sIUDELdy4DdgbPAaQOuIJP3RLVTgJQb0rZYeq5lGvnMeusQ10y+XIfY6WuVvmxXPBxcDmPAOZDBI3AGDzbuY96LtHsCTxydaT+PJb7qOeCXF3bfrjkJSonM3O1mTpkW25fNVj8WFU/VgJ87F2JRwB6DJaByn0EwnH6c2BynbFBqVyP+fbBc13d9tnOnETIScAY8tjZKj+GvfThUKaVSgB0GlgDZV8GOdcZL9v0DUKu6Zzc7tTdLQ0vys5rtR8LPun30HzRHYAgLaW8brwIbA4ghtmuM3KpsTr5fn11+qq+wsZFemr8UpdJanvR3OhYaqxOvl9fnb6qTz9q7O2nk4+Ki7CtvQO4yFIaG8h0OVHK5ySzXsqU6yPXR6ZrzTy/31xtyHMW6l06y/XzPOulTKmzny0h37Vmnu9c13KMNcs+x+C9xod6BPRzMC9sfcHwno4pt1p8GJvrbGmLH3X+1PVlH+rGh0qArLRpvW7xpnNXQm4BuGWraosfS+327CT2ZtmyvegOkCdTLyeU48rU9ee+lQIg6xyk3g+4Jn6yXlv8aGJvnUxOBvypvQMwkKlf8LJsr/pK6Oilu0l/P+DKwPTS2RY/+tlbB36dT1fsEdAPgDrjVrJvpYBrix9N/Gkic8USoIkxKwl4qWulgGuLH/1OgNL/Xu1FdwAcXEp53XiToKwUAL0c6dffz8Y6v+p0tsWPpvbW+ZD7et4BcsDqnM7jWWGv+qDyvfQM21/nQ9bFeBNqix+lvdiV+/q19bX2EaCTWSETyrZKmnDmqreJ/ErLrNTabfGjzp+yr1+bGNcmgMFvokDZfrzU1U9+pcdXCri2+LGczZhjW517jz32WO4buN40KFkuO2A9j9cZMSyITec1tRovXAsAAAAcSURBVCPb6RzstZ7HV9MP16tbo0nfI488sub/AIqApiiZyEzqAAAAAElFTkSuQmCC");
        }
        void SetUpTextures_Tile()
        {
            t_tileTex_Delete = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4AeWd+69dx3XfecnLS/KSl29JlESRekWSbdmWaEuOnTi2UzupGwexk7ZJECRBTaEBCrS/9O/oL0GBtkjVoihaNEnrvA3YadrYaeLYhiPJkmXLelCkJFJ8ie/35WXXZ/N8jtcd7nPOPvucc+8NNMCcNTN79sya9V1rzew5+zG1akJh//79E2r51mZv3Lixampq6tYDI5TQHu32C8P0m9tqw+vTTz/dj5XWx1a3PrPPiUsJfh82Rj7UBKgM7KAObW+Yc2xzUjIduwJMilEFsZS0CVCC2oQv2xvmnNzuJGQ7VgWYBINZAEudbgKUoDbhzfY4Z5jzctvjlvHYFGDcjOVBL1e6CUiC2oRH2+OcYc4r2x6nrMeycnrqqadKHhflHfiiwjFmaH8UgdaxYnv9ePeYdevasUwehznHc3vRcSwM1/RqvGn5OLWxaZ919ZqAUHderzLaE6xedShv02+bc+p42Ldv36pnnnmm7lDjspGmgJUCfuPRDlmxCVBNlMRubY9zhjnP8+voqBi0VoBRO64bzEorawKSoDbh3fY4Z5jzBrU9ChatFGCUDgcNZiUdbwKSoDbh2/aGOadJu9Rpi8nQCtC2o6YDWUn1mgAlqE34tr1hzmnSrnXaYDOUArTpQOaWmXK1M3RsApSgNhmf7XHOMOc1ads6w2LU+DJw2IZlaCkowlS4nf4GjavX8f6b/6tWLTpe02/P4WbAC157njPKgaaXiL0EsajvQdf5iyrXZPLgaw6PWjRVAFGOqczTX10Z5YsApiBCWdbNd8Z1owmg8qgsmpxzs/v2v02UoJcgur2uYMvPvA9K5+OOra6sC26nknkpxU3S9tGlAk/BUoBvx4OUoE4Intt6ZdltYPyJzK/pTHul4SQf68eZANfRXJbTtGe+TFd9lR6AwqVShH5KoFAqJvPPCrP8zKdpaJm2TMqQTOe6eahlWiChRuqYLmk+ZhpKoG4VlssD2H8vJVAo1qvoCgJf/jIl3StyVeOxnLZM6njJEwQq0xLohU49ynO6rGd+UbulB2hj/bZBw21CnRIogG57KwT8zFcGrQTVPLRM57xtlNRxAxpBmgE2DTVSr0wLPOUE81WbHQ9QpduAf7PJ0X9LJciCXglzvvxkmkHLoAo6f2gNSnsebZEm2MfN3M1fQQNE0oIsvd4pk1Ke0/k828rU63/KWq8BxukJukJYAZYvL5mSFjxBhgo6tF/MdXM7tGs/kexavmAJeAYYoPvFXNfzaY+07UZyUV/klyXoCSohjHKd30QbO+6v30AFQ2CgGbA6wKejDuVQY85nxciKkPuIUytFECCpAJaAz0d9yqA5WpbrZ4VYkYqAEkwts+Vn4EOmXdBVgBJ4gZaujXNIQ017TFoqgopl33Fq1yq1VsETUIG/FnUFnrR5qces7/kqVFaE3C/lyxIQ0nIFAYAaAceYgRNMgZbORH3SUsupT5o2SNuWbdtfHOqGDA7AqQQZVNICD73ayUs9Zr06RaBvFS2SlfJRtixKsFwKwIAJAqFVQgVL8ARTkKHEdR1qXqoSrN165cqWPefO3bvtypVds9eu3bbp2rVd665f3xbnTa2+cWNm7Y0bs5FedW1q6uLC1BQg3riyZs2pi2vXHjsX8fS6dUcObN782rmZmXNUS5G6ZbySyqjrWEg7ThTLgBIYAH9ZlGA5FEBhMPgMvAKDJ6PWLbiAXher4wHuxodPnXrkzgsXHtl+5cpDs/Pzd9LJoFApQkcZ1i0sbNt87dr9uzonPXHs2KqL09NHTq1b98rbs7MvfX/79u+FklyIwyoAwNdFeKcOiowS6EkYv95FT4AC6AGkUTT5sNQKwOANKoLAlxaPALVy6PpOvCX93pMn33f/2bNP7Lh8+QPTN25Qb6wBRSLefeHCxx87ceLqyfXrv3tgbu7bL+zc+Xx0BPiXO9E0vFPGmBwfyuD46zyBXiCqdZWB9ETDUiqAgEsRjDFbfAYeMAF8Q0TS0vVrFhZmnzh69CceOHv2M+uvX98Rx5YkrImp4/ZLlz5M/ODJkydf3bz5z799xx1/c3316ovBwKWIKi1eCSVgPCgGyqBClNOC00G2/pyOUycT1nBn6RIENR/ASQu8Vo+QBF7AAZs5emMnbgpKnPvAiRMf/tRbb+2/++LFj4bFV/N4lC95oO/bL19+9KHTpx+L/6QvHZudPR1MCDRUZZfKI/kSYPNQji9JmF6CbUn+r3dA0BJ8rN85Plu8CiCdffD06YceP37888zRSyKdhp0wPTx57NhTj5w6deCZ2277w1e2bv1hZ0wqNjQrBh5BWegN6C17AhVBxeD42MOaxx9/fOyNpgYz8KQRAgqgMATeeR2widnq52JRt/cfvPnmb7z31KkvsEiL4ysywNu95859NK487jkzM3P0/MwMQKvwyqLkvQS4zPc6r2ynVX6SU4CMQxWCwGerzy4f4Cs3L330xIkPffzIkX+5aX5+d6sRLsNJ4RF2xaL0x2NdcLwzLSiDLJNBnGVF8LxB5wx9fNIKAOMOXssHfFwi1p8t3/leBZj72JEjn46F1q+H1lD/71WIwU7HVcO+2H+Yf2Nu7nAwryzKcQh0pqbLumPPT0oBHOwg8LPL7wIfK/zNP3vo0K+GFX02GqCNv5cB3ndevvyemMJ2vrZ58ytx86Dj6CYsCAroPYFv8H9Kaqp5Emscd8iDI03M1q/71/qz5W8Ki9n52YMH//nWq1cfGgdjIdGF2NU7fGbdusOxgXPuUsSzMzOnIn86dvrY4VsVO4ZzW65c2br56tVtcUm5OeKmyN81d+3aXcE8vI8U7rx48ckvvPbajq/s2fMfY1dRmQi2m0FSFUFKff46Jk/a8ygeOYxbASpmgysogjMy9+v6Bd7VvfP+ph2XLt0dlv+vNly/fkfUbx1CkvOxc/fqkY0bX/rBtm3PB9hno7G8L48QXXGvujQ9fTTqwnNeo0xvDqWIlf2jAeBD2y9fvi8Gw/FWYcvVqw/8/IED//qv7rrrd2JKeCUaEUj5kFJutC+OjR18Gh+3AtAmjBpRAMFXAfLc37V+LH9U8C8EkAH411/atu3FADXv3wM+l1sI0j96spDhMytAdfl2dt26S9/ateudOPat9fPzW37s9OmH33Pq1EfCM7TaeArF3vlThw//1p/de++/Ce9j//BEGr6klFkOVZ6RrAL1xhLGuQbITNZZPsC7myfwc1E2x5z/86+//i/m5uf3thnV5fgD5/vbtn3lK3v3/s+3N258fX716jPRDvv1RnbpcmSHjl27vIXLJRtKwpYtNCvMqmhzPlb0p763Y8dLgcjlmKJ2rF1YYExDhdg82rD7/Pn7Q0mfizWBIAOoaSjB/M3cjzwGdZH1WMIkFEBLQgmweiKCygqw6DqfBV/sqA29ITE/NXXl5a1b/+LP9+z53UObN7P5cj5FwYdm8AE+g48SAD7AZ/CdMgSEcVWKfXTjxrMvbtv2ehTciPXDtgB1qKmB/YJdsTB8OTxVtEn7vWIcqo5Bx2b1NGYYlwKokbrSDD7u1Hkfyyey4q9W/VzqsdqP/FDh9MzMgT+5775/H7tu34vrbSwe8EvQBTsD3gtsAYci7GxpALxoTGG9a2PdcD4s+eiDZ87cNbOwMNR0Gvsad8W0dyXWA4c6fakETgXk4UG6SAHYwR1HHIrpYKZfQAm6VhJpBOb8rwdAEbqXfrHJ83gssn4pyoYKh2dnv/PVPXv+VwAv6AKtS8/WXAKbBarilgADAtFQrQkiw7RAe7a58NG3335w4/w8U9vQ4eHTp38hFqjHXtix49txsm1D6VuqQsp31c+4LgvHoQACnykCFXyEhwJk8Gfj2nj3h44f/2dxEorSKIQJLMRc/+Vv3Hnn1+IEXTtUBcC6tXAF2gUrjilErUmeVQDL5T3X91g0U4WpT7755mPxb+ReC4aljP1Dx4795on169+OtQv8ElFeeC4VQM8AH/IF/yVfUdQ8NBZ+wyZhiDbrrB8r6S4Cnzx69Bdj7mxsOcz3f7tr138N8P9vtMMKn0s7XD/USDlRz6CSqCB6CBVFZamb+/UCCjua7Yapn37jjScD/Ae7JS0TyOAjR49+Pk5natQ7IheMBuPBSFVQ5KrSQkcOoyqATGTgM/i6TtcA1QD5Vy92yD7YlPtQ8YX4z/1/vLh9+3fjHEEWaMF2oZfne6eCXgADbgZY4ZZjAATHsvbTb7zxifvOnXtvU/4H1UMWyCTqIR/AR17EOiWQx0yjarswqgLQa2aEdCk83b9KMMtfusOwi9uvAV9FyAqQwdfKS/Bxr8QMvm408+80kMGf/syhQ5/Ze+5cY+VtOs6OTLIH6KUAyBc+xxLGoQAwohIIvsLL8z+avT5u5nhsmP/zWfClOd9VvqBn157duSBnN54tXeHBLxGQBVqFhV8A6brmnzl06HN7zp//UJSNPYRM7nt/LIqj4UpOQesUwKlAeasI0qH5GkUBMhOm6wTKQCrr5zau973zzueacsmlHqv9qA/wgG50bsfta/VavIuprASCj6Vna4dvhErMygq/WmNFf+bgwc/fc/78k1E+VIgbSll3NAqPvvPOz4WM2CNxGshTAAqKfOFZGsnRvMEoCkDnhBL8UqBa1Dru4ePumZun9f9l0Rd/nvy3zqUeQGfQ82Iuu/heFp9BZ8zwqMUDfKWgQbV4N6oq+rMHD/7SPRcufCSODxVe2bLl4B/cf/9fX4tdxCYnIpuQ0ceirkYDVQmUK1SZQ0cKbRXAjjMlLZO1LpUbOJty++qWLX8Zd9Scivq6/bzIy1avAmSLz5dMgk/X8KgCwGu2+uzyuwoQ4P/j3RcufJSThwlxs+grX7v77u9cnp4+E7uGP2h6bkdGKoDgK094hn8iY1H+kWwX4vmIm2+sGpZGd3YuIzIGk1oXA6git243vXuXvf1v3XHH/4tzdfF1cz2uHtCz1WcXH4eqAH8Z9MwbgtbqmesBvrtLGeD/0wAfixwqxC3jL/7l7t1/FSdxeXru2Z07X4ipgOlrYEBG7zt5kisMrT8rQZ0CKH/xGNhHrrC67XZip5HceZ0CaGEz3LefO+6XfnnLlq9djf/to47AS3H9LvbyXI8SlKt6lKHkLyunVqblZ/A3tQX/4Nzcc//nnnv+Ivru7k3Mr1lzJq5kno2yRuG+s2dZa2g8yLD0AIxrLF6ARkYJClhmELCxa2k8scNDG0064i/d+Av2b6OuYEtx9aW7rwOdbhSQSqkAFSqgE7PV889k9f9EgP/LbSz/0KZN3/nf99zz5WiHDaq8SXX+2dtuezZuTDkZ5QMDskJmURHwjcoVqrwZJ0F6MzfEb1sFEHg7zwKHQQVeMc/jWk13/fg/P87HygHeSL60/Oz6XeVHtW6QRwWnILV8XX+2/Lm24L+xadO34l/JP47eBV7a3bAKL/DNLnd9EsgqZPaeqCLPylPwVQBayeDndJ8efnSojQLkThQylLaIWQEqL8Czej/qsncqUJznZo6oIeCCPsjybVR+5EXBTdTy39i48ZtxufqlYEK3L82bVRfjr2vuJUBxB4aQ2cNRaZAClFgMbLesgIBGCaXAtTaVoBoAD2o26YTbuDp38ujupS74ykUflp9D5kdeFOJELP/NjRu/8dW9ewGfqxUVF74Amr6RMfkbcUWw+p316w/E1u+Dke8bOjLzfNpwPFAV3PFC89VO37bzQRpqG+jUICMypgKs4RHtptf+3MMXDQJ2Bj6DjyArYQYtB2zfUARGnKjlB/h/E3ch/X70g8Vr7br8usvXK0dmZ38YdQcGZDZ39Sprkgy+Y1Te0oHt9apAg22C4MsAVOaypk7zfH6TDgLNBW7gjLqu7qXl9X1WApvOfNj/pC0f8H8vGCjBVxHcrs6XspdjjC8wVhnvR+Nq4IE4rjI7LuXsmGmCdKswrALkjkzLCFTmoBXDvJyhCWedW7cRpoBLey32cv/2q7CWwvJ/N3h1a1qK1Qu4C1hody0TN5qeYaxRNjB0ZCfwUMaZ5W16YFu9KtDgKEEGMu2CHw2viduebmvSAfftRz1Azy4f8CnLVo/r1/3bb+5zKSwf8LV0XX6txUc91wVMa5VX64w1sv1DR3aMrS46dhsp85b3pVjMOIKdS7sM81qWJh3w0EbUA3DA1uqhgE1ZCXwUda1BK8HyUQCu8Vn0cZ1PdHdvpOv8zpwv+AKO1bs1rddSDlBksUixO2ON4v4hbjW7PWp0ZRnp3C5pQ05b1oiOqgAlQzJLeZXuvJNnIDM8sROVMvBafQk+bTlg+9P1A/6kVvvM+Rl8+MXdE3Xz8A/Y8gVFORd5tc5Yo7h/iGcRdkSN7Ppt1/Er/9wQZXrIXF6bbqMAdZ3SeMmU9SyvZcBCHteKdLb2DLwDsk1OI63l6/aXyvK1freonePhGSWQr1qF7ow1qjUKjlnqSeRHDm0UwE5LBmRwEeVtXJ7Qj8a8yNs1BF2a3b6nYwUE+oF/hL3Ulu8lngs9LJw5Xn6lKoCKAV3ojDWS/UPIDm+2SJ4p3//khkdHUYDcBUzWBl/FVnswFfqgZhRp7RwtBy/4UI5p+br9Sc/5Wr5uX9fv3F/ynhWZ8VSKkcZKWc9QyK6njHs20ODAuBSg7GrczNKe4JvW8vEwuH4iCjCWvf2aBR9zvpbvos8NK+d+xw3VC5Q0Di1ScvKDgu3menVl+XijtEJtVLlPJQdJFdPQ6iWM0EGBR7SjDoOCpxydT6EoLBHQBX5DpDPwI/+rVwN+tnzALy/t8ACVew+6aPyRJzCuboyxbq5KB/zwAstOFdvMZ1TyzQVt0uNSgLJvmbvReQNnefyWPM/nR2FXSJHOSkBaBchuH6tHAYiTtPysAM77XtcDfp7rUYQcGBOhO7YY65abRf1/Q3YoWgbftPLt30CDo22mgF5M5HLS2SIGssLLGaKS1g5fAk7aAStElAAPMGnwM/DZ8r2sA/g8z8PnLYBH2SJljrFuj7KmwfalWc5N2+hZr40C5MZKZnK+Ssemx6kmb/bizRzRsAog+FL6FHyECfh1Gz2t/8+vcft1c76XeyqASg5/OcgrdBH45OM9AUxTAwOyi0rIsQTfc5W3eShljQPMjSPIpAKRXufFy0064LUsUQ+F1MVDXd1DdffO97p8hFnFtjdz1IDfz/IBX8vPwERxFQQf2WaFVpnXxOZYIwXoyC73ZX/STpfDge5J0HF6ALWxC360z/t5ju3KPfZI806eDj8qAFbu3AqfpBWoyoASELH8Vjdw1oDf1PLhR2sDdEIGX8uXZ8ZQKUFnrNUJ/X7Or117NI4rT6lyltpEmbe8Lx1WAejEwZIm2DFUJgXuelzzHqlqDfjhhUy8k4fXskRVAGaRZaBd2oRfYp77N44R/CaWL/B5/AIPzcDLr0q9NsDfzFij3sAQN8i8HZXqFplZ5vLh94gGtpsrtJ0C7DQzIviCVSnBobm513OHvdIhudW8kCmO6/ZRAi1dt++fOtntj9PyswLk1T7K6GaP43TsDEkFyODr8lUC6NoY4/sZKycNCnyrIOp0jSnS9g3N/Vd4tLnDuxEjPRitOu0ckxkYk2EEdi08wBnet9+jjUXFvI0rCgA9Ay7YLBJJS3H7/6TN3bs1bj8DX672nfMZVxa84y/BF3CtnqnMuLZzr18U9Q/IrPOhChVPuZY8yEf/BnschdlRQgYexrICwHClBHxsocltYbyKjbdxxb1zDrKymmjHQSrUDTyrF+B/ZFjma8BvMucLvnzZreBDMaY838ur4K/bMD+/KW7yeMCT+1Huj4zjXm0gRxWg5EUM+jXX81gbDyAYNGrn0Ax+BXyUVfTYhg0vU3lQCGbW8Cq2qJdX+Fg8GyfGzfGU7hfaPKtXA/4wls/4chD8fsA7nVU03P97o3Ijo4uvk/wgOkMBSiWADxWxxCLz1yjdRgFoWOBzWsbUVJXgWrxa7fnrN7/JM5Ap3sMXlUoFQAmqGM/n/0Kbp3RrwMfyswL0m/MdrwIXfC1fJdBjda0++gB8prV1ca//J4IODMiKT9NExawAylU5y4uUdnN6YD9UaKsANk6HRDVSJgFfBbgaGxoX+MyKJ/WjvITxg8ePfyDqON8L/pZ4M8dn2zyfXwN+Br7XnO+YHKNsC76g4/ZvcfdRlhex6z989OiTcYfPHTbSjyIrZBZ1VAC9gPKVJyhBejM3xO8oD4fascyomTAp+DDOCvoq39jhhCYhvguwb/XCQl78bYl38ny6zZs5asDPlg/42fJLQWclgPUMflaAbPlavFcwG3gvQrwR7FNNxk6djqwquUVWnpApslXOJW9xaPgwysOhal0/BXAQV/nAUjz1e7IJi7Fg3PT4iRNcEnLZNxdv4/rJNu/k6YD/e9GGf+NC+YetH/AK2PFF9Qp4ADfmS7zs7rugR12uZKr9ingJ1Mdjp5P/OgYGZJQ+RqX8VIKsAMo904HtlxUYUJugcDIlrYtaNAVEefX3KR9YatpZLJgembl+fcsn3nrriTZv4wrwv8GrY6M/3L2xVIByb18B53HBcrZ8V/rZ9ZdWD/hVjJX/1gfOnPkpGmkSOjKq5BX1UQDBLz0APMpnk6Zr67RVgNyYjGg5KgGMq8EM6DJf12q6JxAWM/OLr776E/EWzr25syZpntUL8L8UdQVcq9fy4UfBZtCzQAEd+WTAcfVErL5a2Qd1V1LQWcAaZ/l/It4iSn5gQDYho7+OikxLKgF8EpVrdv2Z36gyfBhFAQQ+U5UgewAHcjle93Lxhe3b/6wpm23ewMlTuvGs3h9EHxl8FICoYFVM+ZRvBZotXiUQ/Lzg0/JVAoGv6E+/+eY/2nHlysNNx/u97dv/FBlFfWVW8qmyqgQ0Lc9Nu1lUbxQFyA2pBDCmpiJcvYADuvT8zp3PnF279kA+eVxpns+Pp3RRMPuTZleqEOW5Duw8x/cCHIvPgLNodat6Y7z27cl4tOsTTccWMnntuyGbqO+iFN7r+BZ8+acL0q3COBRARmRMJSgVwIFd4tNqrbjtcxJv5ojn878aVQQ90yxI+EIJstAGKUG50HOxpxIIfLVo3RtvEP3giROf78PuLYc6MkFGeZrKfKu4yvmWNtoUjKoAClEKc1kBVALAcHCX+K5evB/3uTYM153DO3nizRxfj2NZSApK3jLIveb1PLfn63hcfJ7jK6CjrNyrmAP8+CjEb/KF0Tpe68qQRedbg73AR47KlvGUsa7ZRmWjKkDuRKZkFDCcAtDkrgeI9MVv3nHHH8ar4CgbKfA2rngnzzejkdwvfasMKgD9oASMWQXw+j27+V5KoLXj9rV49yoqGm7/x+OLpk81XfRFO6uQQbwQiwVr3UJVD1COR1nTxEhhXN8LkAmtjLxpBE4kj+ArykcVY8FznE+rRQFlQwfew/e13bufjRMRlBGlw2J09XqCKKr6KRUgK0F29eUCDy/gnK8H6NJY8H0uNrB+LhpnjI1CoLjwd7ff/p9e3br1+3GCu5MsXvUEKkA5FpVa2qi/ukoMflxBrUTgAKrWAghCQfBYGmnodLwn/9m4QeKPHjl9+guRHyrEJdPl8CKvdE6iP9ovwaUfQFUJPC5v8hxVKp5tBx6JrvxLxXDVv4HrfC71hlnt0xkhFPhPY+H3d5H0KkXgXQDWKfLIoFedd37G6QGyFZvOVIAUMvkpPqoY/5HvjP8A7s6MDUrH93qm44+jPWuvX78R/za+s3DzbZy93L6AVooXbasYXssz35PuAttJY/Gl669W+3znKD4W8amfPHLkV+NbR3dGvaFC8PydWLT+fpxUt0mlAujNUGDGpsJKh+qzrvI4vx0cN6SId7crCowUmpZWSsBHFeOS6cdi82eY26VXxUJr9a5Ll25/6MyZe6cXFq7HRxdORB8Iy2A/2ZoFH5oVwJW9SiDwUuf9TfHHzsc+efjwr8UNLO8fZrEnU+enpw/90f33/7v47Ez+X8I1AOsiFUAPwJgqLxYv9IzTGNZ4QuUB2txKVHdOsKTA4a5MWwYFeEJVJ0a0KjZwfnj/mTOPFc/D3aw14Jevd9118eKeuJfggfh3az6evr0QX/nCSnThgl4C3m+ln4HfGK5+2/tPntz3ybfe+pW4F+GJeJUbijJ0uBrfN4p3IP/2hZkZlFXrdwoQfCyf6FRVgR95wR/bNDD1xS9+MdodWwi9qLRT8LE8wBYIAGA+RbgI0BV1dTl1z7lzXEL91rCeINpZFEJa13kbFy9k4p08vJYlKuhOnSYUKufKL7wSK4/BDZzcw8dtXNzJEwdGWjMBfrw/+N/GfZKsXbR+F38ogVdKWQHwAgAuv2MDP9pcNbV//37oOIPCpE0FiuAQqpao5aEIxGpehcZzc7vipo+neH9+5EcOIa1Bn47l02+bA+wtPLHDQxvctx/5sX06lkHg9mOv4j+c3LDhMNlOZMVPmsUfkVU/7h/QUQJAd+5f4H3OEcaqACNpNNzUBBlEEUg7CKpSRqij1L0RN5He+NIDD/z2Pzx48Ndifv9wVXuEn+hodSjTbuIIzYx0Kgu+L+/d+1/ispeXYGnx0DzvexkL+ETktsjqw7sq2zg0njDOq4DMkQDnMtKWS8vj5FnlLPBRRb6rF+/NfTgq96tf18aKKAu0FuJS709Y7ceYdPn5Tyqs3gVf3RSVFWDs4COkSSkAbWfQcppjBAckLQe7wEcV42MLh3ddvPjoqPPvzS6X7pcdPjZ54sXXX49esXYjCuBmD+Az7zvnY/m3LPyibGJhkgoA0wIvdSBlnnIVAUqsFCK+13v86Ozs8/Hq1G1xp9AuKq70wN7+1++++3fSDp9uP6/2AT7v9Al+NgSHqmzMj41OWgFgVLAdhNRBkDcy+FtibBvzidbn4jnDl+PZgV1Nnja28aWk/KUb3zb8z/GRq68Ez8ej72z1gu9un+DXuX7lAfulvMY6pEksAksGHQCKYBqQy+AxKFFXiGUgpKvxj9nzEV/h61p8YD1hMUAAAAVoSURBVKnJwyZx3sQDd/JwM0f6P99VfaZYPC6fWI0nKGPLll9avzKJapMJS+EBSs4dVB2lLHsAlSBTPuP+Nu/ej23gM7G6vzM2ZbiUXPLADZwvbd36x7HI+++xC3kgGPCyLtO80s8KIPCMzTE7fsaifEhPLExiH6Afs3iBHNknIM8eQbX5EhSvxGaRW7Wk2UByv949BPPr+B4Rn6ThSxtNP0wR7bUKPLTBffvcup3u3tW6oTkt4PkSD+sHdBQA4EkDdhmjaPJhKaaAPAq1GuqUgBIQFIDWoIUgMF0mioBQEbLbuutejK9vR3yOz6zwpQ127njf/rimCFw8z+rxuBZP7HQe2gBUAS6px0rgHVO2esbr2CNZpaFLEpZaARhUBp88AiBQTlAYUoSlxSBAlQGhu7WMl5gBmJiHT0X8duTXxg7fFl5Xz1u3efEy7y321bW8hNH/HXgbV+eFTKuijVO8mYOXM/B8Po9od57SVRGlgluCTV4eofBsLIEX/KhSBWVgfuJ0ORSAQTFQPQB5BEGeoFCgJfAKlunBbeVMLYdOx67i2c4LKphe8DRS+rK/SFYBnuxboLRYARR8qWDLl+XUJy3/UNu0DxVc0KVRdenCcikAI2TAWQkoQzgCkwVEmmNEhaqwGUMFeKKUGV1foADGrADyYH/2Y1/2pxIIbh3NdQQ9A0+b9iONoqoMuuShEvb+/ftbd8wfFJ1/AFu10fmDo/wXUYAETCqYUACWZrBzOte3DduWwjdgEARIJcggqgjSEmzy1ld5bMd2Bd3+pFXnS/3z9NNPd61t1ShKMCbGK2WMtgQmU8GTAizpDHBd2jqeB83tRrYbMjgZOMEU3H60PK8O+ND5Cvfqp63xjGp4gE9Q6FVmFCVoy1BHGNmLyJNAwVsGTjA5riJYlvM5TV3bgBLs52buVtcMQBlQgDef05ZlmpUpp+krhjya16SRUYLg00YphJXgCTJf8gctYwa0TJPPZZxrPrdJXwaBIg+Y5k2XANflPSdT2iNPqGiN0t882uB3VOXJ4NOdwljU9SieYFFDDTK9hNFxjVMe7/Aqv9AyZoA5VuatD1ekDaQXAdTJZxBJqwiWl3nLaTenzUOrMCqItjMsLcHn/CyIRe0tpRIs6jhlUIKOAshnHaUsR1rI+Zz2GLRXADyCIJa01zHL6yhl3ZCUOk993eOTSNSBTz8Ip2dYCiVQGOViyLzHO0xmfsu0+Uxz2nFaZr6kKgDlplWCXmW5vEyTXxQYk+NbdGBCmV7g090gYSzrmiB5gFI0Jd/mpXlsdWVle2Ve4Ck3Le1VlstJ9wwq9VIoQT/wYTALpyfDk/QEvYShcDzei7lOvbxW6DWuRmNN/WTALS7Lyrz1+tKl8gCDwIdJLpUGhmeeeWbVvn37BtZrUwEABbs8v1f5gHqVMjQ9t2wr5XuB26s8ndo8OQY+aztrAj4nNlIAKk5KCbTwUhBlHh7qQq96NeUA1wS8pvXq2GlcBn81PDY+v1/FpuDTRmMFoPIklKCfIJoKqK5eXRljWElhEjwOAz6y4Fp5qDBsB4MaxwPoBXLdpsJpWi+3vRLSk+C7DTZDKwDCa9NRL6EjiDph1ClFXRtN69Wdu5xlvRS/LU9tMWmlADDZtsNygL0EUacU5bnkm9arO3c5y3opfhueRsGitQLA6CgdO9Begmhq2U3r2d9KoePie1QMRlIAhDkqA+9mDzCqMo4qe/ofWQFoZBRG3s0eYBQvMIrMwcwwFgWgsbYMvZs9QNv1S1tZC3qmY1OAtkrwbvYAGYim6XGCT59jVQAaHJbBd7MHQF7DhGFl26TtsSsAnQ7D6LvZAwyzBhhGpk2At87/B70lCGXKqTnCAAAAAElFTkSuQmCC");
            t_tileTex_Ignore = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAgAElEQVR4Ae2dCXBeV3XHY8uSLVmybFnyGi/Edux4CdkTAoGwNSlLyxIS2pIWOgOUtTAtna5AaTvDQClLM1AYKDCl7TQEWkIJBJIAoSQkaRKy2LEdJ7Ed24lsS94t7+7///T9Po6en77vfYtkpfOdmatz3313Off8zzn3vkXvG3fG2KRxQSznh0vjC+fM0/l47PYc0zdcpxI6qb9OphNKHJM3J/lcOh/r63SxPX1SZj5mKK2E0y0Y8kTuPAkQzUlNGflYRj33QXv6V1HSNyBFEJ0HZPjxQhnc5TEf29BX5KqekMvGBE0YE1IMCgEokUfAANIcgM1LpViX9u6fNDjy4N8IFIDDDXK5hDHQt4/dp3kkl7nOmDCCsWIAKM2KIh8BywLcsjv5HPl4nDaM2B9jmJsAI4IGoBH4Y6rrY/OYKIt13Z4+MATG0akiZZUVT450xgo7nQQAcIMEOM6ngY9AO9+sBCdPHR+XMwJVKVIECeAAFOCPqjbAO88xnHPUd3uT+zMxxuDR4LHne9qMwMo6XQToAG6OlwI+AEZQDaxTS4Gn8z7GKNzeefqhf8bUqSIBjrmBi0YQAQZ48yNKHMe8DYA2GBF9emwMQtkEfJedFiM4XQbgCZsAwsA4nwU8gEegJ6quDSArFevPmTix46ru7iULWltnzZo4ccb0lpbu9qamzqZx45rbJ0yYovZF2n/s2N7jJ08e3X/8+J6+I0d2Pnv48PZNAwPP3rpz5+PbDh/ep4oADfAGPJ0OF8pch7k4zzyJCCoaG0YAEBZotAhleLwIvPN4q7kTXg7QBj4rJecnjh8/6drZs1dc0tm56nmtrYu6Wlpmqn7N1H/kSO9TAwNP3LtnzyM3PvPM6sMnThxSp4Bv0NPJ5zAG52NEcJ7oYm7PTycVjQ6NtgEwHkZg0PEUwrWBx4vx9Ekqc978lPzrZ84851U9PS84e/Lkc5vHj7cxjBgdPXHiyPoDBx6+ZceOu/+zt/cxDWSgbRBw5znGMDAWokh6WbABsCxgDCoaeQKQkR/pV2GwFPhZwAO6eatScixvn/zOefMu+7Xu7pfXy9MrVYIjg5aIO7709NN3KyocVHsDP5Di0RgwBCIChmDws6KBikeWRssAGCcd8tmcGXh7fvR4gDfoTm3mBv79CxZc8cru7qvT67jOnxby/uGHO3fe+o+bNt1ZMAQbgw3BCcPIMgQbgI0BQxj1SAAwkmHECI/3AIR8wn5c6x26DbqNYAjoOjb4bQr1K9525pnXdLe0zNbxmKOdR448889btnzrv3p7V0s4A08azhDiksDegEgQl4QRm6s9cCQJA8MIPF4E355v4Fnf8fTJKmsvpA5t6GZ/fOnS337DrFlvaGtq6lD5mCTL9sJp0y65qLNz5ur9+7fuPnbMno3Ro4O07Pb6SOljdBjr1C0/kgaA4OYogZDPRg/w8XgDD/gGuuO3Zs++4MOLF79rnnb1dZv1CHekS865uvy8+OjJk/2P7t+/W8OhA3P0Uk6KaAh525Tr85TzI20ATDgaQBp8h/0kxIsPAf/vzj779W+aPfvaiU1NNpDnFLWMHz/x4s7OC85qa5t4R1/fJgmPLtLzAOjIyafr1v14pAyAycJLeT7gO+QnXj9lwoSuL61c+Y4LOzsvHyeq+6xHqUPL/ry2tkVXdHXN/5/+/g0HT5zwkoBO0lIY9FEDnsFHQrn0aZ7l+V732eFH8BMD6G5unv7FlSvfO3vSpIUIWQv3dfvWw4e3bh4Y2PbEwYPPPHXw4M7eI0cOrNu/f9eRkyeTjVbLuHFNS9vbp85oaWmXx3YrzV4wadKcOZMmzZUnW96aaduhQ5v+4NFHP7/z6NGd6sx3Fp32Kx1Q4oqB+wbeEHJ1MKKbQsDSeHUh+jN3sufbCNjtc5ln4B3WWfPt+e1zdbv2CytXfrDWXf6BY8cOaBO25if9/Y/esn37BgHN3Th7oBWKUvE4y3qKscowJl3V07Poyq6uFas6OpbqstNyV026xbz9nY8++hndWu5VJ3uVbAA2BF8t2BC4VLS8vkKwvDYEy5mWWUW1E4DV3tNgDwCPQjEAe1GW5yfA69wUeX73l1et+uAMbaCqFWbLwMCWH/X1/eLft217WPf0rVArEfDxKIwA8M0NvmVmqUJeG2xyhTJZO/xrZs1acXVPz/l+tqDyqshG8LaHH/6UIsEOdWAjcLKsNoYYCaLcaaNFdjWpjeppAPQF+NHzvdvnOt+e73Bv77cBTPGa/5VVq94/d9Kks3RcMW2XR+m27B1f37r1l2pMGDXPMoCoTMZCZgzAstoIuDwdErFkCMuvmz37Qsk7lQ4q4YXl4IZgBCwJNgRHA8vuaGD5nSyzDZdIoGx99guecL3ISiTh+eYO/xiAwU+H/o4bli9/66LJk1foXEV06Pjxw7rpcuuH1q795gN79z6lxvaimFDocDdkrGQne1uWwWAsOp3MLVkm1uzfv18Gt/mE9hDL2tu79fzB5bmpY8KEqed2dMz47vbtj6oRY8CHA7puXh8FrZcBGHiTFRG9KR1KTwH/o4sXv/YF06Zd6caV0JZDh57+47Vrv/zdHTsekcbihsqgAzwh1RywDbQBJ9nD2HSxTBgMKxyDToDXMfNpVoXmB/fuPaBLvD7dlp49qampIl1qqZulpWTcj/v7n1S/gJ/meLz5iBiAvbNelFaWFUIEiOG0eN3/2hkzlr9M9/QrFeD2nTvv/JsNG36gzZ293WAbYHs5IKfBtVdlbaYwXMtpkNmsur7BMLmOyz0H92uD8fmkzu+feeaCqc3NjnAV08umT7/qnt27N3xvx46H1BhDpH/Laxnglq/uRlAPAwD4yC1sBN8KYj1NlgGt+53vnj//+gnjxuWWwSFX99pvUrpP/WV5ug0gK5QDqBWKEs2RGWPlnGXKaqPipE3C/3rJkvPk/Qt8UA2NHzdu/PsWLrz+zl27Nu47dszGZbDh0RAsF7LHvOVHZmUrJ0+8VkKJ5hF4KxHg4yYqudnziWXLrtP19rK8gx87efLY1wbBv1dt7PmEffO0McRIgEHgYVayUxpgK5K5MA9CPnsY7l9M+tuzz77iFd3dS9WmJvJLLCs7Oqbq/YLV6sgyIRvymUfQawI8LawnWgtZYaaoOJRn47ICo/IS79d19VkXTpnyQjfMQ/b8z23c+K9f2bLF4BtwEkuADcBLAGs+kSALfCsU5eJVKhoyB6KXjTgaQZLXg6mXKHwvd6N60PM7Oi6+etCYEv2oTxuaI6Z15zGJUOboOnIVV0e1GoBHjYI47z6drDwUSPj3xFrft2DBdQ5/yueibz777PduevbZR1QZ4CPPMgIMIO4FYgSIRmCPwqui/FlG0PyJpUtf+eKurufnEjxnJeviHfPnX6PqwxmA9Wh50K3lrAvlBiHHaAhnngbfBpAYwdvmzr2gktu8d+/adc9nN268U+0j0OSjx0ewCfOEU3s63p4FdpTXXkeoB5CE//2yZa95UVfXhTpfd9ITxHl6w+kSdYz3xwgQDSDtcJalaoOoxQDSgvjY/RGuLDThvxgBXj9r1qtVnot0w2Trn61bd7MqO8QbdBIhn7AfPd6ejrfj6YR8wFeVYuRCXpYrjBXwk/3Lp5Yte93letbvhpXQ7qNHbZi5SFdFV2tP4PEwApaAuAxYx05Vgx6FqcUA6CcaAgZg8JP1UtyTSJRq7897n9+bvk8++eRNutRzuDfQpKxrekAH8OjxapoQciKjgUdGDNSgGwDfpSymT59zzht1r+JSlVVEP9ixY9O7V6++Rw+kLE9Z8ruN18+Zc4EqYoQYABGKZYC5wMv2PVyFag3AA5vg7icmC4oREAUm6T76lSrPRXf29//8nj17NquygbfHl/N6wj5GwNqe9nrLmZYvbQBFIxD411w6deoL1KYi+tHOnRs+tmHD/RsHBnZ+p7d3fd7Gv97T81LVtTzoLRoBBuA51Ay+ZXJHtRKCuK+0cothVa9KzdNbPYvzDLbn6NE9H3/iidtU195uAzB3Sod61vgY4gEcbvmQKwt4vB7QeS+hXeBfK/AvV/uKSHcH13zk8cd/pkZ+0LPvC5s3P9R/9KgNuCx5f6SrpIWqiBFYh3Ymy05C52muKpVRLQaQHtzHCJj2/pbfmDHj0ryi6c7Yj/U0z6Ef4AE/ywAwghj2I/jIiREgG2E2uTLRWA75Bj9JAv+6asBX5HroL9evv139JOCbD5w4sedbzz77oPK56DdnzrxMFYkALFMYgefh5HnVTLUYAINHBUclo+gkCpw/ZcrFNCjFtWna9aXNm+9VHYNN8vW8kzdUbPAi8AacpGyiHBRlblmcUCq7/FO8XnU6qgVfb/3c/6fr1t2iPgz+nkKyIe/7xtatD+tRsMvL0or29vNVidBPBEgbgOeF7qs2BndSLcXBUTYRwBwDaHnF9OkL877Df9vOnXdp4xc9Hq+PN3VsBKz10fPjXJAPmfAkPJ/QHz2/avDv2rXr3j8ZvGKJ4DvvtF8viO7VP5HcHwUcLm9d6Ypgic4jMwbMXIYDv2JDqMYAUKzlZ0DK3B/gI3TzS6dPP9eVy5F3/v/2zDMPqB4ej9fb8+3x0esNfPR6HRY9AoNEhhH1fN+r0JPJb2t8wAf4xPtV7svXg/q/woeODb4XqMPSpD3TCtWIBmC9Mi9zdF66ozJn3VGthCAIh5Wi/An6nz1bc1nSe3rr9F+5Dp0ReMI+l3ppI4j9Wpa0HChxRDxfT/Pu/qO1a2/SuAYb4M0j+MlVzPYjR3brNfH1OleWFullUlWy7OgRvUbw0T28bL/pCrUYAIPC04pPBNeNjZaZEyfOTw+cdaz/vn1M5QAdgcf7Y7hno0dXjG+O0kbU8wX+XR987LFvajyAj6Bzt5L7F8l+5t7duz3HsmSd6YmplynmYp4VBcr2VapCtQZg0E0RfOcBAWudoIcmC/I+8tUbMmvUh4HPAr/Umo8c5ow90p5v8G/UeNHbMQBzDMDe7z2N0+Hv79ixzg+3lC9J1tlL9Dq5KgF8Fvhx3iX7G+5ktQYQ+0MIwDcHhKaV7e3zYuXh8n6vT+HfSsPbIzf40ftjNx6fsfGW0fD8/9C4ljcmg51134I9zRG9kr5vhz5AoXplSW8iL1AldIlezdG5eU3kziqhOGAUgjxAIGyTbmzMyjOA7phtVr0IOpd70fPZ9JkzpnlxPOVHw/MNftrb8fgY8u31XMoWI5u+PLJJ5WVJy0C3KmEAMQIwd/fhvCmWDZbk+GuPqQcxuHk0gvF+3TvPAFsPHbJXGGwbQfR4e34EXoenTBolce3MwxRf5zslN3cKvOpLvcKaD/gATog30JbdhmsdoBPnKU8MvDBXFZem6c3NPaqBPukvzd2Jy6qiehgAgyMYAifcr37lkUyfYNmuenh75IR+80gej7EI/fb+kdrte82P4DsC2NttAIR4jBe5kJFolhhAYa5qVpoKuqMvOHp245inM5fZYXJRNQYQB3XeRNkpvLWpyR5Ylp48eLBflfB2QMfzY3vGcBmeT9gfLc/H+wnxXLYSuQyWZbN+ozEn59cdOJBrD+DXxdTefTHnNNep2qgaA2BECxMpLVxisTIAvwNYlgpf4jLgGAHgw91HegyUPNqeb693iuu7vRz5LZfzEXyM+oQ2gW5blgq6Y85pQyjbPk+FWgyA/hGQY3OXJZT3ElBXAFYmYJtD9G8FQCgDzyfsj/Saj+c79AO+vT8J7eLIj8yZxqy5OnKUpaC7oj5Do6yycDpfth4GEEeKQqGEeL5UPoLuevGYvjACe5jzNgBv/LIe7njjV88Nn9d8PJ/Qz86etV9VEkJevB7DgFMvDy+l03guT1+n1Km3AUTQKp0sk0F5Bjgmwqq5k2WPnt+q45Ha7UfPN/hs+hz2nQBa2ST6RT24LBLzjGWl8rGvtE7juVJ9DHsOjxq2Qo4TWUIUy/yAJ0cfZ+ilSAMI+JFbxgi6gbfXG3x7vts51eWpXsalXryrF0M/dysJ/2wAAamoA8kW53NGV3OzZS9L4Y5h7It2WWWcy81rMYAogPPplHjFwOCLHWUF6mlp8fptoLMAN+iE+wi82wC8N5v1DvvlPJ/Qz9wlQqKHCLjnw7Hz4/VfxZazLB3QZ2tVib7T+4my7fNUqMYAECjdv8tNnE+4DMBeU5b09KtLlSL40evZ7KU9PxpAvcEv5fn2fsAn/AMQcwV0OIYwvjBX6g3LC5+kpV/06voxP2z7PCdq3QMgCDwqI8n71a4ZOSQ5q7XV1SxP9HaUzJqPURAF7P02gsT7q32TJyPsl/N8wj3zNcgQgJsnHi+O3AmXAeRRyRl7jx1zBGAM6zjmdZhpCK6Xm6qJAFmdYwBwBD3hL29nNUiX6Xs8PSoD/Ojx0etZ8w38kNBfR/DzeD6G6XkyZ6aEAWSCr0pN+oq551qWCror6lINGCty9+PjqqjSCOCBsPYoBPkobHITRE+/duSRTF6xUPXS6zxN3b/79nnLPGTjJ/Crenu3Ss/H+5mzxEkI4PF8vN7ykhL59eWw+YU2JVlBd4keVZFxrYf02O4nq8zlJakeEYCBzS0cAif5R/bt21RSgsJJbQK7pzU3ex13eCfZ4x3iWevx+mS9V7mv8+sFfl7P97xInnOkCL51G40gAV9XAG36GtnM2Gi4fEF3UZ9x3Kj34booW16tATDxKATCmVtoh8ljP+3v35znUtD/IKlXx89Rm3SYB3Sv805TCqme4OdZ86MHSoQhlAW8vd6gD0l62XNpnn+M9SWgdaf2LDdpQ4i6B48hQuU5qNYA3HcUIA0+wh7XRmag9/BhT6Qs6T38paqU9np7e9HjlU8M4R+WLXtTNf+xkxH2K/X8OG8DH5P1Gb3eRuA9TDHp/wtX6rgs6f3BrdadKhZ1Wcija+Qo21epCrUYQOwXYfB+C23LTe6U6QONT8TKw+WXt7cvnjr4+NghH9Dt8X6kXOT6L903XjZt2mXD9TNceQb4lXq+5wkZeFP0foOP57N5BfyJ+rmatmWTJ9vIy9LjBw6sVyXuNCbRVMcRfOfRO7xsv+kK1RhAHIy8OcJhBAh9VIpfmx4469hf5fydOXP8v/cx7BPyEyP4ZJX/pZsBfi2ej/h4v/WI92MADv0Ygfc0Le+cP/+SvL9o8ovdu9eoDTo0JxKgZ3SvU9VTNQbAaAgQwUdIC4z1HtUn1db6RxVoWIrrsyvn6nz0fgxgir7M8Wq9L39RqfZZ5zLAr9bzARyvHw50A++lzMCbJ0kveV6qfFnyzTPrTBW53Wxdpo0g6p8+XVYR1WIADIQgWCbhHyPwJI48tn//wzQoxfUe3LQ3zJy5THXY9NnzO/Xl8Kv0ZY7zSrXNOpcBfjWe766jcjEEDCAr9A8B/3fnzj1P/xqf6/pf/ztwv8YrOpDy1iUGgJ7N0X2UTcX5qRYDiIOTt1AYABNIDEAW/fO8YmkZOE/PwjGAjo8tWfJi/XfRirztqVcA/0Yd2+NJfqTrzZWf58enelHBzEdVihRBB3iHe0I+4R6P515Fq7453Kavi7682FOZzHd7e3+hKrxlRBQgukbgy/RU/nQtBkDvKAvwEXRIBNCHmzc+c+jQRhqV4nqTeMpb5871JWH7RxYvvlTLwtml6medE/h3F97bx+Nj2D+oNjYClIyxInuWkksZgMGPBlAEX+Wtf7hw4RV5vV+vx2+9ra/vKbVLHEec8B8NNMqH/s0rJoeuaskKMaEYcxsU3mEePaRZLzmeOL+z0//5WpbOaW/v0o55ysu7u+eVrZyqUAD/JhVHr8fzAd7gp4FHmfTI3OK8rDNv8Dw3gLfXG3RvXuMGtl3v9s//wMKFb9aPVebStSLlzfft2fO4+rG8GCrRKsobjUBVqyNPrFay0iwMyV5ka40RIAm1/7Jt2wO7Br+SrdOlyZ9efcn06bNL1zr1rP9RU57/bZ3B41FkKWVaZuYRPWk4AyDs2xDiWm8j4K5lm0J/x18tXnxt3p2/PozRp0/h3aM+En2JEwXwfssZgY+y6lTlVIsBeHCSR3Y+bQS2WE/CEzrkn1S7ubf3+8qPCOlftO/TP2p+R53bY9KJtTQqM8pvmSLg9linIVFMxwYc0An1gI73J/zDS5ZcdeakSbkjmP5t7NbCz85FA7AOcagsQ/UcqqZaDCAOmgbfghKusOIEkC8+/fQ9Xudi43rk9XGGB/Qv2reoL4/jMO+EEWQpFGONCozLmHWTZQSs9TaC6PFDwNc3hC/Wp16uUJ1c5B+hlG7uVuUoM0ZrXVqnUeZovHEOucajUj0MAEHgFtLCYgTFCKCyBByFOa/PdaOf9PU9oo8z3K4OMTo8Bm+3TFFJpTw9enwEm3Ue0H2vAtC5b5Fcubymp2e5DOCaPPf8UYJ0cqO8n32K9WSjxQDQZzQAmtbEazUAlBrBxwCsfAOCAXhCiWfqv4DXPrR37301SV5orC+Hr/3z9evv1GEEPRqClZdWXDSAUp7uNR4jSBsA4BcvV1W3Q+Cv+NBZZ11fCfj6/YEHtflbrfZErRixmBfzQNeRq2l1lGtnWqZrlAl3dSvVx3CP42NCapN26ptePWPGxYX/ftGpykk/1/qEvsZ1r1qisOg1NjwrzQpEWcoW5bJsgB+9HtABvtx6X/T+35s796L3Lljw5rybPgvjO6QfWLPm8/uOH9+lQ0cAb17ZsDIfjCAasudUM9XDAKIQ0QjIZxqCfkLt5KETJ/r0RO/Can4aThump/UdPv9ETIwwzpOstBg6rTDLYkImDDJtABgB4Nv7nbzZczol/OvT8a/ST9e/Nu/lnvo4w4989cPTX7tLvxmgw3jVQiRgLnEeNgLAh7u7qqheBhAVa0E4JgKg8Oh14xX69uhXM5r1NtDiSqX39/Xv3r17u4zISnLIB3BzKyYqCk/3fLPANtB4PGADuNd8h3uAN/h4fbteZ++5YcWKt1wydepFKq+IfrZr122f2bjxDjWK4Nv7iWgsZRiA51Uz6FHIehmA+wT0mKcMjkEUue4QbtY9/udNz3mfHOF1t3Dyq3p65smLDuneeZ/KCfcxTCILhgf45ng5wMNtDFzeseEz+Kz55l7329+un6//i0WL3qL3GefouCLS7xc+ps/Ifl2NDD4GQOj3JjAatufk+WEAcBXVRiNlAEhl4LNS0QBcUZdwj+te/zJ9Hs0PfnKT/nlygpaQebrcmntQPxOn9w544gjgnp+TwU4DbqAJ8QYajyfMG2gSXp/w182cueqjS5Zce+X06ZdrD+M+KqIdhw9veZfWfcnst34NvoH3+p9cJYmXCv11jQB4psasC0WwDUIaACvZCrNirWh20J1nt7XN/fTy5e/Xe4HdKq+K5FVb9V3ee7Wjfkzf5bNCCaXRm+xJWVHCsmM4jhBDDMc/IqnfMV6uV7peNL+1dYHOV0W+E6o7lZ9df+DAVnVgg/WzCjZ/yVWSji2vZfdy5hTlrZv3q98hYdvHtRIGFZVppdr7rFTCLCEWz7IhTJERzKnVCNTPGf7l0Pv37l2tb/Y+qnsEGwu/HBr3CSjU1U3IbdCLhivQJ/ojV3oeseq8jo5zJ0+YYMOtmlLg2/N5UOUI4OQIEMM/az/y1hV8jVWcuPP1IpQZjcCKjesuGy3CbbKmqk5iBJ8855x36y3hWfUQyL8t+LR+Ys6/HfzkwECvPkSxQx9uHtAbt32xfz206fIbu4vb2qYvbG2dLS+fM0+3cfVMouIQH/slH8DfpjKAZ+3H87nsSxurgbcRmJyvGwFW3TosdOR+SYTVaARWqqOBDcDRIK61Hf4B6c8tX/72hW1tS3TuOU9PDwxseM/q1f+kXwq10Rl0gE97voF3+OeKJu35dQVf4yTrnPlokY2CSWRxl53UPYJj/63f0tOvck7Ww5QFoyXcSIyjG14/fc+aNV8t3OhJg4/ns+lLr/k2gEQnBV53Ee2VI0UxusS8x+M4bRDFyR4/efK4Pq68Tv9TsF1fz16qu2veRzxnyO/16Wfuvv7xJ5/8oeYSQz5eb/DZpHK9P6IbvizljaQBeDyATucNtAnAY56wl/CH9u3r1Ruyv9QHJ2fpJ1V6klZj/I8uR1fr4dQXbu/rWytR0+B7x2/wvdnLWvO53sf7Va0YNZ2vK420AVhYG0E0BMoMfizHKJh40RD6tGnTpd2Delq2TR+eXqiNmfcOY478QsdXt2z5xkc3bLhZMrPeG3AnPB/gDT6eH3f70Sk8R/TifN0pAlD3zkOHjOMNofNxY2gjdHh34jKR+wVcLrJZbNVrZVP0jt1LdfPnFXk/Qad+R5Qc7vVvXD/Sbd2f6L95fG1vsFnf4RH4eF8iveGz4ZvShjBYWue/AFPnbjO781gxRSPgxosNwIbAVQKXi3Du2NkQOvTk7Yorpk17caeuGjJHHOFCe7zu5995w6ZNdwp4h3qD7ESI5xjw42bP3h89n8gH8CPq+Ro7odE0AA/IeEQCHzvvKOBkQ+CGUYwINgiMIOaTSKGfozv/iq6uixdPnrwifFpNTepP/kfXDQcOrP5Zf/99X9269UGN4FCeBppjNnkAb9DZ6Rt8gx7XfB2Ojud7IBOADB6Nzl+PybgYQjQCDIFlIUYEg59OLBstigqTr501a9VFnZ0r9JRxUb0igz1dH3h+4n/37Fl9o37CVt7uNd2gsokD6MgB3Zy1nnAfPT96PHk1GR0CiNEZ7VejMC7GgCEY/GgMBp87iEQEA06yMZA3p07SThvGrhdPm7ZIxjBTTw9nd+phk4xkmqLExPT+weu4vPuwwN21R59m0f8wPCPQe/XT7k/ovn2/+jZ4ABnBjYYQy6lrbsAj+IR7OOEeruqjQwAxOqMNHYWxMQJzg09KLwvREAxwBJt8rOO8E/1gXBhbHB/PMzcohGY8lbBtMJ2PXu2y9DH1aEc/9B2BB3S4uhs9QgmjN+LQkRgfDjhwQDMHTIBNvFzlGIPLKaMO7dwffdE3Y5pnGUA0AoCEAxlUdCgAAAJQSURBVLB5zHM+ejyguyyOQ17FSbn5qJMVdTrJSgAAcysrAmPZUJTPGUS8ycq2/AYAoNPAuzwCb/DTBqCiIgAew+NF0Jz3WHHcNNCch7uN69MPnLnoVHFMl502QtmnTYAwMLKYkwesyAE0gkve3Ebg+pQ5HxP9M4ZOJwQ40QAADvABFaApj4BTx2X0Sd4DATg8Gfx0/Ukr4XTJwbjIE7nzpDSQBpmy4fKcN6ef2L/HBow0YBgAPIIb8z7vY7cHbDh96tSQcXx82glFnHZBUgIgV+TOpxOgpkFOH7sddWOfcdi0EaTBxAgoB+BYDthpzjguH1OEMsaUUEEY5Ivc+awUAY75rLoegj4ZDnDS4MVjQHdZzMc65N2v8yb44NEY+ptWwhgSbYgoUU7y5uk8ZZG7I47JR+58BIi8eTpPGZy26WOXm2g/eDQG/6LAMShapkhRXvKRD5d3Z/FcZueFQkDL4rEs5t2U43S+0O3YZChlbEpXWqooe1Y+q4we4znKzCOI8TiW58nHPsd0fjhFjGmhU8Kl51Du2M3TdegygjtcWbpO+ph2zwk+nCKeE8KXELLUvEqdc5elAC11roQ4Y/dUOWWMXckrk6zaef6/A7wytTVqNzTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0EBDAw0NNDTQ0MBY08D/AbMyXkHjnJtiAAAAAElFTkSuQmCC");
            t_tileTex_Empty = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAcLklEQVR4Ae2daaxdV3XH4+nF84uHENtxEjI4duIMQAoJAdqKoWKokCpoQFQqagUfSquKUor4QAcqPqAOFIkKIaF+aD9USoCqAgpUIChTAoRBSRxix0kImbFjO47HOH521++8+7tZPj733XPPPff5hdwl7bf23mefvdde///a+9xz7jt33lmzK/M6w6HLaX6nDt0vlc+13Om+UNS1LSc7HWZN3nSik0fPlGhvW89Vx6GiP/TIZeHIR5geQDAEKusM9oJoThltyuXclj4o576iWAh1oxBAQrImL5iCPtWpy5p8LtvWcyWAfUfz7jjkRyKzQQDByECRz2AKthq7SJTVHpMQgq/O48Rpp4jHTqmsUchg2FygKAueOgNM/ngkgTePxubcVjJEdVcYB7urbOg2GjYzagLoeDRJsACTvKAKuHpRHCvnMxk81/7sXx2nd4W6plLlfAmQtQBWgQ3gz0bKmryJOXieREIjjIH9VXZwfGgZJQF0vKAwUVMV8IBOmihpyaD2XLT9OYY6DnVFO7oVA2bKzs/Akxd8NKACpuACvOlYJ6/Wdo5rI5rzOTYrJBgVAfKEmAxltODl6BZ0gCed3dGWJYQE4Fz70Yn0n1MUu6It3YoBM00IYMQLNpr0TElTx1xoz1wgDvZCAkSCTZdGsBKMggA6HN0LfMAUeADPaXGpXBDh+nPO2fDqVas2XbxkyUXnnX32+pULF65asmDBioXz5o1iDmFCPTl+8uTxI1NTB54+fnzfr5555vEHDh9+6Pv79u384f79j0UPGXjAPxoJbQCUV7E4dIqwCuBHSZjzpzRsWhCspueXz7M/NMkINWqNYqMcDeCkJSlf1L1s5cr171i//lXXrFjxG5OLFq2J488b2f/ss3vuOHDgJzc//vitP3v6acgA8EciQQI1eRPHWQkgjVsIBGA1cCWQCOo4NJwI2HC9PHe2wGfwYbmML6I5ygIv6Eujjjxp6RvWrr3s3eef/5ZLli69KsrPe7n/8OG7/+ORR/7n63v23BeTAfzDJS0hIIFEgAyAT4IIJIA3RXZ4aZMAvcCHAABP9LvUd8GOOsAv0uZly9Z9+JJL3rF5+fKXRN2vnWw/ePCOjz/wwC33Hjr0REwOEhzqJEmRV4O8EkgEwVcP7SPAaUMkUnnPN/IF36UewJdFWt5JK/7soot+60OXXPKnsb9vbMOgudjH2omJdW8699xXLVuw4Mjt+/fvChsNGs0VWDX1RH4WjiH6fLrU8G+bBMAgCZD3fMAHeKLfaBf8FWfPnz/5r1de+e5Y9n/3TF/QhX0jF+Z4zcqV11w3Obn2G3v27Jw6WeCZwRTgfhpb83mNbG+DABhh8qKPfiEB4LP8V0X+inMnJtb+29VXv3/TsmXXRpsXlKyLlS5Iv+Vbe/fefXhqiiUeAXSTe77a+qJhW3+GJYAMRPcCn8gvLu5CdyMf8D+zdev7NyxefElbk3m+9cNH2d9evXrzN/fu3RYk4MofEfCy7rUiTJ/V8G8bBMjRT38kIj/v+y79xZ7Psk/kv5DBF68VCxee85urV2/64q5dP4vtgJUAoAFfAuQ6VwHJYDeNdVsEKEe/V/156e9e8LHnvxCX/V4osRK8fHLyRV/atWtbtAFwwM9aUkgAupIEaFdi6gcS9ummYuSryyRw/3cLKLaBuNp/zbUrV97YZNDjJ05M/eLIkQfvPHDg/ri58tDOQ4f2PHz06NPRV44Y8kh20HTNzH+zE/OcyOeVDZ8xp+La5ryJicmLlixZExd258WNq/O2Ll++etH8+fhiINkaN7ved+GF2z/90EPfihPZDvLtZMhAXSYGdgm+c42qwWQYAjgShjDh7Kh8AYizipWAz/lvW7fuJk+sq49OTT3z3X37fvzZhx++7ZGjR5+K8/iMrINwjtGCI5oQANuRrCU0mvnkOTnmvF8dO3Yg0tSP9u8/GG0eW7No0eQnrrhia6xwXO8MJL+/fv3b45PBPXGfgPl5Q8j7Ad4Y0i7mib2Nwce4pgTIjqIfyhpGtNAvESL4EGApN3li/ydfWyLK7/+7nTu/GJH/ZJzkjRKcoWOIjGEI4FywibxzQRv5gm/kOx5zpg2rXRGhf3Lhhec3AT/OPwvfhI9u+uO77vp0FCEAc8SPeb6MJ/jaG1XNiNCUAAzo4GqdobPyFrCY27uD3OE7cfLkiS/v2vXtuHP2fzEWd81IvQjg0kg05BTFWuIc1JKZuTgfgDDarDuFfH9z2WWb33juuefXGrFHoy3Ll1/7hjVrLo3bxlwPMF9IBxEkGWTQPu2JqgKPXKaurzCRYQWnaZDRT784rLsKcG+/7kCAH8v9F//90Ud/EuewtAI+t00lAA7JK0AVAaJJIVVOweYsGXjy5chnHkQ9wnEJ4FZw4qObNl0TJH8xDYaVP9y48S2d5wasltwmZnzGJGEb42ozumqOUd1f6LCpZAPIuwJIgu4KwFO9QR7sEPkd8A9EvxAA8CGBD03ykuhyDAlwhCmyhVQ5B3uRrMlju/PAN/SJUG//lJ1voT92+eXXv3bNmk0caEMuXbp0Kz776dNPM2fAx5eCr43YiU3YQGKe6sjWkyYEcEBGMO8KgKZPDJYAEzzSjXItYc/vLPsAT4IEPjRxBZAA3QiMNgIk4Oo4dJpgN6L9aIFHYzt9IxxjThLNfotzPr5582vic/yVNGxTbgqfBQEeiT4lgCTQ19rusJS1zbq+ugkByp1qiA50BZAIEzzPL59UVeZqnwu+OAbzXfYFn7IEYO+FBJkATN4U2RkFmxFsJq9TqUN0pMecU5fU0WbiHzZvfsOrV68eyW3sa1esuC7G+K9IAo8/scMVQL+rtTma1Bcm3lQcWCdlAmAkhi/imzx1v8zBR73O1b7gV2kfnbodQAqfo9fRXj+oIRIJUhVX8qFd+p3baQT4py1b3hTgvyzaDiSxwkHovoLPrp+c3BANCz+GLhNA8mJjY2lKAAdFm+hLEmBskfgaVx3ruMnD5/xoa5Sjq0AGOEHLwAmgq0KVBljrXS2MHOaR7cfxLL/FPYzQfodhyT9v2fLWG1etennUDSRf2bXr0Q/cc8+2Z0+ckGAznv+qad/pyxz92Knf6YN8I6HzQSQPZF5DJIBOLKKG7/DVGYA7fJ2bPJkAOe/nYggA2ACZ932BVOdhy7Zapo32o7Vd8PkIRiruY4Re8oktW37vhlWrro/8QPK13bsf/Nj99++Ik+bfffDg3pesXLm2Xwdx4XxhtAEjwUfr52w3XVGumjvHegqdDSPZiOxAHbmAL3DWGYDbu9EuR3fOA3iOdqPYiEabcEKvFIcK0W4di5MBPQOen2ByV2/Zv1xxxdsD/BuKHgb48/Unn9z59/fd9+M4hS3tcFzc/arO6R3faWM/8OmSeQ0kbRGAfnRqF/yoW8CDjjoWcW8/2gEywJdTL/AFvZfORMAMI6TKVqOeaHfZ5ylmF/y4nnklnQwi39yz5+d/u3Pn9+McPtGw/x++syYBOr6TAPg1+9k5lEEvl+O03jLoFkBPMw2sgRo7n69u9x7+uSM82ImS+3jWOdoFOgMrqM91dnpOm7t2RRPmTnKfJ/qNep5cAjx6RUT+TQH+jZEfSL6zd+8dH7n33u90TsIGSLbol0eO7K3TUcd32af0YZn80NKEAOVBda5aA9Hz637Nq/NUD7CrwM8kAPBMBOwpkyA7x3y2j6hi7ka9+7wEEPzlTcH/3t69P/3wjh3fiDGYj2NDtol4eIT9faXju8KP0VhtX1n37atXg2EJgBFINqacn27R/y9OyUALsjpHfe6tF/jZDp3HfAHfmyss9eXIJ+qN/Hc0ifxb9+27/UM7dnwl+pHMjk+ZOeq3yPaVPI+czycO0l8+r4iCUyoaFBw8G5fzdbsU6CoiZPBzvlffZZsAwL20WIaj7AXfaVEfx1j2G4F/2759P/zg9u3czOJTi4A7PuAzP8p1RfLoU87LefuhrhwMHuuph10BenWsgei6koGdKT9Tf3lc8jqvV+Sf8lW1aD9U5P9g374f/OX27dy9A3w+wgq4W05UFTaxAjWV7NOcb9RfWwTIhpDPqa5heQXoRQD6qmK542dN3sgDgJFG/g+feuq2D2zf/oUYhyt9CeCcHBub3IIiW0s4J6daJ9Vt1BYBHA9D25BMgH79OWZ20qxGfoB/61/cc8/nwtDic35oCEByHq4EEIGPtJSbSp5n0z6657VJAIHodj5gRmepPZ1yP3FsnTObkQ/4t4SBRH7xOT+09zG0m5WAebD0c+3BtUFdcU7Ose55tdoNQ4CRGFTL6ulGeXyddCYiH/C5yUPyQRVRTsIebJOQXhRCiLYk+2HgPochwEyDCcggxhn5RrzlmcbhWB5LR8/Gnk/k3xzjCz7RDwFIAi0htYul3xTZMy+jIMAgoDfxQO7fvI5mPl5ksd/6Ob/Vq/3Oni/4fmGF/d+HV0Q4QGMLNgk62u0gsgOL8x34xF4njIIAvcZqux5nmIyw2Yx8v67GCpAv/tj/AZkECVnJWBGsq7uyxSmjl+cbAQQcjSMBnvxsR34GPy/97PsQAME+bMPGMvgcmxPyfCIAzkSyduk/E5FftfQT6SRE8F32IcGcin6MnMsEwIH9kkt/+d7+qPb8XpHPZ34iP1/8YXuO/CgWBMia/BmVuUyAKscAOCIxsJ/EXjuSe/vpgk/wjXyWfi76uOp36RdwVyajXh1NuyQgf8ZlrhNAoHWoeydLPnWCP+qrfcHngs+bPQBv5EMAL/S00RXA8pxb/sPmObkF4LgsmQQ4kTIEILH0e3et1ad6fSIf8Il+CcA+794f2e4KJeiSgGNzSubaCiD4gq52BcB51GE3BDDyBd9n+UM91asAvyryAd/I90IvqgrB3jkLesfGQs0lAgg+hgk8WvAB3Hr2fPd9SMBFX/dbPJFv/Dy/Avy855cjn6h36Wefdw7ksdcVILJzU+YSAfCQAAs8TiQpkoELPpZ+Ip90JiKf6CfySQAN6NgnCcYrQDijiZRJgFMR6iUEBDDyiX4JMFuRX176BVsSWC7rMHVuyVxaAQTeKBdsb6fiXOylDPgkgHfpbxP8mfb8HPnYBMgCzRzMR3buy1wjgEsoGgJgH0usAvh56R8F+DPt+TnyXfoz4OQhwfNGRkGA7JBBHJEjH7tIRBji6uBHvlPu9DX9AmfFBV+TyK8DelukaOrbaS9W/B0FARgGQ00Vw1ZW4aQc+UQ7Yj3HWPbZ/4l8Est+o3/aqAB/0MiXnILSFsgxrdmTYQjgxNuy1iUfm1zqrfN6gCt+SFAQoEXwm0Q+884+yHmOIZAiE8NyrisaDvGnatza3Q1DgNqD1Gwo2ILPHkuUobGT1P3YF+C/vck/bYwg8sOsWtIUdAA21RpokEZtEmBYIwGexBIvq9GQwGMFATrgvzLqB5IK8IeJfGzrB2qO+HJ+INtTY/2sj9KhwbNtESAbkw3M9f2swxYu8kiIzqUP64v/z4/Iv6FoMcCfCvCH2fOdlxpLtDcDrYW5zrzH+mnGyKlf+4GOt0WAPGg2Njsot6nKE/ks93nJ16kFAXgzR5OXM1SAP2zkZ/sFVM0x82g/3eQ8dXWl7MNczvm6/Z3Srg0CaATaPIOUy6cMXFEAZPd9l3wcheMmeCfPKxu8lqUC/DYiv8L8bhX2IgKOznnnVDSq8Uc/qjkl5+2CuoFlWAI4qAap2bfN1zWKq3sdxQMWyFCUeRtXvJNn4BcyJfCJeJPf4fNxbvmpniTM9pNHsMe8ZTXHTEY92k8wXuRa5rw6wnj4M/s020Af5TJ1tWRYAjAIg+ekoYXRvPVz/rx5OGJG4a3bvHg5GuEgQCDN5z18TV7F1gH/lugD4Om3vOzzZM//4PGpXhl85xVNTxGAVgRdncEvE6AA/4LFi2u9NAPfxSD6E1vMM7a2oRtLX2Aqeq4a2DoN1PATh6am9lf0cVoVr1yPyvxYd0W8gfO18RLGgd/DVwK/DLyRz23dXvf1daqgqrHbPFqwzRvdaIKLrUxtfmG8THpt1PeVju/wZSamvtXGvv3M1KAJAXJ/Ak+deQ0s9MHjx2sRIN6X/6Loo0uAePfuq+P1q1fmwerkA/zbOv+oyVKfwee7+z7PL0d+trk8DOAqGfyclwhqQDcJvNc1i+LFmRvtcCbd8Z3ga6N+5tSctyvqaktbBMA4BkZjsOn4rmPHHo9yX7kufmwhGvE5f2m8dfu6ePHypr4nlRrw//kBPv+iDdju9YKe9/r8JQ57MYrVgonOkV2Vz2ALtB9d+XSTE29OvdRBZ9Id3+lLdfa1YJf1TN2ecmxQAjgQnZhHk2SoJCgu5OKFSI/SuJ9cvWLFmsmFC1d+5NJLr45Xrr+4X/vycd7MEf+fz8sZ/NKm/60jAXLU40wdmbsSfHUmgXkIkEkh+GqBRwO8usjHtc7Ky5YtuzgP2iv/0JEjj8Sxwo+htVk/6/eMQ6+uetZjdBNhUJyUjdAwmYrhx7+3b9/2t55HcM8s/MzKJ+OXNuI3BXjGP5DwTp70WhYinQTgPr7VNvsVTMqCTRtEh06XTv9LexJiP5ACXxL9AM4nGm9bs62RKC9+zwUXXF/3xVnx6tztcU7hx9D61bno+zjU12baVEpTAtBZNkCjNFKjnw0CPMIPKdd5X3AT8HkbV+eFTIDOBZ4XeRJAm7ARmwUQ8MxTD4jofuI5aAmAH0lGv+AXW1rUF+WI/nPiuuYVUe4r+AzfRUNJXF4J9H8dm3uONwwB7FTHonU2xnqVfeyuAwd+Fh/lXu8JbWnew5dexaaDtIdhBAhwiU5Bo41JB5Z1NOkK5yFZ2zeaviUAS70E8BtLPL3k2ubN8e4/jvWVbQcP/jQa6UNJoH+z7RKhb59VDZoQQEfhDAfXIHQ3+iNf7Luff+KJ29omAG/g7LyE0fFwjnZkGwGIeVJH3nbablt1NDlNMvAcpB/qIFZe/t3zXfYBviBB/JbQDS+dnLwqyrUkfHZrNPS6RQIw1zzHbHPO1xqDRk0IYOcMmBOGyVCZywSeiV/UepifUOeXMDx5GM27d+P1qz/q9AEQAEIy0gXZespl52EvUnZcLgv8dMvntowyAVwBIADJPb/43kL8XM51f7BhwxvtpJ9+4PDhbfFx9pFol69l8Kn+LZNAm9X9hugeH4YAdsKgGqSjcbbsLS7K/vOxx77215ddNjQBeOt2vHj5js7gACQBciRiD3YZoRJCOzmd44M4zLHUEk7SQQIJ4Baw9L0XXPCKIMCb69wNxSgkfPXVUPlaBl+WVzrtH2QOdH+KDEMADcAh5HUuznYFKMCP8tGv7t69453r198Vd8GujnIj4X37vnI9OsB2nM6FF85hXAR7yvUSQJt1mro4cYY/9Ilk8MljQyaeW8DijYsXr/7gxRe//hXnnPMSTqwr9x06dOdXdu++N9pLAHyoP52Hvq5rf8/hmxKAgXEA2oRRGChTMRrmMhE+i0/84wMPfO5TW7duGvS3A+Pcs7YfPHjwU7/85cORzZGH/RBAx3iMsQGDeo9pJxpRT5dm/ltFAMfKBJjgc/4fbdz48t9Zu/bGxQsWYENtiR+SOPbJBx/8fJzgvQt850qqX6vm49xqj2VDJ2Z5EM25Jp3hXsjnYFKxB4Ze2UmTf37RRa9754YN74rywMIvbcQnij0/idet333gwC7euh0PkPglUaIEZ0k6nITDJKUOEnR1NKkl+sn5oos582CHe/vc3uUOHzd56n7OL48cK9wXYoX7ctQ/HYlb6NzKJnkbO5OhigjRdDBxYoOd9VxrHYIzSEQkyaXQq2GefpEmSZ+96qr38Fu5kR9LxwNB6Nvfu23bZ6MI8Dy9hAQ+z4DcEhySA34mQBQHWtFoXwjL1zAiAejDfNaQgrIEKY59e+/e+163Zs0WfjqdE1/o8vjRow++7+c//8wzJ04AuhFP1AN6vgbwWoeVLa9iOR+H6ksbBHA0wFUyCaiDAEhBiJjoydv377/3NatWXbEs7v9PH3ph/n3y2LHH4oekPhVb2ZPhAcAn6n2QVSZA1ZbWGHw8PiwB6EOwzZe1x9UcP+up48ePfXfv3m1Bgk0v1JWAyAf8+MGsx8MlM4GfI78c/YU/m/5pgwB5bEBWMuDkT2PqgampZ7/25JN3vDR+QetFZ5+9wRNfCJo9n2U/Rb4EyJ8AvKitIsBp/mzit7YIIPBljU3WlfOUT8Z2MPWlXbu2xS9kPRs/MXfpgnnz2rKJ/uec8FHvf3fv/u+/2rHjlrTn52UfAnj/BALkTzPl6B+aBG06OwOdHV82kjLJyaBPxKPPX9xx4MCdly9btmbNxMR5uYNflzw3eT56332fufmJJ34ccyLijXr3fKOfj3uC3+uKv+zXRm7qBVqjzuIk+jNxwQfB0Hw09O4cN274mFh+Zs7t0+Ie+pvOPffyd8W987aeHUS/Z1S4t8/t3c4dPkDOyat9L/jyVT/guwIYMAKvHmpuoyAABmUSSATvEUgESJCJICG8ibQ4fjt349vWrbsxvi300jrfJxjKEy2fzPN8HunyVK/zYAeATUa6ZZf8HPkCnz/vC7p6aKvbJgAG2Se6+NgXOq8ErgYQAQK4IkiGrD22KH6DeGOkLRcuWbIxbreuW75w4eSyBQsmB3nIEmO1Lnx1m2/v8gVOvsPH17j4Jk/6MgegCjA6R7r1Al+17BdbZJwn6OpW5iJYrXSWOrFftERwJYAMeTVwRQBsATevpo2Jc+0LLcnQSB57uqadvzoenZMAuVcTuSTAJAGuCcBz3uO2t48c9S79cWqXBORbEZw5CsFBAqGzmAiSy+SpZ8LZcZJC0NGSBgKZMviOV9bRvBXBViRrwREwAcxzyUQQcOsy8OT1Bdq+83iM36qMigAYqeHkmYzAUE9ykkwcO3QGeQFX9wI/rwD2X9bRXSvifLIWJOciATKhnVfW5Em243zy9qOP8lhxuH0ZJQGwlgkAiBNhggIU2UKcrE7QKdjGcok24tUZeFcB+1UXnXf+VNXl473y2p2PW5ftJq/9aubhXKq0x2mfk/3mcfL4reabOmZQIxwna4ETTDUgkxfsXLYNmr7Uud+oPo1k1LUhZVAECwDJZyAzwOV8bpfPreq/Dbt79qHjejZo8UAei3xOApkBnimfz815zaVuFCJA9C345AWxTIIy0LlsW/tBI2U9XTuiv6Ny1EzmOmbW5HPKhKDecm6T84xHWcl569rQgkNf5tHmMxGos1zWnqMu90d5VmRUjupnfB6XvGXzdTXjeG45T3lUIuD0b14wB9H5/HKe8sglO2/kg/UYQBuqdK7Leboql6u6t03VsUHqBLnqHI9V6VyX8/RTLlf1PfK6thw0rKHZjqq8dWXtuNZbni0tiI5nuZemncfKefuYVX2mHNdvktmunOe8ctm+etV7vG2dgcx9l+v7lfO5s56fbacNOsFe9vWqH7T/ttuXwbb/XvUeP2N6rjqyjkPmmu1zFuQ6zhy3GXtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeGHtg7IGxB8YeeB544P8BmcASPPFxdCoAAAAASUVORK5CYII=");
            t_tileTex_NotSame = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAY6klEQVR4Ae2da4xkx1XH/dzp6Znu6X34uc+ZXa/ds3FiPsR8QEK8UYjgI0j5whc+gFACEQKCEiI7GCEjrZzFTmKSSAkivKJIAQGKRBzsOMiP2I69rF87PSFE4qVMz8gGbMCsWc7vdv9vTtfe29Pd91Z3r3WPVHOq6tatqnPO/5yq++i5V14Rl67sdw8P01UZdX42F63g0/8FZR3jHPKzoMtePgkQQ3kyOH17Y5MPk9pqPjKujA73ieM6JuOL26GpkObMYJetfNdEUpUMSfdSlDf61X2lieuYpuMBgKHftCROf+QhAaFXml4k8PLJ+JIBLrnEdczPU3OXXOJTlS8GAGRwcQkvxaAUxvVcx1CQFICCMDzpQsCpUzvLDiwBnBeLGBOSbPA8+SSjQACHNO/d5KOtZBH3deQLU9kACBUk5SC8DM6YpGv73CvKqlIF4REy/P/28/RHnnE4Bkk5cI2vuqRByX8YQ6ls+dSv5EAHkiWKfGUCQJNH3+S9crzRMfyefiIvIAAQ9aGQj5Ex+BuOexDQDkJRkJQV5pODBf7IIJqf5GPOzMfLh2yScTf5BGzJR3/UkaAs+QQEL2uv9QR/GbAMChUkxcC9chasTKpZWuynuvL33377PXfu23fnV7vd56zOA4N+vPKtOGBsyjHJjy3jZxl+V/m+d//+dz5yqXz0pTFCOWRocR2nfWEqEwBeMfTrjS/FyOhLdlxp2fL106dO3X1no3HnicXFW65fWjr8d9vbf2/18iD6QkmhokpRgvWbRzKK58zBy4bHh/IBauRDtkROk+8u5Dteq3n55BySz49jpyYkw4urHl5YfgYuSn7SMpIUJAN6BYXKWf7dU6c+9H3N5ts1kVsXF4/tq9ePPdYDAUpSv2riuRQDL6wQ33G/vyz5ZDjJR0RTVMuS74M58p218ySfxvHykFfZsgmFZdVPxIsCQAqXZ3rvQDnyjtDz8YyGpeXfWV//je9fWbktnH27Xj+4Uq+vPr69/bwdy/MQjR+eXrQsY3geyoZ8ADvL8JKvYfJ9YIh8ayYfkU4A9/LI0OLa50g21ftzdGxkXgYApCQpyHu/B4AP+Ri/8dvr67/+AysrJ/Jmu16v37hcrx9/cnv7nLWhf43FKVJAFi+kFDeOxpOBvOcjW+j5GJ7UtIR8v2ryHbd8JiFfo15fe6IHAsZCljDpSkBc8mb2OW5lEQBIyXApyBsfD5GCMD6hMfUMlPODKytrVjeU3lavX7e0uLj25M4OkSAEQXiu5hTWj1rm/DAxZihX6PkyPMDG+M3fard/5YdarWOWH0qn6vXrDeRrBnKWA298GRyuvI7Tp4AAn1juogCQsqQk+iPhHfIQwr82RPJ8jL9q9SORgeBAfXHx+Nd3dogEnkKFSCm0mUQxkkccuUh5nu/Xe2/89/9wq3WESYxCgNxAsGog4OqHeWNwXQrDqRPPAoMdnozKAICU5BXlAYCSpCjC4q+N4vmhOLfX6/v7ICASYCBIvFfq/R3V8DKy+lEZLpnQD8bXZm83z1/5SLv9yz/Sah2m03EIEDTr9aO2HDxj5wkAGF2JOiVkJEHivdKYfycFgBSPorzCpCwAgLIwPBEgCZFs+Iat+dZuKBkI9i0ORoIsRfg6+qOs+Wb1r2NwJQFgLM/vG/9Q1iCj1NlycINtfI/YxvApa89NMKUQBMjkI8Eo3We2KQoAFCZlwaUwjD+wBNxrl3pZu+HMWQ2pzACBDBielWV42lIv8gb3sozq+cl6b501+8Y/qI4n5WwM7RL4ZrsEfsL6AADcJQyBIABoGC+T6kbiRQAg5cHpBwAQKgGBIkBy+cdNHrsOvt3qS6EMENCvlOC58uG4zBnyMgjIyOIBICCzodVSps1sAgAz/i9Z2C9sfCYE2SXwIbsZdqPdDHvMitwWBgBwHwmQTcmyk1FZAJDyMD59AoQEBMnt3UbjnZNNL/+sDBDIqOFJKIlj4jo+zPjp/K0xhgfIGF+7fe/5pRrfxkiIm2GHlpf32W3xR60C4wsAgAFZSlkCMFjZJMXS75U20zzDFB73PQcOHLdOfv6BTudB1xnKgbK4B4IUSFvqATHgFYABgTZ9GF/en1zJWJmwH8X41renUH9h2bcdO4+wk5AmAVcKFZgsBV/6zneeWF9ZOXV4YeGmSQba7ZxdIgFzAwh+vnTJXKmDk3zkkuG1ifWGj+75NpeE/mpn55F7zp8/bYX/tvQ/lsK9gAAsoCfnjfunLABIofIgFKoweu3fbG09fdJAcHRh4bpxJzhK+wwQcFqomLDsAcC8E8AaZ94+7AMAvJ7wH2XNt34H6Ivb21+/d2PjPqv8L0sAAOMDAm0GMT77AWSSXOJWNTqVAQBGQ5kk+hOXUhMwPGQgONFsvu1Yrbbf2pROAQiYAwT3ilG9ACvP94DVZi+9fLU+AMBUjP8Fuxl0emPjjI33miUAQAojQAgAL6M1H50mBQAjSJlwJYVU+vWhFQVf85WtrWfXms1Tq7XaXiuXTgEIsvrXnAUA5knC6xX65f0Ddy/tePQ1//Pb2y/ct7HxgI2F8V+3pAggAOiKwHv/xMa3/hPh4ZOQjM65yosLAB4QibL/1kCw2gNBa5JBdzvHgYA7hpDmRH6Y4Vnzk8tW4+Funzt8UTd8f9rtvnym0/m4jf0flgCAjwAsASQMzzJABNAewLKTE0aZlFCsSHkpW1wA8Iq/ykDw3LFG49RarbaiDsrkfRCs2bODEAThvJLIZGNjfL/pGwDAR9bX31fmdX4oqxl/4/c6nU9YPcb/T0s+AuR5vwAwswiAHFJomJfBxdVO/KqHu91nj/ZAwNpaOgEC9+xA84CTCPcYn3sVJHk+YZ/EnJJ1P7bn/0m3u3n/oPEBAOGfhPFJPvRnef/EICgSAWxeCQA893mMLZLhxam/0kDwXGQQ7O2D4AUbT8aHe8/3AMDzAYCM/17z/JutHIX6xucexr9bkvcDAL/5AwD+TqD3/IkNb30mVBQAdBIautdz76+OecMPnNMHwbotB7Eiwd7+A6QXbeBkH2I83PTpRk96uXd3u/2LPxrR+H/c7X7TbmD9vs0F42N0ACDP59KPpDuAAID1v1Tvt/4KbQI5P49keB2nDFrFqU/L0wBBrVY7/tTOznkbFxAMBcBd6+u/8GOt1o1MMgb1je89X97vAaDQr1vAAgB6Uyo8vTIiAJPwBs/L+8mqjfgVsUHw9qWl1oI9SjYQdGwiWWs/UWD5rnb758z4N/jJlpnPMb7f9eP52vXrxk+e8QFCISoLAEwCY5L8pEKkqqw24pwfHwT1evPaWu3E0zs737Lh2PVzzU9i3a9/uN3+2R9vta6zfBQKjK/Q7zd9GJ+k0I/hvfG1/jO/Ad1RMQmVCQCNn3p1v8KXlRenCYJQTgSKHQnesbS0fI0tB8/s7HzbxkwB8Jvt9k+/q9XaZ3VRKDC+Qr6Mr02fPD8M+97wzK8U49NRDADQbx4xcU0eoSBfl1TEBsEdS0v1q+1FUwPBv9mAtQ+12z/1E61WlE0oAgXGl+dr00f4x+tZ8wUAvD684eP1ZYfLoWkDYNisAcLUIsEd9Xrtqlrt6LtuuOHku1st1v8oFBg/y/O98fM8X04jXtpcZwUA7/Ue2QMCxo4E37O0dO3JWo17AlEoMH6e5wOAYZ4vXQ3opqwJTxsAWvtTT88QBEHVLvrGMGP8Uqr6xtd1fhHPj2J4CTltAITCUFadjwTMj/oECBYJzh5tNqPdLGKwMskZ/1Xrdy49X/JOGwAaVx4+LBKobcIftgdI/dvG3K2bW7Lbu//g7vDJ88PrfG34hq35coyoss4KAKFwlFUXchTw3UjQaBAJ5hIEGN8e7BD2MTye7wHAXT7We635GF83eoh+JOlB3Kri0qwAIKl2iwT+OHmeIp49YiCw39nPFQgs7H/LPP9TNkcZHuNjdLyf63y/25fhdZMnNL41nw7NGgDydknrkR8eo00CAvsPG+cO20slBgKe3s2c/mhr69sf29z8tE0EoytxkwfjAwIBgN3+XHi+zSOhWQNA8/CeTp0vk08Mb1yPdK9+ZGvrhUMWCU7UatzGnRl9rtv9p49vbn7WJqBwL8PPtedLYfMCgCxvZ44hEFIA2LGr7UcTLx9sNG4zEES7kSNFZfE/7Hb/9ROdzufsmPd6ASBvzQ/v7yvq5ekga+jS6mYJABlXwsjTKSuPwckzT5Je5NDj3D0Ggm/e3Gjceos977XjU6M/2NrafnBz8/M2oHb4WYbXbl9rPms9APBGn4nhpahZAoA5ZIHA13sAkAcAzDkFgOX3PNrt/uNNjcYtBgIe80anz3a7r35yc/PPbSAZXxyvD9d8v+5r0+cBwHxnBgKUOk/kFeGVlJdPd8/3vPTSl//6lVfYaUelz2xtvf7JTucrNojmxBzSeQR5tQnnRL3I51U3NT5rAGQJ75Wm/Kh8WorLmo8HQdZx1U1rjiONMy9LgEI9nBSGer22zTqvX+qy8Ute5DBe/2C7/ZMxn+rZGAnxAMkeJR+0R8nnrUJrvB7m+HDPug8o/JpPHwABEg+Xwd7RKf2dBwD4DR/GZ04kQKC1Xm/vYHxAgPEFgCV7meNn7Hn+1G4M8SjZXio5ZCB40eYRGp8yRgcAWvPDZcIOzQfNCgAyurg8X8bH8Gzo5Pn+vX1u/mBs0jKvcdmbPFF+amb95xIvlexZXDxqr5e9YI1kbAyupCUBDsnjQ947OqO/8wQAGT/P81OPN10lv9zhBU57h+/AjHR3xTvq9eUFe6nEXjQ9Z3PwIFDo954fAmFW0x4Yd9oAkMeLD/N8hXq8PzG48fQXO/1Xt6O9vTugpSEFe9u4abcgVg0Ez1szvBtDey6PVy9hWfUz4fMCALyeRNgn/BP6w7Cv0N/kRxsx39u3scciXjm3H5+s9v+PIQYOE/0JGOqbNjjCTGlaAJDHe64NX1bI1ybPez7e37x7ff29MX+xM6k17LeI/AyNH6SyHHiSx3s+c8NrgrMCgEK/PF+bPsK+Qj8gSL3e8snv8+fR+FImILBI4EHgjZ6V51TqZwaI2ADwHq/8MM8n7HNtT9JOH74S+yfaNkYplPHT9Lx+Z2p4TWraABjF82V8vD8J+7F/oi1llMUdCPxy4CMAQ1FWncpTjwSxACBv93w3z1fITw1vWon+b1nQfAzqg8D/g+s84840EkwLAKN6/iVrfsz/zPGZbvf1f3njjTdj/TYgAwRgTV7vOXlfzgNL6ViNAQDv9eTn0vN5pPupTuehr3W7HXuUfCTWo+QMEAwz7rBjpRufDssGgATA6DI++WG7fdb8qXo+L3PY8/y/sHGTt3TtfYKX7aWSY7FeKskAgQ094PEqh5GAehHHpF/VFeZlAoDJyeji9O+N7x/qzGTN5zWu/ps8vMGT/irXQHDOXi87Eev1shwQjGJALQ1qWyoQygKAkCnDa80XAHSHz1/nT93zeYGz/w6f3uARAJLHuvZ62bnD9maRvW3M3EqnDBDI48UZ0z8z8Mb3edpJ5+QnpjIBIOPD6VfG161djM91Pp4/dePz6rZ7ezcEgB7pXuCjjvbK+W2xXjnPAIGpIyVvZJ+nQVimrjAIygAAk1AKPV93+BT6Mb5CPzd4dJ3PZ1YOWjkK8aON4L19ADCwBFgZECRP9OyVc358AgiYY+kUgECGhZP0zMCX/RzU3tdNnC8KACHQb/pCzyf8hw929FRP39iJZvz+b/U+bXPQjzQxPC9uAoJkE2icH2uQ0mf5RIIjzWY7JgiCZwcyuE3jEiCozhtfedmANmNTGQDw3k9/IQB86Ge3n97osTt8eP6hsWc94gnut3r6uRbGFwAAAWs/ILgEAFZ30SIBP0iN9ltEIkEfBGdtPAijKgLkcRk+OaHonyIAEPLgWaFfa79f93V/n+/qvd+Mf7ioAHnnu59o60cbcK39GJ0NoNZ+PJ/wj9Kl+ETR9lvEZ2P+NB0Q2HcRV+27iIBA42dx5qNk2SQvLltQHouKAiDL++mTsE/Srl+enwCAjyqO8129sSSyxs74eL4P/QAAz1foFwAwPgkgSPnytIv20/Sz/UjA0lU62Sfj9vdB8Kx1zvjpUtQvq445kRcQNEermozKAIC8H65rfg8A7frZ+SefUx3li5qTiTNg/FetD3m/PB+vx/h6m1eG90YnDw0oN4kEveUgFggONOwdwyd2dp6xsf28QmB6AFwyTyrGoUkBoJDjN38CgN/5Y3w94uVD0R8Y9i3dcSae1bbv+Q/asXE9H6XidVkelgLBQKA9QRQQ8BlZ+27gYftu4NM2F4FAAAijUwgEO2V8KgoAv/4LAEQBLvu0BCQAKOu7gXkiBsbH89nsec/H+0PPD0MtxpbBxa3quxQbBO67gY/bqGxOdXkKEEKgamKZc9XBYbwIALT+w+kHAOD9AADjA4Lk8q/s7wZavwMUGF9rvjZ94ZqPUuVdXqEyvueMI+WKR//HVdV3AwfMO7wQGF+er0u9YWu+D/mZhg5GBgCAPQFC7Egwre8G4rVlkyID/Ub9bmBgfDx/2KZP1/ryfh/+lVcbwq7uERBBSCwn6j/ZY3z4pZfOPPTKK/9s9TEJfXoKy/7Y2PkiSwCDydhwwER/pPRqwL4b+HiM7wYGxh/V82VovNgnKw4Q8iSePlDbK1CfHo8VCd5K3w3cU/Z3AwPj+zVfnuqv88M1P2v3LGOLy+6UVcd5kK9LKsoGwVvtu4FJRCjru4GB8XfzfBkfz8eA3vgybGLE4A8eDqWe3isO/OX89HhZIPiC3Xk83emcsb4BM3uYvKuXUWWxLvJp0iWAHr2SyJNYBrQUwFkK0iXBvhv4TJHvBtq9/c3+d4L9eq8NH2u093zWcQyvy6cshQkEksWaJ6R6X1Yd/UCUVZeUDQR8CGvi/2hq3w18/r5O5wHrTJevkkeXrwJ0lizMYWwqCgApTgAQp1+BwQOCT8YBgvVxPx5pxu+4r2tpM4ai5CkoyytK6z3KylKYN541SQFNXuTlC9urjerhFw0E37BP4gGCsT6J92fb2y+e6X00Muv+hW5ZZwFa85iIFwWABvWKEgjgGN/zJO9AMNLHI/moojO+vF+KEgBk/N08XwbT3IfxsG1i5P4JHlRU6djYIOgb/2PWBzKRkIkUgppoBggYKxzfqsanIgBgNBk7zHvDh8coXzQQPHXc3ryxbwnvoyKPUI59VBHlhOu9DI+S5CGEyN08P2+oYfXIuRulALCGgOApi3Tt3SIdYd95PjJmRTWFfi8b44l8XnUj8TIAwEBeQVl51cFTRdme4En7oHQ774PSfEj5o72w6I0feogHQFaITMcbSSPZjUIF+z51zHsk+TcN5MgHyPdndYt89q3g++2YPN8bn82fgI3nC9x+HI2d1f1IdUUBwCAybl7eH6cNk0aIREkGgsdvXVk5eWRh4XoOirgUcl/RRjFeOQqNhH0UI+UAAPXtjWTVUcgDWgN4+S6YfI+dXFm59ejCwnVqAM+QT2Ffdy89sBX6vWzqrhAIygCAJuK5FCPOMW+QxPhWl3jsl7e2HrWbRbccXli4iYZ/ubPz1Xs3Nj5qWRld3Id9rfkyft5uv5CCmM8QCmWiLCMpGl2wS+AB+bjJY/LdZ20ll7gu+wRwZJPxBW4/5pCpjXaoLAB4L/f5cBZ+8gJBEt7sZtHDd+zdu3butdeev+f8+dN2opQhjlK8YgiPoXLo049hxamSB4CX74LJ94jJt+rkQxYBOsvrRzE+4xWiYcYat2P6Un/aBAIwku4H8JSQJ4Z6Z0B5HVcfXnkogoTBxRPQWBmvkGeExi+sHOvbk+YmjowkyYcMkieUU3rQuZqz5JBckpFyFrglox1OgA4vREy6LJLCEVJ5JizydaGBpSDacj7HSVKCFCKueimStvSvZNnSSfNXx4zpSWP7ucvAo8jnZcuTT+OFc1H92LxMADC4n5jynpNHQRiOsREa5ciTLJsCgLa0I3mFkFcfcNqpX8sOzIFymcQ4IuU91zwuG/nKBgDKkUJ8JEAh1CvJS2R8hVPOh8J2AoI3vIwPF2lslWNwjfGWkA8hYpH6hivJ0JSVh+s4HBIA4AKLN7jyaqdz4NMizdXPXTJRp/xcyychYilN/XslSTmq8wrSPORlAoAMHRret9O50+SXvXwSIKbSNIbn5H1ifB3XXGR0ysqLq85z8rMgzdtzL5uv9/MLZVEZDoW8V1vyX02u5G4v6c6PI+XQSPXiqguF92XlaevzlGdF4fxVDjnzo07zzuKqo63PUy6dNMHSO87p0I+Xl/enegXk5X37WefzZPL1fo55Mvl63770PLvwWVCeQsK5hIoIy2H7eSlfNvLNCgCjGupyMfio8oTt3uryhfJW5UoDlQYqDVQaqDRQaaDSQKWBSgOVBioNVBqoNFBpoNJApYFKA5UGKg1UGqg0UGmg0kClgUoDlQYqDVQaqDRQaaDSQKWBSgOVBioNVBqoNFBpoNJApYFKA5UGKg1UGqg0UGmg0kClgUoDlQYqDVQaqDRQaaDSQKWBSgOVBioNVBqYTAP/Dz5Aj2JKB8e6AAAAAElFTkSuQmCC");
            t_tileTex_Any = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAasElEQVR4Ae2dCbCeZXXHzb7dkARCEsAkkrCFiBEUEEYRRjvTcVoU7XSqSN3qUnW01Vaqo9aitXV0bKbFOo5LK5ZiO9VOR2sZFLW2FWUTkEBCIIaEEIQskIWbm+XePr/35nd78uT99iTfK33PzHPPs57nnP8553mX7w2Me1ZvNC4tj2V8alsmHKzDrTNGnTXU4VDOR3sP/ztysCvy4dRHoe/AwTo81p3jPOYqI1UL+lW3I7dHu5ryiU1Hmw9GwKjrXDmyKTg81mMw5DLS1KakkTpQh+rs/Wk1dbh19qBPYk0ZqQv6a0Ouezt2IBtZrUgb5AYpuuY2YEszO8Sl1Z6HjWNQNxQNpC5oAjcp9SEbHusRQNew3pKqBUX5dGhg5NQBCuAiaPtSm4Lz4FCUpwz6rbu/OrGWkuse7XEOnPWsVU6qjlGzvdmfEp1v8MK1RbllsqIN1sc2b1XpNgCQG5WiHp0PUJNDmXKwblDAAU7AlZW6DnEWbUjD5ABGPToewPamAmjwoVR0Cn3Mt7A+kvurD7qpK7aovzY51sgO5EHy0dboX21QF3gjO7BBnJQV12NH3j+6S5t/MaAXYnOKzkceBaAAjTL1YIkgOi8ap6w0/TCKRlOPGQN4ZgqACZrymO8a66mrkAGHnJvbovO1Q5vyQND+KEe5xQbZH/VQLwPA4DWAIz6IcD6cPeHsCYdifbSnxd9uAiAaad3MQZ7ZD1jTU5kWigAyh4KBFOWkaqkRGginABhB4HEJYBRkooMyU/WQYGFNBI5xiP21gbW5HdpAMFNvZgdykAfJrWsHbeoGMnZgk3YMprr4KC/Otw6nsA+8Y+omAOImOXCAh+JkSAHWBd/79R+m+jGnW19+40vSpgBssESuYwQOnttiEODsqcmOHyV+zCnZcWnaFOeivyXalboL3bWFdtvUSwAImsCZOcgsQEucbOkXoQNHKvqgmxkOB1BAlLTFOdpCMFOQ1S8CQxyPLd4Yqqd6d5X9GISgTogNocipq5BZ4z1APwPA6zQOjEEgaLkN9mMLAWAQKCd19YW85KBHtEXc1bsr5ToNgLiJG6uIwAE2xSCIa45lPTod3aK+6kFfpDhHe+DI6hdx+uTOR6doE7pF3Wm3RQjplBqBFrOGSO13AKiPQMnLgIp91plPUU6nOB2p+WUBgE7qKe9qPwzshtxULrgC5ilAIPSLuC7Ga6N1edTLPjlj1GOJ849lHQwpOB18I9bg3xMhrFeKQaCCKEsQVCEAdCJ26mA5fa0orm8192iMg6EJlQeB2He9b68BECNQZWIQoHC/iGdq75x9BNSZkauffT5iscb3DMjpF+l08AVbcY76lPXF8Yb1XgMAwXFz6zEIGm5+lAdy58cgYGscDun4yPMg6HcAxCAQY/moFV3+PZJ3tyqU8y5V63nZniSh7BTAuZSyAChzPDJ4vdwvyvGkfcToSAWASnWtbHrj9Y1kFa9AKThPB+IAj2KyOBb7mUNxHTL8XYB+Mth1ZnrqOiwIDA7nso7sm5j0uyxxnsl5ve0rYZ508kc05puxXrudxzru6nmz+KrE26EyTO1rZ33TOUcqANgEpSLl7ThWVsdpT6eyOxUDQSfG41zn4CwDgHEK82Mg0I5rdbBB4CmQphWnApcuTwFks5Y+HZqqBSnHfb1R0/lyA0A93bdTbNi0mzWj2jb520sANFPIMXkTFcaGcDrO35WKgYADyWqB1vlwHUVdZzHP0yByxl2r83RGGhojxtBZmTifNhxyjXurVycBgJxOcIlzYx05UFnf6Egbf3sJgEbio0IxwxrNtx9HewoQBJ4EBgAOzZ1oW45DYjDYNgBwnE5UN3kaKsYMEGUqL54EBgZrIGXGtZwCtsWEPk8F1vWdjkYAdGuUAYDjKTtT8VKA83EmTsEhAht5dJjzdLxjztdhSdQY0cc4BFcGzsPhFts6Fa48Hcxc91Jm6hq9n0i8n+9H0GOMqhQAONlrvo73RPA4zx0ZQbbOHOrOtU2fjpKnrjHSoXQ4Hnm+nnmsoRgcBIB1x1JXQcpST/v7ylG2KmQAcBJ4GnAvEIunA9x+g8V1BovHfwyA6MTcbh2U87iGsUg6efzEWZOmrPjaJX908uuWPDdNAFfHnM9anQ+vBFXpBMBRXm9xHkVnGhxmtUDmzhJk+3Pn2V8GfnSYdbgZ7fEOZhzh/tjFo93ksz5zwe9POWn6Oae88fTlk+ZOveHhv77v1tTvetaw3hOC/nYJnY8aVSkAcL5F58sNBIMkdzQA6Vx53mcbDjGvzBH2wSkEgM7LnV8805/5ly/8remnzjw/zXvWuPHjxs+/fNGVk0+cumDtR+68ib5Eri87GUZn9OkvClWFzGqzPPL8Zi6OxboyDJD8BMBWxqDc0To7OpxMz7Pdl0G8EJqx+D1nv2zWC+e+AoGR5lw072Vn/82LXjdu0njm5T/pVgb3yiiSQNJ5kUfnUjcQ5HGcdbTj+rLTIE0ZCwLqkNluEJCxZHtZxhsAM+a/evGKeb+x8LUIKKOBZbNXnPPlF785nQbHpXECCXmeBmVLjnlflQIA43VYWQbj2Hw8tvO6YNpvG94o+8sczzWeUmR84jNSGZh94YlLF77ljLdy5Kd2Q5p68vSFZ3/uojcMLJ89N01CPvObrmko7CgMVEaRZJuOynl0vNntnDhmX84bwZZnPViYnfHY5/gey/pUH5i+dOZJp37gnLeNnzKBwGhJk4+fcvwZn3zB6+a8ZP6z02SDoOW6YzGhagGgzTgxkk61L447Fvucl/PodI97He+R7939YY5PwgYmDEycc/rHzn3zpFmTj8+FN2tPnDFp+slXLr0gzfH0aTb9mI1VKQAwWmfGenRsPt4tUDEQYgDEmz6yO2Z+cfSf+anzr0qPe4s73Xjv1qHta//0Z987uK4yQUDU/38hnY691HW8132P/dzxA2kuZWbK/FcNnDnrnFTviA4M7h986M/v+tbeXw7yAov9uHRVgqp2ArQCpdvMiesMBGw3CLzb59iPRz83fkUALHrHWZfMefH8S1O7IxoZHhle/1ervrXznu1b0kLvYSoTAFU+AXRUdB7g0+ZSIKevGbkejsPh3uzpeK/73u17x184f97lC5+XHvmuaLZJo7FHr3/oxq3f37w+jeN09kP3yuBeGUUSKK0Ix0VnAiRkn+3R3tG/jrkWXpb5BADO9/gvrvepPTDrgrmnLnr7WVe1etxLcw+jLd/d9N+bvvrgXWkA56OfpTK4V0aRBE50Ul43c+1P08fmCypjZeSaRo7nyM8dXwTA9CUzT1py9fPe3O7jXtx8xz3bfr7uUz//QerjNbY6EmjUud+oBFUpAMoA0XmR40gyCg6YOdlnQMANoHj0Y3s8+uMdP497s0/72Llv7PRxD2UGN+7esObq2/81VfmFkgDIiTeZlaAqBYBONlNzjvMk5ubHKmM4X8fTzmUiA5vJwJj5h1zz09hAetx7fXqLtyjVO6J924e2rrn6tutH9g3zQYs/ZqEH9kDU6a8EVSkAAESHCRigmbV5ADAHh5eV1F0Q65UVnU/me92PmV8c/ad//Lwrunrc271/94OfuPu6vY/v4Y6f7xRwNNluMKMLetQnQAIhJ0GKTidAKTrZOWS/J0DOmSsxX9DNfB2fX/dHH/feteyy9EveJQpol48cGN7/8Ofvv2Hn3ds2pDV+pIKj+YHK4FMH+ipBKFQVMlMNAHQTuBgA9BkAOWcefZIBgCyKmZ8/6xeZP/+KxefOf+Wiy13cCd/89V98c8uNm1alNXzQSgBw/ffXSS451NWhDoAERk7R8QDldRqnGggCKsfZ1uEGABxCJkV5ZD3O55p/yHV/1vlzlyx825mv7+Zxb+sPN9/8yN+tvSXJ9GtmP09Dj6iTJwK6VoIApioUAwDnU3AwABIAgGfGR6dTtxgQqatYZwAgi+w387nujz3rT1sy8+SlH1rxlvGTxjOnI9p57/a7HvrE3f+eFuF8A4CPW338Qx42cMJhg3akav+pSgGALmYqjgIogyI6OAYB/cyLnLqZ53oDwBu+4nqf5g1MOn7K3DOuOe9NE2dOmp3aHdGeTbvXr/7AbdenRdH5fKyK87kBxOnxHkTd0a8SVKUA8JjXWTjSPoEbnrpwxtQ9G3cDOH1mlHfbBgNjnhwEgdl/2NF/xifOu3LKgmnPTnM6on1PDm1ZffXtXxnZO7wjLTQAuPYTAOrjCaQd2KQtqdp/qlIAxOw3QwgGnFpk9NIPr3hZ+kHmqie+vXHlw9fef+vBMcC2GBAGgA7gRKEYADNTfebp15x3xYwzZp2d6h3Rgaf371r7sbu+tPexwSfSQo99HO/Nn4GI4ynR8YUtqa8SVLUAIFNxJsTRiSMB71lnfeb81xz3/BNeQX3e5Ys+OGnOlOsf/Phd/5GazPfINRDMMsAnCAwArvsEwcxF7zzr0jkXz3tJqndEw/uG9z587X1f23Xv9g1poZnPz7wUrv3cALq/+NYBkEBpRZ4ABAHOx3Ejk06YMvms9BHGtOcMjP0Oz5368S9dcNWyEy5cmN663TA8NOwr1zwAkEEQeAkoAmDeKxetmP+qxb+Z+jumzV9f940tNz3q417MfnXw5o9M1w5PpEplP8YDUFXIACBbi5c0004dmL/82oveG50flZ353DmXLv/bi/8gBcn81M9NnGVWqlv4InesftwLTliSftt/bTePe1tufvS7m7764C1JXsx8jv54/HsaeRnQ+XCJQKgEVSkAvF4WgTDrwhOfvWzlhe9Kn1Sf0gypaYsHli3/3EXvS8GyKM2bkwpBAI+FvllpLo97v9vV49492+5Y9xf3+Ljnka/jfezjBNLx8djX+fUJkABqRAQAzp+44DXPWZY+v/q99CEl2duSJs+duuDslS96z+yL552ZJueOL06FibMmn5hu+n4n/brXlsy46eDGXetW/8ntX099Zn48+r3xy4MAp1N0ujyK7nu9SicAYIxb/O5lL1j49jNf3WmWTpgxccZpH17xBl7nJjleCgiGIvtPv+bcy6eeMn0Bm3RCxePe+2/7cnrceyqtyzOf676ON/N1fHQ+W1bm2EcZqUoBwA3TuJGR4sZJ/Tri4ydPmJSu75enV7oXp4U6f/aSq8+5bObyOUs6EpYm+7i3b9vQ1tQ0+wkCj34DwJvPGARmvLzT7Y/J/CoFQJE5Gz53/x0bv7DmmzxudYPAuAnjxp3026e+6LSPPv+l4yaOm5W+xV8x99dOWd6prNHHvfuvC497efab+fG63yj7O93+mM3nmlsVIlMKAB/7xvq1ezY/fd3Sq5/3Wo72bhQ8/pIFp6Ujf+6058zkCaAj4kve0ce9TfelhV7v4Xnme8eP3sX7ioMbkViVzvyDelbqMRAAOULJqL1P/vjxjfe99ydf2PvEnl+qbKd8+tLjZnMidLpu682P3tTgcc8bPhxP8cj3jl+ny9maemWpSpcAwDQACIKhwfW7tt77zh9/8el1O9ceKwR33LX1tvQx541pv3jN5/jX+Rz9lGZHfxo+hCobBFULgMLxCTpuriiD+7fvfXLVu2+57qk7ttx6CKRHoTH48K4H13zojn9KoqPzy479PPO5BJRlfWUdL3xVDACOVjKMjAP83ekRbGf6yvZfHv/2hu9wfU59R5z2bht6fPUf3/b32a977d7xGwDoVXmnR/CqFABcRzkBDIDiBEhtnFBk5PqV9938yFceuL7bJ4Qkp5SKx72P3Pml9LjHx5zsFR1PIDa749fh8QRgH/upV5aqFABe/wkAnV+cAKmNU/jMemf69u72hz559xcOpC9wU7tnIph+sXLVV3eveeqRJKydo9/j36yX96xLPwRUKQB8CjAQyDoDwVOgCILt//XLB+77w5+u3Ltlz2O9gMblJP3bvX/e9v3N9yc5Zn7M/kaZb7Y3y/L49BHrvah8xNdWLQDiZYCTwPsATgKzky9wdgyu27lp1TtvufbpX+x8oFtUeNx79B8e+mlaT2ApP970EYDowaUJ3ShkvFlvAMjT0CFUvN08pKdijSoFACACrCcBoHtP4EkQLwk7uGavetctX3zqzi04sSPacfe2W9Pj3nfSokbOJ/vZ3yNf55c5W0eXcfRq1M9YX6lKAWBmGQQ6v+GlICG3I921P7nmA7ff8Ph3Nn6r3SeEwQ27Hljzwdv5mDN+z9fN0R8diyNjmzokH21V7G+VXgUDFNkVi8GQ9wGjmVgEzvrPrrpp6LHBLadcddqVzX5JTP+plkfTl7yfJ3CSDO8t4rHPkU8x85HvXqk65mT6dC6cQkK1U1yXpveXqhQAEQnALRybuEcv3MuD43DH92/+x3U/Gdo8uOXU9y1/x4RpE/nw8xA6sOfAjrUfvfOz+7YMPZEGzHg59xtcavKjvywAkKsTdX67AeB8ZPSdqnQJKMucHCwdnz8pjN0bbPvB5tWr33/rNelf6fJYN0bD+4eH0secnz74uOfRr/NbOV49/Gpp7OOVtAFJZOErZgt91B2Dx/Wp2X+qWgAAUB4IgC+RjZ4C8R7BpwUcunP3AzseSTeHf5Z+UfwZC0dGRg48/m8bVqZ/u/fz1OTDDm/88gDIj36W63z10vlyHa2zc24AROdTrwShXFVIIPmC1694dTjgk/USABoYziEgPCHGp3+iPXTvW//nk+m7wjft2zq0ccPnV/9nGve5Hh4LayleZpCjfAMAbhBYd4x+6uhF3SDg41aKn6VrW2Vwr4wiB0EDOEGC6xABxjGQDqBuAFgnUArHDO85MLLqHT/+bGp7avhMbyB4irCGgiyKpIN1LHrEunrQH0uzAGCM0i6xx1GjKgWAn4PjHJyB0wSVdsxwHaMD5GnamAMJFmTgUNYqwyDwuM8zP00dDaDEdTYcrCJ3TB3h9jEXJ5v5xb9HSO1pqXgipGr/6WgHQCfRawDgGJyGAwVX5+UZmiPImuh41rkWR8fiGJw1eebrUDDSoZHj7FjUlT7XGAD8ayTLMz4AAFOKdfsacbLDjDWjvRfQiQYAcmMxYJiHDMbso03R4Z4GznUea9jXvXU2mRwvS9Qd09EGSzwBGHMdthEA8SRIzY4JHY8ooWS31EyZZmON9iMzdAaAohuXA7JI5xkgzrOtg1mHgxmH4I6Z/cqKAVBMTn8MADNb55u1ZrSOZRw9nZ8HQFyPDIOAgDhS1A3WY3v3EgBjQg5WckXydj4/bwsKTkAvwONy4LUah+lQuHUcrHMJGJwAMU4/8iD0cZ2cPopz4GazOnhpQj+cCDcQ0LEsCAwIx53PWkuqtkXqCIdsj7Z6/HukAiBXTiXtb6lm+n/pvqblpA4mpP/X78vTdByhc9VJ58PtQzLz8gAg04sASPr9iEl9oIhho3rXahHtR4oEM3JA7heRfR7JOhddon4RUOeACYXkiKdAavaFygJWveVdK3YkAkBAUcI6XMW7Vq7HhTgvBkAzcTgfMgg8wpHh9b6Y0Ic/8aQSX9Sg3jP1GgBRCZVDYa7L3nz1rGSXAqLzdXAzUTpfDjbKIBD6Rd60gmcMBvUR9+gLx1ryXgOADVTAjI8BgNL9Imyj5M5XX3nUT+fDXe9pEOcdy7rJFPEtC4SudOo2AARPHpUz87kD5w6+X6RO6oge1HOKfXndtbE/X3+022DoU45PQtG2nvbvJgByMCJIOh9FfYTrScEeFke9rCMu1hVPXyTnRB7Hj2XdAABTT4Ool/WudOomANzIjeFEpMpF5/Mzbb+IrEEXihkDR19I/Udb/9eOcw1oZPWLwJD3G9ojztqS22O7LX07vblBONfHyKkLmoCjLErzKNYvMnMEDB5BEyh4LNqi8w3oftnhxyrRHu2Qa0vHOnYaAHGDHDQB0/n9vnkiAAUNJxoAOljQcjsYz23pBaeIWTd1P1Urs0Xdu5FbrMnvkNsRVHanDEAU3prx3MwrU999++qz7BWqQaLMtOyQu3adRL/GwnWiJw7gUMgWCqDFQjDkx6jZk4aKPbkcog92+OyvHdrQ6FWwdiBDWyK2sZ6mjNkS7SDotEOnRxvs0w4SjTUxsFOzkA1vi7qJ7DKnREMwNgLBfJREYYH1/bmgC1qa0pBiABgEZjayPXliIAiW89QzynJDxtADXZmPbshSN+1gnH5kG/i5Ha5JU0oJWRB7Ule/aAfyPf7h7Om86HRtScOdUzcBEHdxcwxBKQ2HQ4zTj2EY4I8jZhrzYrC4LnUfRsiC4AInEMgHHPdhr1jaBU7Z6qw+2uEeuR3YEO1IzQILeBlpS6d2aKd2I0dZ7BPrZfse1tdLALiZSsQgUBn7BC7PmAiaYMujsnEvZdMnEHCd5l6AJWAGgICrs7LgEOMQsiB0ca62IFM7PPqZF21JzYJyW7SDQeXCkU1RzzIbtEWb4/ooN4lpn7oNADbUOA2Iu9qXgyZgecYgS3lRTl7XULjFPeQRROsGCHMorlW+chnLyTUGGJg1s4P1rWxxP/WAx33UF/21QW4AaAf7QcocbbX5t9sAKNswB0/j6MfhGAAHPADKM6YVaGnJmJEaG4GLAFIXxBww9VIGctnbdq92KA/eiNwrcvWnT52jDfbFecxVRqO9mvb3EgAKjgqgnErhYNoorrNznobGsqWdAGC++0XuvpFTtzDXMfVDlqQs23Hur4Iduf7a0ZL3GgBsHLPHDSOA1Jmj86lbmE+9U4oGU48l3zuOWWc/6pI6xD7GclnMq7Id2tM21/C2FzSYqJzIqZe1Y1+ZOMfzsdw5jMc+6rE4bp/tyKlHcu/IqZe1Y1+UYd1x2/Koc1mf+sqZY921OVdOx7yRkh0LSguiLOvwWEeu7bxOu1MSCNZZjzzWlW2f7ZyX6feraEduV2k7Gls6oYvOXGZsxzqi83an2+XOjO1YR27ebrVXrltsxzpy8nYr2fl4rltsxzrr8nYuq6N2r4o326xMdllfMxmdjpWBU9bXidwyncv6OpHZam6ZzmV9reS0HOeR7JlERwWkPgD0TLGjD9DVW9YI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQI1AjUCNQIPIMR+F+cxo6fdeHejgAAAABJRU5ErkJggg==");
        }
        void SetUpTextures_Solid()
        {
            t_backgroundTexture = Functions.CreateColoredTexture(40f / 255f);
            t_toolbarBackgroundTexture = Functions.CreateColoredTexture(60f / 255f);
            t_highlightTexture = Functions.CreateColoredTexture(168f / 255f);

            t_emptyTexture = Functions.CreateColoredTexture(Color.clear);
            t_defaultButtonTexture = Functions.CreateColoredTexture(88f / 255f);
            t_hoverButtonTexture = Functions.CreateColoredTexture(103f / 255f);
            t_activeButtonTexture = Functions.CreateColoredTexture(new Color(70f / 255f, 96f / 255f, 124f / 255f));

            t_fieldBoxTexture = Functions.CreateColoredTexture(50f / 255f);
            t_windowBorderTexture = Functions.CreateColoredTexture(60f / 255f);
        }
        void SetUpTextures_Tool()
        {
            t_toolTex_Brush = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAnElEQVQ4EaWSAQ6DMAwDYeLfZH/rv0YPzbQz0LWbpahJExunYk4pTf/g8SP5lXnENCqwiggZjAhADkhvzJyLqi/nbreaCeU9Dq7Iz14BbDsOMo2WA9+Z+X1vEqElEBrKJ/mJTL8lQB9Ejg/bXAougG09Gl8kbsmIICBCvbPumGlC/0E3wdVwEH45UiPAjmEkr61dSq3gD+V1YVi2AT9HF2/yJ+QhAAAAAElFTkSuQmCC");
            t_toolTex_Pick = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAoUlEQVQ4EaWSgQ6AIAhEq/Xf0b/5X8UZZ2ipudgYqLwDWnMIYfpj6yB8uPoZ+eIueqmHURvPXyYowazRyAQZyENPAN2xa9yXkMXuNyBMzoukvDZBCVPkEd8EAIs6ojeKpu54LAUIi5EUIWzXdygF7pcrEw1VGCW1/wAgTNSzkXHpzQts9iCuoAmjjisAFnNAdE3bRgHRMviuPmRcoTtqTfUExlgXeRZvfBEAAAAASUVORK5CYII=");
            t_toolTex_Erase = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAoElEQVQ4EaWPgQ6DIAxEwfjfw3/jv1yfWZvSFWXZJQj27p5Ye+/lH20/lM8suwrQsu7GWgHE0vD+BBjC9tlSbH4HsJAr+uPlzwCYzaeTc2WWAbR8iN8IJbrKzCPAl/EziJUjIJbxkYcMZUy9waxM5iWryfoqy6zsPESYQBBfVN2WCSmAc4Q8liMgQtoHynwqfwMN+Zvob6kX95oBCAFZ0hujLyD2EefxlgAAAABJRU5ErkJggg==");
            t_toolTex_Move = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAo0lEQVQ4EaWQAQ7CMAwDN8T/X9V/wTz1MqdLQIJKU13HdpLtY4ztn/P4Yn4ddX3t+RTgRscprAuoDBW3PVPc9dgnxMT7Uky0ToDhJjQiaTwgFaZBnavuoSUgiMMgzLvDyj81BIj46fATNSZdfeQKJ51P4GKm8RXgdIfWA1LB1QsOs3hWWDSxDnwaG1L3OgG11GWSFdcGyOMGxzQ5724FRK0RwRsxpBtuAgca/AAAAABJRU5ErkJggg==");
            t_toolTex_Select = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAs0lEQVQ4EaWQAQ7DIAwD6dR/N/0b/+pyLK6iFlinWQomITaEpdZa/sErxIfz5jHj7j1rVM15j6DEHog/WWddYgRuXjrnKg3PNYKpc8DD85GB/kJ+PxsgIGQ0HG/2B4gzzJPbp45GQIggwzzRi856NthSA42320Jl0ddSGTAjgsw0GEsH9DXIQPmVMb3CcuGbAb1ZwJ5g3IZVmwnzCvM4nx25U9mfGNCYxRqr8ZMRMLhCJuUNKDosh5UXV3MAAAAASUVORK5CYII=");
            t_toolTex_Inspect = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAA3UlEQVQ4EY2RgQ6CQAxDPeN/W/6N/8I9WKEIJi7ZrddtvSpjnufHTbybm256J2qEQC4tPTWqJn9a5vJqhiE1zvLNXxw9c7qxgksc9AEtgHIOY510qMDldZoIYHOpVCXBInd4iyi4gkfYwcFsSFVIC1uoqHN8fwV12y5ymt6UBNgOsCuIDr/sO1WV8MzuYYGdKKC+XF5rnj5Ca1iAYXV68c7FulTHMHgZVPUilDgqLLzdtlN5sYPkwCxaUBAdqkru/0M6KP427GJEV42nfwSYzWU7W+uvn9AP/CwWeXwARyQvEf2lgl0AAAAASUVORK5CYII=");
            t_toolTex_Recolor = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAA2UlEQVRIDcWUAQ7CMAhFrdm9xbv1XtoXwdCmpZvWScJYP4X/QbOUc77807aA/BHkLJXs5dMYCaBnRLBH4FTXNbghQW5ZaiaAKVtfRk6jmQB+AlyK/8RMQDslZ1HGm77bWeEw9Pp57F1sAgBsWotgnvwOsNMkuFflvIC2hovmR8jpw31qW5MCVL1GAvzkFLE+MIzIeWatCCkFFTkNkn4JaZgAikEg6lbg8yV1yOiHWa/XSZ89AZBJcV/wjQCl6oetA9smOqn10Og/sJ5p0NFvgDWfbibg1LX7KZ/UXzcA8XghSgAAAABJRU5ErkJggg==");
        }
        void SetUpTextures_Action()
        {
            t_actionTex_DeleteSelection = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAhklEQVQ4EeWSXQqAMAyDrXhvL7d7qYEmxCpz4qMFWX/Sb3VbtNamLzYPNK+HZrMPsSxyAgiqRSZQo4/UKV5ShMVFiB3qvtfCASi4AXjazYrKj5wB+jgBV7FGAWqozo8AvGKuOoreNULEq1RDOgI9AQipgNfvoAIU+wSXRyJVxyFA/9TR3pZ2XHkVwJjw9NEAAAAASUVORK5CYII=");
            t_actionTex_Undo = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAgUlEQVQ4Ec1QQQ7AIAgby/6t+xv/2qhLDQfINB42EgJiWyuiqttK7CtkcP8rUMzdlSTueogtEUDpk4fojmnbONwBRBCs6KslQD4xYzQndMAhq3fEma98SOjAX76RgSWmRAJU96JRX21YIwGAR0ROAA9L2sF5NsIdTIlkXxgW+V7gBvx2GX/hLLTvAAAAAElFTkSuQmCC");
            t_actionTex_Redo = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAeklEQVQ4Ed1R0QqAIBDL6L+1f7v/slu6ODjlAl+iwXG4tjU0ici2gn3FDO/3ArK2qpPBN4dkLhHGN0hGVHkHNr2oACI74Aj+6N5sQNKm02A3dQ+HBrmfIjNkToOA0kdXiGEDuM7Q2l7HyQ5lXC2nasRQx1eYeGL6BwEXCkkZfQv3RjwAAAAASUVORK5CYII=");
            t_actionTex_Copy = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAhUlEQVQ4Ee2SSw6AIAxEwXhv5W69l2ZQYOgn0biVBGmn7QMLWUTSl7E6xYejQcqe7gG8ZEAxDWQhKhI28rWJYuRMgwEIlClqHQPRAFsyFOzeTtDWFPVglF2W/vcOeHMCDa3+D0jhLfQuu50j0WsiriyaO8UqRr+DJzuXWnl/GKAfC+eF9glrmRB9HN2nSgAAAABJRU5ErkJggg==");
            t_actionTex_Paste = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAkklEQVQ4Ea2QUQ6AMAhDnfHezrvtXmqNNKyBuCXyxaB9A0prbUnifOsl6T/lLWiqUd+dZXUvCCOxTeD7tOkEEIfCu249mpEoADX7EflnRABbQ80hOALAqGJbqyrVH1F7+ga0anEGAC8g3YozAFsDIEKyG0DkI7rJ05+ZwAOZ/w7YiR5M/ATY8xj0UZYdkVemMkkuo0sXdbWUxZwAAAAASUVORK5CYII=");
            t_actionTex_Lock = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAh0lEQVQ4EcVS0Q6AIAiU1n/Xx/Ff5s3YACEefIiNQLy7QCVmbjt2JORr1Ltz1BbLBO6BhNPryOGLUTIC/g6ytqjWsg408TP/X+AM+sOsMIlzNb/LOfgRIpIWQG4wXsCDy3UlIO8gFaoEUqJsbAtEtyDiiObA9IbkvgP/fAWno8FEHRiAZkb5A5DgE7kWSo56AAAAAElFTkSuQmCC");
            t_actionTex_Unlock = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAfUlEQVQ4EcVSAQqAMAjM6N/1OP9Vu+FEzMyI6EBy0zu9ETHz9AZzgby2nt0F7joqAlvrRJAEckQHFSxgOsgWelfZwBJP+f8Ci9sJ3iKoZynqm1gLV+QhGNatwGh89M0EdM1MMRPIeFr7VCB8NB0tid3gznNY9/9B2OSn2vMBFUgSuO8kDhAAAAAASUVORK5CYII=");
        }
        void SetUpTextures_Option()
        {
            t_optionTex_Export = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAA3klEQVRIDcVUAQ4CIQwT478P/sa/lCYrKQvIHYeRhGzrtnbuiCHn/PjneS6Ivxd6hi0rA4Bs2xA6AEh5DxmZGC1TiG+flzF4slRwj90W6xHoBpCP5QY4chDrZcrXEb9kuQE2JXP460ciI5w87Gfsbe33G9DCqIH5R7G1uZMnFOl0bJML9j/AiUmOmL5y+DrNeR/DRgciToqNNtAT174zPoSiFMJvxJHzbwDYzqOC6leNXw8Aoa4wJ/CfAN9tdL7lRj1T3D/CaYMVhLOFszpu4ArhldqZfvMItxJPla3gAzqhI48gZrJAAAAAAElFTkSuQmCC");
            t_optionTex_LockWindows = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAApElEQVQ4EaWSgQrDMAhEk7H/XvZv+a/NC33lktIgmyBGPU+vtPbeyz/2SA6/AvcxVz4sS9ACLa9H1HtYTUrQdg1jZ569gMFLzBCgV1txEY06BDTWKGA7XBJwagWC6J1NQK75LUDY2BqRfCJYtytfra2FpxV8o5X3T5ewQ3I6S8iLX3BH0KKBO0a1wo8kvbCrnrasBCecPq5LmBo+sXtD8NP5Iv4CHOYn/qmo8ZUAAAAASUVORK5CYII=");
            t_optionTex_HideSprites = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABH0lEQVQ4EZ2TMU7DQBBFbRQqiESZipqSA9DmHhyBAhoaJgW0UHIA7sAFXOYUVOlJH95bZqLISpHkS8873vWf2Vnb/TAM3Qm6xHMDy8mJ5m98tzA/NoGVNd9BD7MzLvv0wuRmxCv3u2Z9q3GCMgaLYhV5g2ewcsBWlWBsPOeJK/iFNdyDisTd6ek8A4NIFozqHR5a9H+5YPgA16U8Xc9rNFvkAkOTlT2wUhA8wrQmGFuSamFnvoX2XQoC2SsTRGJGZWV3oCIx/vKSqhZiwkT1HcTyAzP4BLftIWp+gjIStmcX1YJJ7E/zdS6ucs55Y3cViS22wpWgvjDNLqqATWIsWyNxk2+hzPV51tpBozvwr/LHqMoHGeshEyxhDh7c0foD2K5Da9EfmwgAAAAASUVORK5CYII=");
            t_optionTex_Ruler = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAXElEQVQ4EWM8cuQIAyWAiRLNIL3DwAAWoDf+UxIOsDBgBBrSADWIJDYjMBpBLgBpAgGS2TAXQLQjDALxYYbiY1MejaBABAGyAxJkALJTwaaRQqCHASl6wWqHgQEAF/IPRGlc/KgAAAAASUVORK5CYII=");
            t_optionTex_Modified = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAABCElEQVQ4EY2TMVLDUBBDMRN6jsIRnBtR0yAKaDkSLnyqNEbPs8psjM1EM+LvavX1N2QyzPP8sIP30j52ZrvS0IL65aXcg8+u74YgnmqCWVX3Y6sfbvjYb1WtpvW6yX/LBPFSv8RHgoFcHG6DiSDWX0yZYBsgaxBP+On6BtnoRqyGB9SYLb+svZmE4llBECtjkglikGv4ZD6bP8WLz/jleg07uQA0ojDUyCPf5qsZjFUwA+JPgqiBGmN8YbDB6J55PEpQhI3//jZB3Ohhqgi0yRzNjqma/EuuG3VTAlVi+rH6ySfaNYT+6OvHqOLiE5yL1Ggqrg/1H631XeTlPpSbNSDiPUHx/nv+Al97QON2NlnVAAAAAElFTkSuQmCC");
            t_optionTex_Settings = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAABMUlEQVRIDcWUC27CQAxEuxXXLjVwtZyr6TyyA44VAUmoOpJZf8YeZxPRhmH4+E98FvHvFOOP3Wo+0fa5eQFEQpbF6vRXOLXnYdz6KziKFbImG2VLoJYRCk45scX3DZzVHGVAFWQxLwd3tzh6XgCfJTJCAXWsitVYlG049DbeLfATIoA5b0FiODWv1AxwHqG56G+AhtzEUyMSMhAylviRAQ/wOWXvv7n3np280MGsKxD6CyAQC4PJ3cSp+xVQAGwOODMR3zXqwc8TuD86j9O5ntJVln/CURUMQHYD4l6gycdehfs8a9aXF4AYsnHGmAIEcx7uZYG3OuVvwOIMWHrCLA4nZF84e+EFuJ6QIcQyLEHOwIfrHOdbbuBghT6cBc4p15KPi3DlFMq6MH8D6zrfxP4FUdJIdZyTcsgAAAAASUVORK5CYII=");
            t_optionTex_helpIcon = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAA4UlEQVQ4EX2SCw6DMAxD6cS9CXfjXl1eiasQulky5GOnKVu7rmtb4PCalTr5WWrbpxQwdqcFm7+hcnpoJvIAGhbElE8jzoPmkN0bIJtl7HdrPhmgnkX1bPENEFOUoJpDP7Yg1oGNK5AAme/sfnIqrJD24AoWzKKVKfeJDXIF1v1nyNepup5/BZ/zwj/zEGuAvsNrQhTqyZSHhwEW9NcLGFdmhAYZcDrBaguuACukPXUFcwVUw8OfQGPBbQ+ZtqABlNf1s3lotIFM5gHszrwNMTUL6oBNf2WvP4DBHpU7n0b1vi/uOlUKB4+sAAAAAElFTkSuQmCC");
            t_optionTex_showSprites = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAA7ElEQVQ4Ea2TOw7CMBBEHRR6jsIRwo2oabIU0HIkUuRUNDAv2rVMRGIkGGmyv/F4IUozjmP6B1o3eVbMmso8YYRJTVjVbFZu4nBt03x8zajc0vKJheSTUbkFBr1IjA2JF/ENc6MwIfaiFWRDeBVPYmiUplQahQl9K7hVvhPvzocihubkwtTyEJZMzprdxCMiR+eRGTAeYUQOrGAI9wxm6FQzD43x0xrxZ8RGczNzZ24cxE4sMXjB/2MwjLw/hbyuN6PuvB4U6WUT6vKtqc5AaM54EQfVENAzJ9rUfPH1x83oA6ZkMojGN0ahXY0vzxA5kHDDbVkAAAAASUVORK5CYII=");
        }
        void SetUpTextures_Search()
        {
            t_searchIcon = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAjElEQVQoFY2P3Q2AMAiEqXGvjiZuVpMOJqccQfriJdjj5yu1zTklqSd/JR92CydymB8pkC8igKZ6tOQXaLdmTwOneYinmh8W8TxusFoMwUOE3sy/Gajra/4gALBOPTiEk7V4jtUE/wBxvZpHQOoBz34ALA4YF29Wzx+IG+oQc94cUAU4mM8P9AcATEhuAYYeOY/JlXYAAAAASUVORK5CYII=");
        }
        void SetUpTextures_TileInfo()
        {
            t_tileInfo_upArrow = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAfklEQVQ4Ed2S4QqAIAyEM3rv1rv5XrUPaRymIfgnOhiObXc7xZRzXmawzpDhfl9gd5dEF1u3U4gm/UPySHtvwFaLqZI3nbQElIzILcT5EKmvUJPVNgIEiLo6eCNDMJgO8wgnSX7iSddhHrGBgkCXJOoqIHPjqV5hnCWTPxC4AJJKGQENuHbMAAAAAElFTkSuQmCC");
            t_tileInfo_downArrow = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAj0lEQVQ4Ed2RWwqEMAxFR3Hfxr11X5rTyZW0PkD8GJhAm/S+aHUopXze1PjGjPfPAlZ/EmvmbRcFJ12V5G9gYaKfhYDBUVZ333LAkggEOaQ3o601aYguwvzMUlkMdGkq1AcASmA+s1TmgzhhzRN2MISWAOaDGf7sBuBUNuT5y8Z+F9CHNEYd8l8Q9qj/PmAD5jYXdVL4jB8AAAAASUVORK5CYII=");
            t_tileInfo_rightArrow = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAfklEQVQ4EaWQQQqAMAwErfhv49/6L82AHtRkU+hCLCTOkLb13peZrDMwbCY4fbaPyDMBrHmVkkwATMxLSjLBccN+aEkmABySKMGQpBIgkakEPKDdBk6u9YoSlDCmTDAEK4Ex9JjXb20GT7INmJuXhPlp4xOkBb2wpTYIgW/zAvzeFO3c2D5VAAAAAElFTkSuQmCC");
            t_tileInfo_leftArrow = Functions.Base64ToTexture("iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAdklEQVQ4EaWPQQrAIAwEaz9e+zf/ZTtQispGF8xFDZkxm0opx06dOzCsK7je2ao+cwTAWcH0VoIWlpKZYIRvtUUksOAogg1HArVp2FMRyJo/gpONwlIChm1JJLAlM4GS0OtqJWC4jdPBPBwBc0gSl7Fcwcj97wcbTxVscLFVRAAAAABJRU5ErkJggg==");
        }

        void GetButtonStyle()
        {
            //create icon button style
#if UNITY_2021_1_OR_NEWER
            _iconButton = new GUIStyle(EditorStyles.iconButton);
#else
            _iconButton = GUI.skin.FindStyle("IconButton") ?? EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector).FindStyle("IconButton");
#endif
        }
#endregion

        public void SetupGrid(bool _new = false)
        {
            switch (_file.settings._gridShape)
            {
                case BetterRuleTileContainer.GridShape.Isometric: _grid = new IsometricEditorGrid(this, _new); return;
                case BetterRuleTileContainer.GridShape.HexagonalPointedTop: _grid = new HexagonalEditorGrid(this, false, _new); return;
                case BetterRuleTileContainer.GridShape.HexagonalFlatTop: _grid = new HexagonalEditorGrid(this, true, _new); return;
                default: _grid = new EditorGridBase(this, _new); return;
            }
        }

#region Variables
        public BetterRuleTileContainer _file = null;
        public EditorGridBase _grid;

        //selection
        public bool _hasSelection = false;
        public Vector2Int _selectionStart;
        public Vector2Int _selectionEnd;
        public Rect _selectionRect
        {
            get
            {
                return new Rect(
                    new Vector2Int(Mathf.Min(_selectionEnd.x, _selectionStart.x), Mathf.Min(_selectionEnd.y, _selectionStart.y)),
                    new Vector2Int(Mathf.Abs(_selectionEnd.x - _selectionStart.x) + 1, Mathf.Abs(_selectionEnd.y - _selectionStart.y) + 1)
                    );
            }
        }

        public Vector2Int _moveFromPos;
        public Vector2Int _moveToPos;
        public bool _movingSelection = false;

        public List<BetterRuleTileContainer.GridCell> _clipboard = new List<BetterRuleTileContainer.GridCell>();
        public Rect _clipboardRect;
        public bool _hasPasteSelection = false;
        public bool _movingPasteSelection = false;

        public BetterRuleTileContainer.GridCell _inspectingCell;
#endregion

#region properties
        public float _zoomAmount { get => _file.settings._zoomAmount; set => _file.settings._zoomAmount = value; }
        public Vector2Int _gridCellSize { get => _file.settings._gridCellSize; set => _file.settings._gridCellSize = value; }
        public Vector2 _tileRenderOffset { get => _file.settings._tileRenderOffset; set => _file.settings._tileRenderOffset = value; }
        public Vector2 _gridOffset { get => _file.settings._gridOffset; set => _file.settings._gridOffset = value; }

        private bool _lockWindows { get => _file.settings._lockWindows; set => _file.settings._lockWindows = value; }
        public bool _hideSprites { get => _file.settings._hideSprites; set => _file.settings._hideSprites = value; }
        public bool _showRuler { get => _file.settings._showRuler; set => _file.settings._showRuler = value; }
        public bool _showModified { get => _file.settings._showModified; set => _file.settings._showModified = value; }
#endregion

        private void SetUpGUI()
        {
            //reset variables
            _selectedDrawerTile = int.MinValue;
            _hideSprites = false;
            _hasSelection = false;
            _hasPasteSelection = false;
            _inspectingCell = null;
        }
        private void CreateGUI()
        {
            //set textures
            SetUpTextures();
            if (_file.settings._saveSpriteDrawer) AddObjectsToSpriteDrawer(_file._imageObjects.ToArray());

            //set styles
            //GetButtonStyle();

            //set up window positions
            SetUpWindows();

            //set window variables
            foreach (var item in _windows) item.ApplyLayout(position);
            _window_Toolbar.lockPosition = true;

            //GenerateButtonStyles();
        }
        private void OnGUI()
        {
            if (_file == null)
            {
                GUIStyle style = new GUIStyle("boldlabel");
                style.alignment = TextAnchor.MiddleCenter;

                GUI.Label(new Rect(position.width / 2 - 150, position.height / 2 - 20, 300, 20), "Double click or open a \"Better Rule Tile Container\"", style);
                GUI.Label(new Rect(position.width / 2 - 150, position.height / 2 - 00, 300, 20), "asset to start editing it in this window.", style);

                this.Close();

                return;
            }

            wantsMouseMove = true;


            //draw grid stuff
            if (_grid == null) SetupGrid(false);
            _grid.DrawAll();

            //drag and drop
            CheckDragAndDrop();

            //tools
            HandleTools();

            //wondows
            DisplayWindows();
        }

#region Drag # Drop
        void CheckDragAndDrop()
        {
            if (IsMouseOverWindow())
            {
                //drag drop into sprite drawer
                if (_window_SpriteDrawer != null && _window_SpriteDrawer.visible && _window_SpriteDrawer.rectangle.Contains(Event.current.mousePosition))
                {
                    //if selecting something
                    if (DragAndDrop.objectReferences.Length > 0) DragDropToDrawer(DragAndDrop.objectReferences);
                }
            }
            else
            {
                //dragdrop
                if (DragAndDrop.objectReferences.Length == 1 && DragAndDrop.objectReferences[0] is Texture2D) DragDropImage(DragAndDrop.objectReferences[0] as Texture2D);
                else if (DragAndDrop.objectReferences.Length > 0 && DragAndDrop.objectReferences.All(t => t is Sprite)) DragDropSprites(DragAndDrop.objectReferences);
                else DragAndDrop.visualMode = DragAndDropVisualMode.Rejected;
            }
        }

        void DragDropSprites(UnityEngine.Object[] sprites)
        {
            //set drag and drop icon
            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;

            //get box size
            int boxSize = 1;
            while (boxSize * boxSize < sprites.Length) boxSize++;

            //draw outline
            _grid.DrawGridTileOutline(_grid.GetMouseTilePos(), new Vector2Int(boxSize, boxSize), t_highlightTexture);

            //add asset
            if (Event.current.type == EventType.DragPerform)
            {
                for (int i = 0; i < sprites.Length; i++)  _file.SetSprite(_grid.GetMouseTilePos() + new Vector2Int(i % boxSize, i / boxSize), sprites[i] as Sprite);
            }

            //update ui
            Repaint();
        }
        void DragDropImage(Texture2D image)
        {
            //set drag and drop icon
            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;

            //load sprites  
            List<Sprite> sprites = new List<Sprite>();
            foreach (var item in AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(image)).Where(t => t is Sprite).ToArray()) sprites.Add(item as Sprite);

            //get texture grid size
            Vector2Int spriteSize = new Vector2Int((int)sprites.Average(t => t.rect.width), (int)sprites.Average(t => t.rect.height));
            Vector2Int gridAmount = new Vector2Int(image.width / spriteSize.x, image.height / spriteSize.y);

            //draw outline
            _grid.DrawGridTileOutline(_grid.GetMouseTilePos(), gridAmount, t_highlightTexture);

            //add asset
            if (Event.current.type == EventType.DragPerform)
            {
                //sort
                sprites = sprites.OrderBy(t => t.rect.x - t.rect.y * 1000).ToList();

                //place
                for (int i = 0; i < sprites.Count; i++)
                {
                    //if all tiles are the same size
                    if (sprites.All(t => (int)t.rect.width == spriteSize.x && (int)t.rect.height == spriteSize.y))
                        _file.SetSprite(_grid.GetMouseTilePos() + new Vector2Int((int)sprites[i].rect.x / spriteSize.x, (int)sprites[i].rect.y / -spriteSize.y + gridAmount.y - 1), sprites[i]);
                    //else just lay them out 
                    else
                        _file.SetSprite(_grid.GetMouseTilePos() + new Vector2Int(i % gridAmount.x, i / gridAmount.x), sprites[i]);
                }
            }

            //update ui
            Repaint();
        }
        void DragDropToDrawer(UnityEngine.Object[] objects)
        {
            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;

            //return if not releasing mouse
            if (Event.current.type != EventType.DragPerform) return;

            //add sprites
            AddObjectsToSpriteDrawer(objects);
            if (_file.settings._saveSpriteDrawer) _file._imageObjects.AddRange(objects.Where(t => !_file._imageObjects.Contains(t)));
        }

        void AddAllTextureAssets()
        {
            var objects = Resources.FindObjectsOfTypeAll<Texture2D>();
            AddObjectsToSpriteDrawer(objects);
            Debug.LogWarning("Added all textures to the sprite drawer.");
        }
        void AddObjectsToSpriteDrawer(UnityEngine.Object[] objects)
        {
            foreach (var ob in objects)
            {
                if (ob == null) continue;

                if (ob is Texture2D) foreach (var item in AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(ob)).Where(t => t is Sprite).ToArray()) _grid.CacheSprite(item as Sprite);
                else if (ob is Sprite) _grid.CacheSprite(ob as Sprite);
            }
        }
#endregion

#region Selection and clipboard functions
        void DeleteSelection()
        {
            _hasPasteSelection = false;
            if (_hasSelection) 
            { 
                _file.DeleteArea(_selectionRect); 
                _hasSelection = false; 
            }
        }
        void CopySelection()
        {
            if (!_hasSelection) return;

            _clipboard.Clear();
            foreach (var item in _file.Grid.Where(t => _selectionRect.Contains(t.Position)).ToArray())
            {
                var cell = new BetterRuleTileContainer.GridCell(item);
                cell.Locked = false;

                _clipboard.Add(cell);
            } 
            _clipboardRect = _selectionRect;
        }
        void MoveClipboard(Vector2Int by)
        {
            for (int i = 0; i < _clipboard.Count; i++) _clipboard[i].Position += by;
            _clipboardRect.position += by;
        }
        void StartPaste()
        {
            _hasPasteSelection = true; 
            _hasSelection = false; 
            _selectedTool = 3;
        }
        void PasteClipboard()
        {
            if (!_hasPasteSelection) return;

            _file.PasteGrid(_clipboard);
            _hasPasteSelection = false;
        }

        void LockSelection()
        {
            _hasPasteSelection = false;
            if (_hasSelection)
            {
                _file.LockArea(_selectionRect);
            }
        }
        void UnlockSelection()
        {
            _hasPasteSelection = false;
            if (_hasSelection)
            {
                _file.UnlockArea(_selectionRect);
            }
        }
#endregion

#region Tools
        void HandleTools()
        {
            //keyboard shortcuts
            switch (Event.current.keyCode)
            {
                case KeyCode.B: _selectedTool = 0; break;
                case KeyCode.I: _selectedTool = 1; break;
                case KeyCode.D: _selectedTool = 2; break;
                case KeyCode.M: _selectedTool = 3; break;
                case KeyCode.S: _selectedTool = 4; break;
                case KeyCode.E: _selectedTool = 5; break;
                case KeyCode.C: if (Event.current.modifiers == EventModifiers.Control && Event.current.type == EventType.KeyDown) CopySelection(); break;
                case KeyCode.V: if (Event.current.modifiers == EventModifiers.Control && Event.current.type == EventType.KeyDown) StartPaste(); break;
                case KeyCode.Delete: DeleteSelection(); break;
                case KeyCode.Escape: _hasSelection = false; _inspectingCell = null; PasteClipboard(); break;
                case KeyCode.L: LockSelection(); break;
                case KeyCode.U: UnlockSelection(); break;
            }

            //handle selection
            if (_selectedTool < 3) _hasSelection = false;
            if (_selectedTool < 4) _inspectingCell = null;
            if (_hasPasteSelection && _selectedTool != 3) PasteClipboard();

            //return if left mouse is not pressed
            if (Event.current.button != 0) return;

            //turn off tools if mouse is in a window
            if (DidMouseClickWindow()) return;

            //higlight cell 
            //DrawGridTileOutline(GetMouseTilePos(), _highlightTexture);
            //Repaint();

            //tools
            switch (_selectedTool)
            {
                case 0: HandleTool_Brush(); break;
                case 1: HandleTool_Picker(); break;
                case 2: HandleTool_Eraser(); break;
                case 3: HandleTool_Move(); break;
                case 4: HandleTool_Select(); break;
                case 5: HandleTool_Inspect(); break;
            }
        }

        void HandleTool_Brush()
        {
            //only continue when dragging mouse 0
            if (Event.current.type != EventType.MouseDrag && Event.current.type != EventType.MouseDown) return;

            //painting sprites
            if (_selectedDrawerTile == 0)
            {
                _file.SetSprite(_grid.GetMouseTilePos(), _selectedSprite);
            }
            //painting tiles
            if (_selectedDrawerTile > 0)
            {
                _file.SetTile(_grid.GetMouseTilePos(), _file.Tiles[_selectedDrawerTile - 1].UniqueID);
            }
            //painting default tiles
            if (_selectedDrawerTile < 0)
            {
                switch (_selectedDrawerTile)
                {
                    case -1: _file.RemoveTile(_grid.GetMouseTilePos()); break;
                    default: if (_selectedDefaultTile > -5) { _file.SetTile(_grid.GetMouseTilePos(), _selectedDrawerTile); } break;
                }
            }

            Repaint();
        }
        void HandleTool_Picker()
        {
            //only continue code when releasing button 0
            if (Event.current.type != EventType.MouseUp) return;

            //find the tile we selected
            var tile = _file.Grid.Find(t => t.Position == _grid.GetMouseTilePos());
            if (tile == null) return;

            //get sprite
            if (tile.Sprite != null)
            {
                _selectedDrawerTile = 0;
                _selectedSprite = tile.Sprite;
                _selectedTool = 0;
                Repaint();
                return;
            }

            //if no sprite get tile
            if (_file.DoesTileExist(tile.TileID))
            {
                if (tile.TileID < 0) _selectedDrawerTile = tile.TileID;
                //if the order does not match up with the tile id this makes sure to get the correct index
                else _selectedDrawerTile = _file.Tiles.IndexOf(_file.Tiles.Find(t => t.UniqueID == tile.TileID)) + 1;

                _selectedTool = 0;
                Repaint();
                return;
            }
        }
        void HandleTool_Eraser()
        {
            //only continue when dragging mouse 0
            if (Event.current.type != EventType.MouseDrag && Event.current.type != EventType.MouseDown) return;

            //draw outline
            _grid.DrawGridTileOutline(_grid.GetMouseTilePos(), t_highlightTexture);
            Repaint();

            //find the tile we selected
            var tile = _file.Grid.Find(t => t.Position == _grid.GetMouseTilePos());
            if (tile == null) return;

            //remove
            _file.RemoveSprite(tile.Position);
            Repaint();
        }
        void HandleTool_Move()
        {
            //move selection
            if (_hasSelection)
            {
                if (Event.current.type == EventType.MouseDown)
                {
                    //set drag start postition
                    _moveFromPos = _grid.GetMouseTilePos();
                    _moveToPos = _moveFromPos;
                    _movingSelection = true;
                }

                if (Event.current.type == EventType.MouseDrag)
                {
                    _moveToPos = _grid.GetMouseTilePos();
                    _movingSelection = true;
                }

                if (Event.current.type == EventType.MouseUp)
                {
                    Vector2Int movedBy = _moveToPos - _moveFromPos;

                    _file.MoveArea(_selectionRect, movedBy);

                    _selectionStart += movedBy;
                    _selectionEnd += movedBy;
                    _movingSelection = false;
                }
            }

            //move clipboard
            if (_hasPasteSelection)
            {
                if (Event.current.type == EventType.MouseDown)
                {
                    //set drag start postition
                    _moveFromPos = _grid.GetMouseTilePos();
                    _moveToPos = _moveFromPos;
                    _movingPasteSelection = true;
                }

                if (Event.current.type == EventType.MouseDrag)
                {
                    _moveToPos = _grid.GetMouseTilePos();
                    _movingPasteSelection = true;
                }

                if (Event.current.type == EventType.MouseUp)
                {
                    Vector2Int movedBy = _moveToPos - _moveFromPos;

                    MoveClipboard(movedBy);
                    _movingPasteSelection = false;
                }
            }
        }
        void HandleTool_Select()
        {
            if (Event.current.type == EventType.MouseDown)
            {
                _hasPasteSelection = false;
                _hasSelection = true;
                _selectionStart = _grid.GetMouseTilePos();
                _selectionEnd = _selectionStart;
            }
            if (Event.current.type == EventType.MouseDrag) _selectionEnd = _grid.GetMouseTilePos();
        }
        void HandleTool_Inspect()
        {
            if (Event.current.type == EventType.MouseDown)
            {
                _inspectingCell = _file.Grid.Find(t => t.Position == _grid.GetMouseTilePos());
            }
        }
#endregion

#region Window methods
#region Variables

        public GUIWindow[] _windows = new GUIWindow[8];
        private GUIWindow _window_Toolbar
        {
            get => _windows[0];
            set => _windows[0] = value;
        }
        private GUIWindow _window_TileDrawer
        {
            get => _windows[1];
            set => _windows[1] = value;
        }
        private GUIWindow _window_TileInfo
        {
            get => _windows[2];
            set => _windows[2] = value;
        }
        private GUIWindow _window_SettingsWindow
        {
            get => _windows[3];
            set => _windows[3] = value;
        }
        private GUIWindow _window_ExportWindow
        {
            get => _windows[4];
            set => _windows[4] = value;
        }
        private GUIWindow _window_RecolorWindow
        {
            get => _windows[5];
            set => _windows[5] = value;
        }
        private GUIWindow _window_GridCellInfo
        {
            get => _windows[6];
            set => _windows[6] = value;
        }
        private GUIWindow _window_SpriteDrawer
        {
            get => _windows[7];
            set => _windows[7] = value;
        }

        private bool _clickedOnWindow = false;

#endregion
#region Base window functions
        public bool _initializedWindows { get; private set; } = false;

        private void SetUpWindows()
        {
            _window_Toolbar = new GUIWindow(GUIWindow.WindowLayout.SpanTop, new RectOffset(0, 0, 0, 0), new Vector2(position.width, 26), ToolbarWindow, new GUIContent(""), true, false, false, GUIStyle.none);
            _window_TileDrawer = new GUIWindow(GUIWindow.WindowLayout.BottomLeftCorner, new RectOffset(4, 4, 30, 4), Vector2.zero, TileDrawerWindow, new GUIContent(""));
            _window_TileInfo = new GUIWindow(GUIWindow.WindowLayout.BottomRightCorner, new RectOffset(4, 4, 30, 4), new Vector2(300, 400), TileInfoWindow, new GUIContent(""), false);
            _window_SettingsWindow = new GUIWindow(new Rect(0, 0, 300, 50), SettingsWindow, new GUIContent(""), false, true, true);
            _window_ExportWindow = new GUIWindow(new Rect(0, 0, 250, 50), ExportWindow, new GUIContent(""), false, true, true);
            _window_RecolorWindow = new GUIWindow(new Rect(0, 0, 250, 50), RecolorWindow, new GUIContent(""), false, true, true);
            _window_GridCellInfo = new GUIWindow(GUIWindow.WindowLayout.BottomRightCorner, new RectOffset(4, 4, 30, 4), new Vector2(300, 400), GridCellInfoWindow, new GUIContent(""), false);
            _window_SpriteDrawer = new GUIWindow(GUIWindow.WindowLayout.SpanLeft, new RectOffset(4, 4, 30, 125), new Vector2(180, 400), SpriteDrawerWindow, new GUIContent(""));

            _initializedWindows = true;
        }
        private void DisplayWindows()
        {
            //check if the windows are set up or if they aren't missing
            if (!_initializedWindows || _windows.Any(t => t == null)) SetUpWindows();


            if (_window_TileInfo != null) _window_TileInfo.visible = _selectedDrawerTile > 0 && _inspectingCell == null;
            if (_window_GridCellInfo != null) _window_GridCellInfo.visible = _inspectingCell != null;
            _window_SpriteDrawer.visible = _file.settings._displaySpriteDrawer;


            BeginWindows();
            for (int i = 0; i < _windows.Length; i++) if (_windows[i] != null) _windows[i].Show(i, position);
            EndWindows();
        }

        private bool DidMouseClickWindow()
        {
            if (Event.current.type == EventType.MouseDown) _clickedOnWindow = IsMouseOverWindow();
            if (Event.current.type == EventType.MouseDrag) return _clickedOnWindow;

            return IsMouseOverWindow();
        }
        public bool IsMouseOverWindow()
        {
            if (!_initializedWindows) return false;

            for (int i = 0; i < _windows.Length; i++)
            {
                if (_windows[i] != null && _windows[i].rectangle.Contains(Event.current.mousePosition) && _windows[i].visible) return true;
            }
            return false;
        }
#endregion

#region Window toolbar
        private int _selectedTool = 0;
        private GUIContent[] _toolbarTextures => new GUIContent[] {
            new GUIContent(t_toolTex_Brush, "Paint selected tile or sprite to the grid (B)"),
            new GUIContent(t_toolTex_Pick, "Pick tiles or sprites from the grid (I)"),
            new GUIContent(t_toolTex_Erase, "Delete sprites (D)"),
            new GUIContent(t_toolTex_Move, "Move selected sprites on the grid (M)"),
            new GUIContent(t_toolTex_Select, "Select one or multiple sprites on the grid (S)"),
            new GUIContent(t_toolTex_Inspect, "Inspect a tile on the grid and modify it (E)")
        };

        //create style
        GUIStyle _toolbarButtonStyle;

        void GenerateButtonStyles()
        {
            //set up button style
            _toolbarButtonStyle = new GUIStyle(EditorStyles.miniButtonMid);
            _toolbarButtonStyle.normal.background = t_defaultButtonTexture;
            _toolbarButtonStyle.hover.background = t_hoverButtonTexture;
            _toolbarButtonStyle.active.background = t_activeButtonTexture;
            _toolbarButtonStyle.onNormal.background = t_activeButtonTexture;
            _toolbarButtonStyle.margin = new RectOffset(1, 1, 0, 0);
            _toolbarButtonStyle.alignment = TextAnchor.MiddleCenter;
            _toolbarButtonStyle.imagePosition = ImagePosition.ImageOnly;
            _toolbarButtonStyle.padding = new RectOffset(2, 2, 2, 0);
        }

        void ToolbarWindow(int WindowID)
        {
            if (t_defaultButtonTexture == null || t_toolbarBackgroundTexture == null) SetUpTextures_Solid();

            GUI.DrawTexture(_window_Toolbar.rectangle, t_toolbarBackgroundTexture);

            //create toolbar
            if (_toolbarButtonStyle == null) GenerateButtonStyles();
            var toolbar = new GUIToolbar(position, _toolbarButtonStyle);

            //left side (from left to right)
            toolbar.DrawDividerLeft(t_defaultButtonTexture);
            _selectedTool = toolbar.DrawToolbarLeft(_selectedTool, _toolbarTextures, 198);
            toolbar.DrawDividerLeft(t_defaultButtonTexture);

            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Undo, "Undo (Ctrl + Z)"))) Undo.PerformUndo();
            toolbar.DrawSpaceLeft();
            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Redo, "Redo (Ctrl + Y)"))) Undo.PerformRedo();
            toolbar.DrawSpaceLeft();
            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_DeleteSelection, "Delete selected area (Delete)"))) DeleteSelection();
            toolbar.DrawSpaceLeft();
            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Copy, "Copy (Ctrl + C)"))) CopySelection();
            toolbar.DrawSpaceLeft();
            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Paste, "Paste (Ctrl + V)"))) StartPaste();

            toolbar.DrawDividerLeft(t_defaultButtonTexture);

            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Lock, "Lock selection to prevent it from being edited (L)"))) LockSelection();
            toolbar.DrawSpaceLeft();
            if (toolbar.DrawButtonLeft(new GUIContent(t_actionTex_Unlock, "Unlock selection and allow editing it (U)"))) UnlockSelection();

            toolbar.DrawDividerLeft(t_defaultButtonTexture);

            _window_RecolorWindow.visible = toolbar.DrawDropdownLeft(_window_RecolorWindow.visible, new GUIContent(t_toolTex_Recolor, "Replace selection"));
            _window_RecolorWindow.position = new Vector2(toolbar.currentMargin.Left - _window_RecolorWindow.width, 23);
            

            //right side (front right to left)
            toolbar.DrawDividerRight(t_defaultButtonTexture);

            _window_ExportWindow.visible = toolbar.DrawDropdownRight(_window_ExportWindow.visible, new GUIContent(t_optionTex_Export, "Export options"));
            _window_ExportWindow.position = new Vector2(position.width - toolbar.currentMargin.Right - _window_ExportWindow.width + 38, 23);

            toolbar.DrawDividerRight(t_defaultButtonTexture);

            _window_SettingsWindow.visible = toolbar.DrawDropdownRight(_window_SettingsWindow.visible, new GUIContent(t_optionTex_Settings, "Other Settings"));
            _window_SettingsWindow.position = new Vector2(position.width - toolbar.currentMargin.Right - _window_SettingsWindow.width + 38, 23);
            toolbar.DrawSpaceRight(); 
            _hideSprites = toolbar.DrawToggleRight(_hideSprites, new GUIContent(t_optionTex_HideSprites, "Hide sprites to see tiles below them"));
            toolbar.DrawSpaceRight();
            _lockWindows = toolbar.DrawToggleRight(_lockWindows, new GUIContent(t_optionTex_LockWindows, "Snap windows to the corners and lock them"));
            toolbar.DrawSpaceRight();
            _showRuler = toolbar.DrawToggleRight(_showRuler, new GUIContent(t_optionTex_Ruler, "Show the grid coordinates on the edge of the screen"));
            toolbar.DrawSpaceRight();
            _showModified = toolbar.DrawToggleRight(_showModified, new GUIContent(t_optionTex_Modified, "Highlights the cells which have been modified with a flashing outline"));
            toolbar.DrawSpaceRight();
            _file.settings._displaySpriteDrawer = toolbar.DrawToggleRight(_file.settings._displaySpriteDrawer, new GUIContent(t_optionTex_showSprites, "Show the sprite drawer"));

            toolbar.DrawDividerRight(t_defaultButtonTexture);

            if (toolbar.DrawButtonRight(new GUIContent(t_optionTex_helpIcon, "Open documentation (opens browser)"))) Application.OpenURL("https://docs.vinark.dev/#/./better-rule-tiles/index");
        }
        #endregion

        #region Tile Drawer
        GUIStyle _iconButton;

        private Vector2 _tileDrawerScroll;
        private int _drawerSize { get => _file.settings._drawerSize; set => _file.settings._drawerSize = value; }
        private GUIContent[] _defaultTiles => new GUIContent[] {
            new GUIContent(t_tileTex_Ignore, "This tile will be ignored in the rule tile, this is the default option, use this to clear tiles on the grid"),
            new GUIContent(t_tileTex_Empty, "No tile should be placed in this place for the rule to be right"),
            new GUIContent(t_tileTex_NotSame, "A tile of the same type shouldn't be placed here for the rule to be right"),
            new GUIContent(t_tileTex_Any, "Any tile could be placed here for the rule to be right")
        };
        private string[] _defaultTileNames = { "Delete", "Empty", "Not Same", "Any tile" };
        private int _selectedDefaultTile
        {
            get
            {
                switch (_selectedDrawerTile)
                {
                    case -1: return 0;
                    case -2: return 1;
                    case -3: return 2;
                    case -4: return 3;
                    default: return -1;
                }
            }
            set
            {
                switch (value)
                {
                    case 0: _selectedDrawerTile = -1; break;
                    case 1: _selectedDrawerTile = -2; break;
                    case 2: _selectedDrawerTile = -3; break;
                    case 3: _selectedDrawerTile = -4; break;
                }
            }
        }

        Sprite _selectedSprite = null;
        Texture2D GetSelectedTileTex()
        {
            switch (_selectedDrawerTile)
            {
                case -1: return t_tileTex_Delete;
                case -2: return t_gridTex_Empty;
                case -3: return t_gridTex_NotSame;
                case -4: return t_gridTex_Any;
            }

            if (_selectedDrawerTile == 0)
            {
                //return _grid._spriteTextureCache[_selectedSprite];

                if (_selectedSprite != null && _selectedSprite.texture.isReadable)
                {
                
                    Rect rect = _selectedSprite.textureRect;
                    var colors = _selectedSprite.texture.GetPixels((int)rect.x, (int)rect.y, (int)rect.width, (int)rect.height);
                
                    Texture2D tex = new Texture2D((int)rect.width, (int)rect.height);
                    tex.SetPixels(colors);
                    tex.filterMode = FilterMode.Point;
                    tex.Apply();
                
                    return tex;
                }
                else return Functions.CreateMissingTexture();
            }

            if (_selectedDrawerTile > 0)
            {
                return _file.GetTileTexture(_selectedDrawerTile - 1);
            }

            return t_emptyTexture;
        }
        bool _drawerCollapsed = false;

        void TileDrawerWindow(int windowID)
        {
            if (_iconButton == null) GetButtonStyle();

            //get values
            string[] drawerTileNames = _file.GetTileNames();

            //calculate values
            int scrollStart = 81;
            int numTiles = _file.Tiles.Count;
            int drawerTileWidth = numTiles == 1 ? 73 : (numTiles >= 6 ? 70 : 71);
            int numDefaultTiles = _defaultTiles.Length;
            int scrollRectWidth = numTiles * drawerTileWidth - 5 + numDefaultTiles * 70 + 12 + 85;

            //make styles
            GUIStyle selectedTileText = new GUIStyle("boldlabel");
            selectedTileText.alignment = TextAnchor.MiddleCenter;
            GUIStyle tileNameText = new GUIStyle("label");
            tileNameText.alignment = TextAnchor.LowerCenter;

            //set window properties
            _windows[windowID].width = _drawerCollapsed ? 80 : _drawerSize * 70 + 80 + 19;
            _windows[windowID].height = 115;
            _windows[windowID].lockPosition = _lockWindows;

            //show window title
            GUI.Label(new Rect(5, 0, 100, 25), "Selected", "boldlabel");
            GUI.Label(new Rect(scrollStart + 5, 0, 100, 25), "Tile Drawer", "boldlabel");

            //Before scroll rect
            GUI.Label(new Rect(5, 25, 70, 70), "", "button");
            GUI.DrawTexture(new Rect(5 + 7, 25 + 7, 56, 56), GetSelectedTileTex());
            //GUI.Label(new Rect(5, 95, 70, 20), "this tile", selectedTileText);

            //collapse
            if (GUI.Button(new Rect(_windows[windowID].width - 17, 4, 16, 16), _drawerCollapsed ? t_tileInfo_rightArrow : t_tileInfo_leftArrow, _iconButton))
            {
                _drawerCollapsed = !_drawerCollapsed;
            }
            if (_drawerCollapsed) return;

            //draw divider
            GUI.DrawTexture(new Rect(scrollStart - 1, 0, 1, _windows[windowID].height), t_backgroundTexture);

            //start scroll
            _tileDrawerScroll = GUI.BeginScrollView(new Rect(scrollStart, 25, _windows[windowID].width - scrollStart, 88), _tileDrawerScroll, new Rect(0, 0, scrollRectWidth, 70), true, false);

            //draw default tool buttons
            _selectedDefaultTile = GUI.SelectionGrid(new Rect(5, 0, numDefaultTiles * 70, 70), _selectedDefaultTile, _defaultTiles, numDefaultTiles);
            for (int i = 0; i < _defaultTileNames.Length; i++)
            {
                Rect labelPos = new Rect(5 + i * 71, 0, 70, 65);
                GUI.Label(labelPos, _defaultTileNames[i], tileNameText);
            }
            //divider line
            GUI.DrawTexture(new Rect(numDefaultTiles * 70 + 11, 0, 1, 70), t_backgroundTexture);
            //tiles buttons
            _selectedDrawerTile = GUI.SelectionGrid(new Rect(numDefaultTiles * 70 + 17, 0, numTiles * 70, 70), _selectedDrawerTile - 1, new string[_file.GetTileTextures().Length], numTiles) + 1;
            for (int i = 0; i < drawerTileNames.Length; i++)
            {
                Rect labelPos = new Rect(numDefaultTiles * 70 + 16 + i * drawerTileWidth, 0, 70, 65);
                GUI.Label(labelPos, drawerTileNames[i], tileNameText);

                Rect imagePos = new Rect(numDefaultTiles * 70 + 16 + i * drawerTileWidth + 19, 10, 34, 34);
                GUI.DrawTexture(imagePos, _file.GetTileTexture(i));
            }
            //add new tile button
            if (GUI.Button(new Rect(scrollRectWidth - 75, 0, 70, 70), new GUIContent("Add Tile", "Create a new tile")))
            {
                _file.CreateTile();
                Repaint();
            }

            //end scroll
            GUI.EndScrollView();
            GUI.DragWindow();
        }
        #endregion

        #region Sprite Drawer
        Vector2 _spriteDrawerScroll;
        private int _drawerHeight { get => _file.settings._drawerHeight; set => _file.settings._drawerHeight = value; }
        private int _drawerCollumns { get => _file.settings._drawerCollumns; set => _file.settings._drawerCollumns = value; }
        private int _expandedDrawerCollumns { get => _file.settings._expandedDrawerCollumns; set => _file.settings._expandedDrawerCollumns = value; }
        bool _spriteDrawerCollapsed = true;
        private string _spriteFilter = "";

        void SpriteDrawerWindow(int windowID)
        {
            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title bar
            GUI.Label(new Rect(0, 0, _windows[windowID].width - 12, 25), "Sprites", titleStyle);
            EditorGUILayout.Space();

            //collapse
            if (GUI.Button(new Rect(_windows[windowID].width - 18, 4, 16, 16), _spriteDrawerCollapsed ? t_tileInfo_rightArrow : t_tileInfo_leftArrow, _iconButton))
            {
                _spriteDrawerCollapsed = !_spriteDrawerCollapsed;
            }

            //Search bar
            var searchRect = EditorGUILayout.GetControlRect();
            _spriteFilter = GUI.TextField(searchRect, _spriteFilter);
            GUI.DrawTexture(new Rect(searchRect.x + searchRect.width - 15, searchRect.y + 3, 12, 12), t_searchIcon);

            //get start pos of scrollrect
            var pos = EditorGUILayout.GetControlRect(GUILayout.MaxWidth(10));

            //variables
            int size = _drawerHeight;
            int spritesCount = _grid._sortedSpriteCache.Length;
            int collumns = _spriteDrawerCollapsed ? _drawerCollumns : _expandedDrawerCollumns;
            Vector2 scrollSize = new Vector2((spritesCount % collumns) * (size + 5) - 5, Mathf.CeilToInt((float)spritesCount / collumns) * (size + 5));

            //grid
            _spriteDrawerScroll = GUI.BeginScrollView(new Rect(pos.position, _windows[windowID].size - new Vector2(pos.x, pos.y + 2)), _spriteDrawerScroll, new Rect(pos.position, scrollSize));

            int s = 0;
            for (int i = 0; i < spritesCount; i++)
            {
                if (_spriteFilter == "" || _grid._sortedSpriteCache[i].Key.name.ToLower().Contains(_spriteFilter.ToLower()))
                {
                    int row = s / collumns;
                    int collumn = s % collumns;

                    Rect rect = new Rect(pos.position + new Vector2(collumn * (size + 5), row * (size + 5)), Vector2.one * size);
                    DrawNextSpriteCell(rect, i);

                    s++;
                }
            }

            GUI.EndScrollView();

            //window properties
            int scrollBarWidth = scrollSize.y < _windows[windowID].height - pos.y ? 3 : 16;
            _windows[windowID].lockPosition = _lockWindows;
            _windows[windowID].width = collumns * (size + 5) + scrollBarWidth;
        }

        void DrawNextSpriteCell(Rect rect, int spriteCellIndex)
        {
            if (_grid._sortedSpriteCache[spriteCellIndex].Value == null) _grid.CacheSprite(_grid._sortedSpriteCache[spriteCellIndex].Key);
            var tex = _grid._sortedSpriteCache[spriteCellIndex].Value;

            Vector2 aspect = tex.width > tex.height ? new Vector2(1, (float)tex.height / tex.width) : (tex.width < tex.height ? new Vector2((float)tex.width / tex.height, 1) : Vector2.one);

            if (GUI.Button(rect, new GUIContent("", _grid._sortedSpriteCache[spriteCellIndex].Key.name)))
            {
                _selectedDrawerTile = 0;
                _selectedTool = 0;
                _spriteDrawerCollapsed = true;
                _selectedSprite = _grid._sortedSpriteCache[spriteCellIndex].Key;
            }
            GUI.DrawTexture(new Rect(
                rect.position + rect.size * .1f + rect.size * (Vector2.one - aspect) * .4f,
                rect.size * .8f * aspect
                ), tex);

            //spriteCellIndex++;
            //return spriteCellIndex >= _grid._spriteDrawerContents.Count;
        }
        #endregion

        #region Tile info
        private int p_selectedDrawerTile = int.MinValue;
        private int _selectedDrawerTile
        {
            get => p_selectedDrawerTile;
            set
            {
                if (p_selectedDrawerTile == value) return;
                if (p_selectedDrawerTile > 0) UpdateSelectedTile();

                if (value > 0)
                {
                    _inspectingCell = null;

                    _tileInfo_Name = _file.Tiles[value - 1].Name;
                    _tileInfo_Color = _file.Tiles[value - 1].Color;
                    _tileInfo_Texture = _file.Tiles[value - 1].Texture;
                    _tileInfo_Sprite = _file.Tiles[value - 1].DefaultSprite;
                    _tileInfo_ColliderType = _file.Tiles[value - 1].ColliderType;
                    _tileInfo_GameObject = _file.Tiles[value - 1].DefaultGameObject;
                    _tileInfo_Shape = _file.Tiles[value - 1].TextureShape;
                    _tileInfo_MirrorTexX = _file.Tiles[value - 1].MirrorTexX;
                    _tileInfo_MirrorTexY = _file.Tiles[value - 1].MirrorTexY;
                    _tileInfo_Unique = _file.Tiles[value - 1].uniqueTile;
                    _tileInfo_VariationOf = _file.Tiles[value - 1].variationOf;
                    _tileInfo_Variations = _file.Tiles[value - 1].variations;
                    _tileInfo_CustomProperties = _file.Tiles[value - 1].customProperties;
                }

                if (value != 0 && _selectedTool > 1) _selectedTool = 0;

                p_selectedDrawerTile = value;
            }
        }

        string _tileInfo_Name;
        Color _tileInfo_Color;
        Texture2D _tileInfo_Texture;
        Sprite _tileInfo_Sprite;
        Tile.ColliderType _tileInfo_ColliderType;
        GameObject _tileInfo_GameObject;
        BetterRuleTileContainer.TileShape _tileInfo_Shape;
        bool _tileInfo_MirrorTexX;
        bool _tileInfo_MirrorTexY;
        bool _tileInfo_Unique;
        int _tileInfo_VariationOf;
        List<int> _tileInfo_Variations;
        List<CustomTileProperty> _tileInfo_CustomProperties;

        Vector2 _tile_scrollPos;
        int _tile_selectedVariationTile;
        bool _inspector_collapsed = false;
        void TileInfoWindow(int windowID)
        {
            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title
            GUI.Label(new Rect(0, 0, _windows[windowID].width, 25), $"Tile info: \"{_file.GetTileName(_selectedDrawerTile - 1)}\"", titleStyle);

            //collapse
            if (GUI.Button(new Rect(_windows[windowID].width - 20, 3, 16, 16), _inspector_collapsed ? t_tileInfo_upArrow : t_tileInfo_downArrow, _iconButton))
            {
                _inspector_collapsed = !_inspector_collapsed;
                _windows[windowID].height = _inspector_collapsed ? 25 : 400;
                _windows[windowID].width = 300;
            }
            if (_inspector_collapsed) return;

            //set up scrollbar
            _tile_scrollPos = EditorGUILayout.BeginScrollView(_tile_scrollPos);

            //editor options
            EditorGUILayout.Space();
            GUILayout.Label("Editor options", "boldlabel");
            _tileInfo_Name = EditorGUILayout.TextField("Tile name", _tileInfo_Name);
            _tileInfo_Texture = EditorGUILayout.ObjectField("Tile image", _tileInfo_Texture, typeof(Texture2D), false, GUILayout.Height(EditorGUIUtility.singleLineHeight)) as Texture2D;

            //if (_tileInfo_Texture != null && !_tileInfo_Texture.isReadable) EditorGUILayout.HelpBox("This texture is not readable, therefore some functionality may not be available for this image", MessageType.Warning);
            if (_tileInfo_Texture == null)
            {
                EditorGUILayout.Space();
                GUILayout.Label("Auto texture");
                _tileInfo_Color = EditorGUILayout.ColorField("Tile color", _tileInfo_Color);
                _tileInfo_Shape = (BetterRuleTileContainer.TileShape)EditorGUILayout.EnumPopup("Tile shape", _tileInfo_Shape);
                _tileInfo_MirrorTexX = EditorGUILayout.Toggle("Mirror X", _tileInfo_MirrorTexX);
                _tileInfo_MirrorTexY = EditorGUILayout.Toggle("Mirror Y", _tileInfo_MirrorTexY);
            }

            //rule tile options
            EditorGUILayout.Space();
            GUILayout.Label("Rule tile options", "boldlabel");
            _tileInfo_Sprite = EditorGUILayout.ObjectField("Default sprite", _tileInfo_Sprite, typeof(Sprite), false, GUILayout.Height(EditorGUIUtility.singleLineHeight)) as Sprite;
            _tileInfo_ColliderType = (Tile.ColliderType)EditorGUILayout.EnumPopup("Default collider", _tileInfo_ColliderType);
            _tileInfo_GameObject = EditorGUILayout.ObjectField("Default gameobject", _tileInfo_GameObject, typeof(GameObject), false, GUILayout.Height(EditorGUIUtility.singleLineHeight)) as GameObject;

            EditorGUILayout.Space();
            _tileInfo_Unique = EditorGUILayout.Toggle(new GUIContent("Unique tile", "Is this tile unique, or a variation of another tile?"), _tileInfo_Unique);
            if (!_tileInfo_Unique)
            {
                int varIndex = _file.Tiles.FindIndex(t => t.UniqueID == _tileInfo_VariationOf);
                varIndex = EditorGUILayout.Popup(new GUIContent("Variation of", 
                    //"If a tile is a variation of another, that other tile will treat this if it was the same. But this tile can have separate rules for interacting with itself, and separate rules when interacting with it's parent. This is a good option if you want to make sloped variations of existing tiles."
                    "If a tile is a variation of another tile, it will autofill all missing rules from the parent."
                    ), varIndex, _file.GetTileNames());
                if (varIndex >= 0) _tileInfo_VariationOf = _file.Tiles[varIndex].UniqueID;
            }

            EditorGUILayout.Space();

            //variation selection
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent("Add variations", "The tile will connect these tiles as it was the same tile"), "boldlabel");

            int varIndex2 = _file.Tiles.FindIndex(t => t.UniqueID == _tile_selectedVariationTile);
            varIndex2 = EditorGUILayout.Popup(varIndex2, _file.GetTileNamesSorted(), GUILayout.Width(80));

            if (varIndex2 >= 0) _tile_selectedVariationTile = _file.Tiles[varIndex2].UniqueID;
            if (GUILayout.Button("Add", GUILayout.Width(50)) && !_tileInfo_Variations.Contains(varIndex2 + 1)) _tileInfo_Variations.Add(varIndex2 + 1);

            EditorGUILayout.EndHorizontal();

            foreach (var item in _tileInfo_Variations)
            {
                EditorGUILayout.BeginHorizontal();
                var tile = _file.Tiles.Find(t => t.UniqueID == item);
                EditorGUILayout.LabelField(" ", tile != null ? tile.Name : "Deleted");
                if (GUILayout.Button("✕", GUILayout.Width(20))) _tileInfo_Variations.Remove(item);
                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.Space();

            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent("Custom properties", "Custom properties can be accessed by scripts to load custom data from the tiles"), "boldlabel");
            if (GUILayout.Button("Add", GUILayout.Width(50))) _tileInfo_CustomProperties.Add(new CustomTileProperty());
            EditorGUILayout.EndHorizontal();
            //custom properties

            for (int i = 0; i < _tileInfo_CustomProperties.Count; i++)
            {
                var item = _tileInfo_CustomProperties[i];

                EditorGUILayout.BeginHorizontal();
                item._key = EditorGUILayout.TextField(new GUIContent("", "Enter the key which you'll use to access this variable in script"), item._key, GUILayout.Width(80));
                item._type = (CustomTileProperty.Type)EditorGUILayout.EnumPopup(item._type, GUILayout.Width(80));

                switch (item._type)
                {
                    case CustomTileProperty.Type.Int:
                        item._val_int = EditorGUILayout.IntField(item._val_int);
                        break;
                    case CustomTileProperty.Type.Float:
                        item._val_float = EditorGUILayout.FloatField(item._val_float);
                        break;
                    case CustomTileProperty.Type.Double:
                        item._val_double = EditorGUILayout.DoubleField(item._val_double);
                        break;
                    case CustomTileProperty.Type.Char:
                        item._val_char = EditorGUILayout.TextField($"{item._val_char}")[0];
                        break;
                    case CustomTileProperty.Type.String:
                        item._val_string = EditorGUILayout.TextField(item._val_string);
                        break;
                    case CustomTileProperty.Type.Bool:
                        item._val_bool = EditorGUILayout.Toggle(item._val_bool);
                        break;
                    default:
                        break;
                }

                if (GUILayout.Button("✕", GUILayout.Width(20))) _tileInfo_CustomProperties.Remove(item);
                EditorGUILayout.EndHorizontal();
            }


            GUILayout.Space(20);
            EditorGUILayout.EndScrollView();
            GUILayout.Space(30);

            //buttons
            if (GUI.Button(new Rect(5, _windows[windowID].height - 25, _windows[windowID].width - 35, 19), "Apply Changes")) UpdateSelectedTile();
            if (GUI.Button(new Rect(_windows[windowID].width - 25, _windows[windowID].height - 25, 20, 19), new GUIContent("✕", "Delete Tile")))
            {
                int index = _selectedDrawerTile - 1;
                _selectedDrawerTile = int.MinValue;
                _file.DeleteTile(_file.Tiles[index]);
            }

            //lock position
            _windows[windowID].lockPosition = _lockWindows;

            //move window
            if (!_lockWindows) GUI.DragWindow();
        }


        public void DrawGUIBackground(Rect rect, GUIContent title)
        {
            //draw background
            GUI.DrawTexture(rect, t_windowBorderTexture, ScaleMode.StretchToFill, true, 0, Color.white, 0, 5);
            GUI.DrawTexture(rect, t_backgroundTexture, ScaleMode.StretchToFill, true, 0, Color.white, 1, 5);
            GUI.DrawTexture(new Rect(rect.position, new Vector2(rect.width, 20)), t_fieldBoxTexture, ScaleMode.StretchToFill, true, 0, Color.white, 0, 5);
            GUI.DrawTexture(new Rect(rect.position, new Vector2(rect.width, 20)), t_backgroundTexture, ScaleMode.StretchToFill, true, 0, Color.white, 1, 5);
            GUI.Label(new Rect(rect.position + new Vector2(5, 0), new Vector2(rect.width, 20)), title);
        }

        void UpdateSelectedTile()
        {
            _file.ModifyTile(
                _selectedDrawerTile - 1,
                _tileInfo_Name,
                _tileInfo_Color,
                _tileInfo_Texture,
                _tileInfo_Sprite,
                _tileInfo_ColliderType,
                _tileInfo_GameObject,
                _tileInfo_Shape,
                _tileInfo_MirrorTexX,
                _tileInfo_MirrorTexY,
                _tileInfo_Unique,
                _tileInfo_VariationOf,
                _tileInfo_Variations,
                _tileInfo_CustomProperties
                );
        }
#endregion

#region Grid cell info
        //public Sprite[] _gridCellSprites = new Sprite[0];
        public Vector2 _gridCellViewScroll;
        bool _gridCellCollapsed = false;
        bool _showSpritesArray = false;
        void GridCellInfoWindow(int windowID)
        {
            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title
            GUI.Label(new Rect(0, 0, _windows[windowID].width, 25), $"Cell info: {_inspectingCell.Position} - {(_inspectingCell.TileID < 1 ? GetRuleName(_inspectingCell.TileID) : _file.Tiles.Find(t => t.UniqueID == _inspectingCell.TileID).Name)}", titleStyle);

            //collapse
            if (GUI.Button(new Rect(_windows[windowID].width - 20, 3, 16, 16), _gridCellCollapsed ? t_tileInfo_upArrow : t_tileInfo_downArrow, _iconButton))
            {
                _gridCellCollapsed = !_gridCellCollapsed;
                _windows[windowID].height = _gridCellCollapsed ? 25 : 400;
                _windows[windowID].width = 300;
            }
            if (_gridCellCollapsed) return;

            //scroll rect setup
            _gridCellViewScroll = EditorGUILayout.BeginScrollView(_gridCellViewScroll);

            //default settings
            EditorGUILayout.Space();
            _inspectingCell.Sprite = (Sprite)EditorGUILayout.ObjectField("Display sprite", _inspectingCell.Sprite, typeof(Sprite), false, GUILayout.Height(EditorGUIUtility.singleLineHeight));
            _inspectingCell.UseDefaultSettings = EditorGUILayout.Toggle("Use default settings", _inspectingCell.UseDefaultSettings);
            if (!_inspectingCell.UseDefaultSettings)
            {
                _inspectingCell.GameObject = (GameObject)EditorGUILayout.ObjectField("Gameobject", _inspectingCell.GameObject, typeof(GameObject), false, GUILayout.Height(EditorGUIUtility.singleLineHeight));
                _inspectingCell.ColliderType = (Tile.ColliderType)EditorGUILayout.EnumPopup("Collider type", _inspectingCell.ColliderType);
            }

            //output
            _inspectingCell.OutputSprite = (BetterRuleTile.ExtendedOutputSprite)EditorGUILayout.EnumPopup("Output", _inspectingCell.OutputSprite);
            if (_inspectingCell.OutputSprite != BetterRuleTile.ExtendedOutputSprite.Single)
            {
                EditorGUILayout.Space();
                if (_inspectingCell.OutputSprite == BetterRuleTile.ExtendedOutputSprite.Animation)
                {
                    GUILayout.Label("Animation settings", EditorStyles.boldLabel);
                    _inspectingCell.MinAnimationSpeed = EditorGUILayout.FloatField("Min speed", _inspectingCell.MinAnimationSpeed);
                    _inspectingCell.MaxAnimationSpeed = EditorGUILayout.FloatField("Max speed", _inspectingCell.MaxAnimationSpeed);
                }
                if (_inspectingCell.OutputSprite == BetterRuleTile.ExtendedOutputSprite.Random)
                {
                    GUILayout.Label("Random tile settings", EditorStyles.boldLabel);
                    _inspectingCell.NoiseScale = EditorGUILayout.Slider("Noise", _inspectingCell.NoiseScale, 0.001f, 0.999f);
                    _inspectingCell.RandomTransform = (RuleTile.TilingRuleOutput.Transform)EditorGUILayout.EnumPopup("Shuffle", _inspectingCell.RandomTransform);
                }
                if (_inspectingCell.OutputSprite == BetterRuleTile.ExtendedOutputSprite.Pattern)
                {
                    GUILayout.Label("Pattern settings", EditorStyles.boldLabel);

                    //
                    _inspectingCell.PatternSize = EditorGUILayout.Vector2IntField("Pattern size", _inspectingCell.PatternSize);
                    if (_inspectingCell.PatternSize.x < 1) _inspectingCell.PatternSize.x = 1;
                    if (_inspectingCell.PatternSize.y < 1) _inspectingCell.PatternSize.y = 1;

                    int size = _inspectingCell.PatternSize.x * _inspectingCell.PatternSize.y;
                    if (size != _inspectingCell.Sprites.Length) Array.Resize(ref _inspectingCell.Sprites, size);
                }

                //space
                EditorGUILayout.Space();
                GUILayout.Label("Output sprites", EditorStyles.boldLabel);

                //_gridCellSprites = _inspectingCell.Sprites;
                //display a fucking list
                /*ScriptableObject target = this; // So apparently this gives errors
                SerializedObject so = new SerializedObject(target);
                SerializedProperty stringsProperty = so.FindProperty("_gridCellSprites");
                EditorGUILayout.PropertyField(stringsProperty, true);
                so.ApplyModifiedProperties();
                _inspectingCell.Sprites = _gridCellSprites;*/

                _inspectingCell.Sprites = EditorTools<Sprite>.ArrayField("Sprites", ref _showSpritesArray, _inspectingCell.Sprites, typeof(Sprite));

                //display pattern
                if (_inspectingCell.OutputSprite == BetterRuleTile.ExtendedOutputSprite.Pattern) GUILayout.Space(DisplayPatterGrid());

                if (_inspectingCell.OutputSprite != BetterRuleTile.ExtendedOutputSprite.Pattern) _inspectingCell.IncludeSpriteInOutput = EditorGUILayout.Toggle(new GUIContent("Include default sprite", "Add default sprite to the start of the array when generating the tile?"), _inspectingCell.IncludeSpriteInOutput);
                else _inspectingCell.IncludeSpriteInOutput = false;
            }

            //label
            EditorGUILayout.Space();
            var guiSize = _grid.DrawInteractiveMiniGrid(EditorGUILayout.GetControlRect(), _inspectingCell);
            GUILayout.Space(guiSize.height);

            EditorGUILayout.EndScrollView();

            //check if it was modified
            _inspectingCell.IsModified = _inspectingCell.CheckModified();

            //lock position
            _windows[windowID].lockPosition = _lockWindows;
            //move window
            if (!_lockWindows) GUI.DragWindow();
        }

        float _configWindowWidth = 0;
        float DisplayPatterGrid()
        {
            //get background rect
            Rect defaultRect = new Rect(EditorGUILayout.GetControlRect());
            if (defaultRect.width > 1) _configWindowWidth = defaultRect.width;

            Rect rect = new Rect(defaultRect.x, defaultRect.y + 6, _configWindowWidth, defaultRect.height);

            //set
            int columns = _inspectingCell.PatternSize.x;
            int rows = _inspectingCell.PatternSize.y;
            const float spacing = 2;
            float xOffset = 11;

            //
            float tileSize = (rect.width - 22 - (columns - 1) * spacing) / columns;
            if (tileSize > 40)
            {
                xOffset += columns * (tileSize - 40) / 2;
                tileSize = 40;
            }

            //set background height
            rect.height = (tileSize + spacing) * rows + 36;

            //draw background
            GUI.DrawTexture(rect, t_windowBorderTexture, ScaleMode.StretchToFill, true, 0, Color.white, 0, 5);
            GUI.DrawTexture(rect, t_backgroundTexture, ScaleMode.StretchToFill, true, 0, Color.white, 1, 5);
            GUI.DrawTexture(new Rect(rect.position, new Vector2(rect.width, 20)), t_fieldBoxTexture, ScaleMode.StretchToFill, true, 0, Color.white, 0, 5);
            GUI.DrawTexture(new Rect(rect.position, new Vector2(rect.width, 20)), t_backgroundTexture, ScaleMode.StretchToFill, true, 0, Color.white, 1, 5);
            GUI.Label(new Rect(rect.position + new Vector2(5, 0), new Vector2(rect.width, 20)), new GUIContent($"Pattern preview ({_inspectingCell.PatternSize.x * _inspectingCell.PatternSize.y} sprites)", "Colors:\n\n" +
                $"Gray:\t Sprites list is not the correct size!\n" +
                $"Red:\t Sprite is not set!\n" +
                $"Yellow:\t Sprite is not read and write enabled!"));

            int l = _inspectingCell.Sprites.Length;

            //
            for (int y = 0, i = 0; y < _inspectingCell.PatternSize.y; y++)
            {
                for (int x = 0; x < columns; x++)
                {
                    Rect cellRect = new Rect(rect.x + xOffset + x * (spacing + tileSize), rect.y + 30 + y * (spacing + tileSize), tileSize, tileSize);

                    if (l > i && _inspectingCell.Sprites[i] != null)
                    {
                        if (_inspectingCell.Sprites[i].texture.isReadable)
                        {
                            Rect slice = _inspectingCell.Sprites[i].rect;
                            Color[] cols = _inspectingCell.Sprites[i].texture.GetPixels((int)slice.x, (int)slice.y, (int)slice.width, (int)slice.height);

                            //create texture
                            Texture2D texture = new Texture2D((int)slice.width, (int)slice.height, TextureFormat.ARGB32, false);
                            texture.SetPixels(0, 0, (int)slice.width, (int)slice.height, cols);
                            texture.filterMode = FilterMode.Point;
                            texture.Apply();

                            EditorGUI.DrawPreviewTexture(cellRect, texture);
                        }
                        else EditorGUI.DrawRect(cellRect, Color.yellow);
                    }
                    else if (l > i) EditorGUI.DrawRect(cellRect, new Color(.7f, .3f, .3f));
                    else EditorGUI.DrawRect(cellRect, Color.gray);

                    i++;
                }
            }

            //return space
            return (tileSize + spacing) * rows + 24;
        }

        string GetRuleName(int rule)
        {
            switch (rule)
            {
                case -1: return "Ignore cell";
                case -2: return "Empty";
                case -3: return "Not same";
                case -4: return "Any";
                default: return "null";
            }
            
        }
#endregion

#region Export dropdown
        void ExportWindow(int windowID)
        {
            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title bar
            GUI.Label(new Rect(0, 0, _windows[windowID].width, 25), "Export options", titleStyle);
            EditorGUILayout.Space();

            bool changedShape = _file.ChangeGridShape((BetterRuleTileContainer.GridShape)EditorGUILayout.EnumPopup("Grid type", _file.settings._gridShape));
            if (changedShape) SetupGrid(true);

            //_file.settings._generatePalette = EditorGUILayout.Toggle(new GUIContent("Generate palette"), _file.settings._generatePalette);
            //_file.settings._addMissingRules = EditorGUILayout.Toggle(new GUIContent("Add missing rules", "In tiles which are variations of another tile, should the missing rules be added from the parent tile?"), _file.settings._addMissingRules);
            _file.settings._collapseSimilarRules = EditorGUILayout.Toggle(new GUIContent("Simplify similar rules", "Checks tiles which have the same sprite, finds a common pattern between them and replaces them with one rule that applies for all"), _file.settings._collapseSimilarRules);

            EditorGUILayout.Space();

            if (GUILayout.Button("Generate tiles"))
            {
                BetterRuleTileGenerator.GenerateTiles(_file);
                _windows[windowID].visible = false;
            }
            EditorGUILayout.Space();
        }
#endregion

#region Settings dropdown
        void SettingsWindow(int windowID)
        {
            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title bar
            GUI.Label(new Rect(0, 0, _windows[windowID].width, 25), "More settings", titleStyle);

            //
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Drawers", EditorStyles.boldLabel);
            _drawerSize = EditorGUILayout.IntField("Tile drawer size", _drawerSize);
            _drawerHeight = EditorGUILayout.IntField("Sprite drawer height", _drawerHeight);
            _drawerCollumns = EditorGUILayout.IntField("Sprite drawer collumns", _drawerCollumns);
            _expandedDrawerCollumns = EditorGUILayout.IntField("Expanded drawer collumns", _expandedDrawerCollumns);
            _file.settings._saveSpriteDrawer = EditorGUILayout.Toggle(new GUIContent("Save sprite drawer", "if this option is enabled the sprite drawer will remember the tiles inside it when opening the editor again. If you have a lot of sprites enabling this option will cause the editor to load slower."), _file.settings._saveSpriteDrawer);
            if (GUILayout.Button(new GUIContent("Clear sprite drawer", "Remove unused sprites from the sprite drawer, this will only take affect after you reload the editor window.")))
            {
                _file._imageObjects = new List<UnityEngine.Object>();
                SetupGrid(false);

                //select the object to prompt user to manually restart
                //Selection.activeObject = _file;
                //EditorGUIUtility.PingObject(_file);
                //Debug.LogWarning("Removed unused sprites from the sprite drawer. Close the editor window and open it again to see the changes.");
            }
            if (GUILayout.Button(new GUIContent("Add All sprites", "Finds all sprites in the asset database and adds it to the sprite drawer.")))
            {
                AddAllTextureAssets();
            }

            _drawerSize = Math.Max(_drawerSize, 1);
            _drawerHeight = Math.Max(_drawerHeight, 32);
            _drawerCollumns = Math.Max(_drawerCollumns, 1);
            _expandedDrawerCollumns = Math.Max(_expandedDrawerCollumns, 4);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Grid", EditorStyles.boldLabel);
            _zoomAmount = EditorGUILayout.FloatField("Current zoom", _zoomAmount);
            _file.settings._renderSmallGrid = EditorGUILayout.Toggle(new GUIContent("Render small grid", "Render the grid when it's zoomed out?"), _file.settings._renderSmallGrid);
            _file.settings._zoomTreshold = EditorGUILayout.FloatField(new GUIContent("Zoom treshold", "At what zoom value should the grid stop rendering?"), _file.settings._zoomTreshold);
            EditorGUILayout.Space();
            _gridCellSize = EditorGUILayout.Vector2IntField("Grid size", _gridCellSize);
            _tileRenderOffset = EditorGUILayout.Vector2Field("Grid cell offset", _tileRenderOffset);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Locked cells", EditorStyles.boldLabel);

            _file.settings._renderLockedOverlay = EditorGUILayout.Toggle(new GUIContent("Show locked overlay", "Shows a striped overlay above the tiles to indicate that the cells are locked"), _file.settings._renderLockedOverlay);
            _file.settings._renderLockedOutline = EditorGUILayout.Toggle(new GUIContent("Show locked outline", "Shows an outline around tiles to indicate that the cells are locked"), _file.settings._renderLockedOutline);
            _file.settings._lockedOutlineColor = EditorGUILayout.ColorField(new GUIContent("Outline color", "The color of the outline around locked cells"), _file.settings._lockedOutlineColor);

            EditorGUILayout.Space();

            //reset values to not crash the app
            if (_zoomAmount < .1f) _zoomAmount = .1f;
        }
#endregion

#region Recolor dropdown
        int _recolorFrom;
        int _recolorTo;
        string _replaceFrom;
        string _replaceTo;
        void RecolorWindow(int windowID)
        {
            string tileTooltip = "Replaces all tiles in the selection, which are the same as the tile you specify in \"Replace from\", to the tile you specify in \"Replace to\"";
            string spriteTooltip = "Find all sprites in the selection, whose filename includes \"Replace from\", and replaces them with sprites where the \"Replace from\" text is replaced to \"Replace to\"";

            //create styles
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel);
            titleStyle.alignment = TextAnchor.MiddleCenter;

            //title bar
            GUI.Label(new Rect(0, 0, _windows[windowID].width, 25), new GUIContent("Replace tiles in selection", tileTooltip), titleStyle);

            //show from and to popups
            EditorGUILayout.Space();
            _recolorFrom = EditorGUILayout.Popup(new GUIContent("Replace from", tileTooltip), _recolorFrom, _file.GetTileNames());
            _recolorTo = EditorGUILayout.Popup(new GUIContent("Replace to", tileTooltip), _recolorTo, _file.GetTileNames());

            //show prompt if not selected, show button if has selection
            EditorGUILayout.Space();
            if (_hasSelection)
            {
                if (GUILayout.Button("Replace tiles")) _file.RecolorSelection(_selectionRect, _recolorFrom, _recolorTo);
            }
            else GUILayout.Label("Select an area to replace tiles in!", EditorStyles.helpBox);

            //small space
            EditorGUILayout.Space();

            //second title
            EditorGUILayout.Space();
            GUILayout.Label(new GUIContent("Replace sprites in selection", spriteTooltip), titleStyle);

            EditorGUILayout.Space();
            _replaceFrom = EditorGUILayout.TextField(new GUIContent("Replace from", spriteTooltip), _replaceFrom);
            _replaceTo = EditorGUILayout.TextField(new GUIContent("Replace to", spriteTooltip), _replaceTo);
            EditorGUILayout.Space();
            if (_hasSelection)
            {
                if (GUILayout.Button("Replace sprites")) _file.RecolorSelection(_selectionRect, _replaceFrom, _replaceTo);
            }
            else GUILayout.Label("Select an area to replace sprites in!", EditorStyles.helpBox);

        }
#endregion
#endregion
    }
}
#endif