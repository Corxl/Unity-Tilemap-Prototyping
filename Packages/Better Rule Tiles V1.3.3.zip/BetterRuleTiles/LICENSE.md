# LICENSE

- This asset can be used in commercial and non-commercial projects.
- You can modify the asset as you need.
- You may not repackage, redistribute or resell the assets, no matter how much they are modified.
- Credit is not necessary, but always appreciated.

For more information contact the creator of the package.